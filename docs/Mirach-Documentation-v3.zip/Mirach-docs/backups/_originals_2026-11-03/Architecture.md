# Architecture — Private Community Communication App

> **Status:** Proposed architecture for the first implementation.
> **Review date:** 3 November 2026.
> **Scope:** Browser-based private community application; free-first prototype; gradual rollout.

## 1. Architecture goals

- Deliver a usable private messaging product without requiring phone numbers.
- Support two community entry paths: invitation code or administrator-reviewed request.
- Enforce membership, connection, conversation, and media permissions on the backend.
- Start with managed services to avoid operating custom infrastructure.
- Keep the frontend portable and the backend replaceable through clear service boundaries.
- Keep initial hosting within free tiers where possible, without promising unlimited use or production-grade uptime.
- Add voice/video, social, and gaming services only when their phases are approved.

## 2. High-level architecture

```mermaid
flowchart TB
  U[Member browser] -->|HTTPS| CF[Cloudflare Pages<br/>React + TypeScript + Vite]
  CF -->|Supabase client + user JWT| SB[Supabase project]
  SB --> AUTH[Supabase Auth<br/>Google OAuth]
  SB --> DB[(PostgreSQL<br/>RLS protected)]
  SB --> RT[Supabase Realtime<br/>private channels]
  SB --> ST[Supabase Storage<br/>private buckets]
  SB --> EF[Edge Functions / SQL RPCs]
  EF --> DB
  EF -->|short-lived access token| LK[LiveKit Cloud<br/>later phase]
  U <-->|WebRTC| LK
  DB -->|validated game state| RT
```

**Important separation:** Cloudflare Pages serves static frontend files. It is not the project's database, authentication authority, durable message store, or media store. Supabase is the application backend. LiveKit is introduced later for media transport.

### Why not GitHub Pages as the application host?

GitHub remains the source-code repository. GitHub Pages is intended for static site hosting and GitHub cautions against using Pages for sensitive transactions such as sending passwords. This application handles authentication and private communications, so the recommended deployment is Cloudflare Pages for the static frontend plus Supabase for backend services. A static site is not itself the security boundary; every private operation remains protected by Supabase Auth, database grants, RLS, and trusted functions.

## 3. Technology decisions

| Layer | Choice | Responsibility | Alternatives / migration trigger |
|---|---|---|---|
| UI | React + TypeScript | Pages, components, client-side state | Keep UI independent from Supabase SDK details where practical |
| Build | Vite | Dev server and static production build | Revisit only for a documented framework requirement |
| Styling | Tailwind CSS + shared design tokens | Responsive styling and consistent components | Component library may be added after accessibility review |
| Frontend hosting | Cloudflare Pages | Static asset hosting and Git-based deploys | Cloudflare Workers or another host if full-stack edge behavior becomes necessary |
| Source control | GitHub | Private source repository, issues, PRs, CI | No secrets or user data in repository |
| Authentication | Supabase Auth, Google OAuth first | External identity and app session JWT | Email/password only after SMTP and recovery work |
| Database | Supabase PostgreSQL | Membership, relationships, conversations, messages, moderation | Postgres remains portable; avoid vendor-specific schema dependence unless justified |
| Authorization | PostgreSQL grants + RLS | Authoritative row-level access checks | Never replace with only frontend checks |
| Realtime | Supabase Realtime | Postgres change delivery; private Broadcast/Presence for transient events | Dedicated WebSocket service if proven necessary by load tests |
| Object storage | Supabase Storage | Private media objects | Another S3-compatible provider if quota/cost demands it |
| Trusted logic | Supabase Edge Functions and narrowly scoped SQL RPCs | Atomic invites, admin actions, call tokens, game validation | A custom server only after complexity/scale justifies it |
| Calling | LiveKit Cloud, later | WebRTC room signaling/media routing, token validation | Self-host only after operating cost/security capacity is assessed |
| Tests | Vitest, Testing Library, Playwright, database/RLS tests | UI, integration, browser and authorization coverage | Add load testing before broader rollout |

Use current stable, mutually compatible package versions at implementation time. Commit the lockfile. Do not invent future version numbers in planning documents.

## 4. Deployment environments

### 4.1 Environments

- **Local:** Vite app, local Supabase stack if Docker/Supabase CLI are available; otherwise a clearly marked non-production development project.
- **Development/preview:** Cloudflare Pages preview deployment and development Supabase project. Use test accounts and dummy data only.
- **Production/community beta:** Separate production Supabase project and production frontend environment when the owner is ready. Do not point preview deployments at production data.

Supabase Free currently permits up to two active free projects across an organization and may pause low-activity free projects. Plan around this constraint; local development is preferable where practical.

### 4.2 Frontend build/deployment

- Vite production output: `dist/`.
- Cloudflare Pages build command: `npm run build`.
- Build output directory: `dist`.
- Connect the GitHub repository and deploy from the selected production branch.
- Configure SPA fallback in `public/_redirects` if required by the chosen router:

```text
/* /index.html 200
```

- Configure allowed origins and redirect URLs in Supabase Auth to include local development and exact Cloudflare Pages production/preview URLs as appropriate. Do not use broad redirect wildcards for production unless necessary and understood.
- Frontend environment variables may include `VITE_SUPABASE_URL` and the Supabase publishable/anon key. These are public client configuration, not secrets; RLS must make their use safe.
- Never place `service_role`, secret API keys, Google OAuth client secrets, LiveKit API secrets, database passwords, or SMTP credentials in `VITE_*` variables or browser bundles.

### 4.3 Git and CI

- Main branch represents deployable code; feature branches and pull requests for changes.
- CI should run type-check, lint, unit tests, build, and database tests where configured.
- Require a successful check before merge when repository settings permit.
- Use migrations for schema changes and review the SQL diff before applying remotely.
- Never force-push, rewrite history, or run destructive cleanup commands without an explicit, understood recovery plan.

## 5. Identity, membership, and authorization model

Authentication, community membership, and social connections are different concepts:

1. **Authenticated identity:** Supabase Auth confirms who signed in. The user receives a JWT.
2. **Community membership:** The membership record says whether that identity is pending, active, rejected, suspended, or left.
3. **Connection:** Two active members have accepted a relationship request.
4. **Conversation membership:** A user is a participant in a particular conversation.

A user must not gain community access merely by completing OAuth. A user must not gain access to another member's DMs merely by being an active community member.

### 5.1 Initial account flow

1. User chooses Google sign-in. No phone-number field is presented or required.
2. Supabase Auth completes OAuth and returns a user identity. Require a verified email claim from Google; do not expose it in the member directory. The user must have a supported Google account. The MVP relies on the Google account for authentication/recovery rather than managing an app password.
3. A database trigger or trusted provisioning routine creates a minimal `profiles` row for the authenticated identity if one does not exist. The email stays in the protected Auth identity, not the public member profile.
4. User chooses a unique username and display name.
5. If a valid invitation is supplied, a trusted atomic redemption operation checks its status, expiry, usage count, and email/identity restrictions (if configured). Default behavior: activate membership unless the global approval setting requires review.
6. If no valid invitation is supplied, create a `pending` membership request; no access to member-only routes or records is granted.
7. An administrator reviews pending requests. Approval changes membership to active; rejection leaves it blocked from community resources.
8. Suspended or removed members lose access according to the RLS rules and session/realtime revocation procedure.

### 5.2 Invitation invariants

- Store only a cryptographic hash of each invitation secret, not the raw code.
- Codes must have `expires_at`, `max_uses`, `uses_count`, `revoked_at`, `created_by`, and optional scope/notes.
- Redemption must be atomic in a transaction or carefully designed SQL RPC: validate and increment usage together. Concurrent redemptions must not exceed `max_uses`.
- Make each redemption unique per user and invite.
- A code can be revoked. Revocation prevents future redemption; decide separately whether previously admitted members remain active.
- Rate-limit code attempts and avoid revealing whether a guessed code is almost correct.
- Do not create an administrator through public self-registration. Bootstrap the first owner-admin through a trusted manual setup procedure.

### 5.3 Roles

- `member`: active community participant.
- `moderator`: can review reports and perform explicitly scoped moderation actions.
- `admin`: manages invitations, membership, settings, and moderation.
- Optional `owner`: reserved for the initial project owner if role separation is needed.

Roles are stored in a protected membership/role table or protected claim. Ordinary users cannot update their own role. All privileged actions are checked server-side and audited.

## 6. Data model

Use UUID primary keys, `timestamptz` timestamps, foreign keys, explicit unique constraints, and indexes for frequently queried foreign keys and sort/filter columns. Use SQL migrations as the source of truth.

### 6.1 Core tables for the first messenger release

| Table | Main fields / purpose |
|---|---|
| `profiles` | `user_id` (FK to `auth.users`), `username` (unique, normalized), `display_name`, `avatar_path`, `bio`, `created_at`, `updated_at`. No public email field. |
| `community_settings` | Single community configuration, including `require_admin_approval_for_all`, allowed invite behavior, and registration state. Read/write access is tightly restricted. |
| `memberships` | `user_id`, `status` (`pending`, `active`, `rejected`, `suspended`, `left`), `role`, `joined_at`, `reviewed_by`, `reviewed_at`, `reason_code` (avoid exposing private moderator notes). |
| `membership_requests` | Applicant, optional message, request status, created/reviewed timestamps, reviewer. One pending request per user. |
| `invitation_codes` | Hashed code, creator, expiry, max uses, usage count, revocation timestamp, optional policy fields. |
| `invitation_redemptions` | Invitation, user, redemption timestamp; unique `(invitation_id, user_id)`. |
| `connection_requests` | `requester_id`, `recipient_id`, status (`pending`, `accepted`, `declined`, `cancelled`), timestamps; prevent self-requests and duplicate pending pairs. |
| `connections` | Canonicalized pair of user IDs, creator/source, accepted timestamp; unique normalized pair. |
| `blocked_users` | `blocker_id`, `blocked_id`, created timestamp; prevent self-block and define how mutual blocking affects access. |
| `conversations` | ID, type (`direct`, `group`), creator, title/avatar for groups, timestamps, optional direct-pair key. |
| `conversation_members` | Conversation, user, role (`member`, `group_admin`), joined/left timestamps, last-read message pointer/time, mute state. Unique active membership per conversation/user. |
| `messages` | Conversation, sender, message type, text/body, created/edited/deleted timestamps, optional reply reference. Durable record; sender must be a current participant. |
| `message_attachments` | Message, private storage object path, MIME type, byte size, width/height/duration metadata where available. Never store an expiring signed URL as the permanent reference. |
| `notifications` | Recipient, type, related resource, read timestamp, created timestamp. Do not store unnecessary message bodies in notifications. |
| `reports` | Reporter, target user/content, reason category, optional details, status, assigned moderator, resolution timestamp. Access restricted to reporter and authorized moderators. |
| `admin_audit_log` | Actor, action, subject, timestamp, minimal metadata. Never log passwords, tokens, message contents, or raw invitation codes. |

### 6.2 Later-phase tables (create only when feature scope is approved)

| Feature | Tables / records |
|---|---|
| Social feed | `posts`, `post_attachments`, `comments`, `reactions` |
| Stories | `stories`, `story_views`; expiration state and cleanup policy |
| Calls | `call_sessions`, `call_participants`; no recording by default |
| Games | `games`, `game_players`, validated move/state records, results |
| Push notifications | Device/browser subscription records, encrypted/limited as required |

### 6.3 Relationship sketch

```mermaid
erDiagram
  AUTH_USERS ||--|| PROFILES : has
  AUTH_USERS ||--o| MEMBERSHIPS : requests
  AUTH_USERS ||--o{ MEMBERSHIP_REQUESTS : submits
  INVITATION_CODES ||--o{ INVITATION_REDEMPTIONS : used_by
  AUTH_USERS ||--o{ INVITATION_REDEMPTIONS : redeems
  AUTH_USERS ||--o{ CONNECTION_REQUESTS : sends
  AUTH_USERS ||--o{ CONNECTION_REQUESTS : receives
  AUTH_USERS ||--o{ CONNECTIONS : participates
  CONVERSATIONS ||--o{ CONVERSATION_MEMBERS : contains
  AUTH_USERS ||--o{ CONVERSATION_MEMBERS : joins
  CONVERSATIONS ||--o{ MESSAGES : contains
  AUTH_USERS ||--o{ MESSAGES : sends
  MESSAGES ||--o{ MESSAGE_ATTACHMENTS : has
```

The diagram is conceptual. Exact SQL constraints, delete behavior, pair normalization, and indexes must be specified in migrations before feature implementation.

### 6.4 Data integrity rules

- Username normalized form must be unique; define allowed characters and case-folding once.
- A user cannot connect to or message themselves.
- Only active members may create connection requests, join conversations, upload community media, or use member APIs.
- A direct conversation has at most one active pair; create it transactionally to avoid duplicate DMs.
- A user can read a conversation only while they are an active participant and their community membership is active. **Working default:** leaving or being removed from a group ends access to both new and historical messages/attachments; records remain available to remaining authorized participants under the retention policy. Confirm this default with the owner before production.
- The sender must be an active participant in the conversation when inserting a message.
- A group administrator may manage group membership; other members cannot silently add/remove participants. Leaving or removal immediately revokes that user’s access to group history and media under the working default.
- Do not rely on a frontend-supplied `sender_id`, `role`, `is_admin`, membership status, `conversation_id` authorization, or game winner. Derive identity from the authenticated JWT and validate relations in the database.

## 7. Authorization and RLS

RLS is mandatory on every exposed table in an API-accessible schema. Database grants and RLS policies must both be reviewed; a policy does not revoke an overly broad table grant. Tables not intended for direct client access should have grants revoked and be accessed only through narrowly scoped trusted operations.

### 7.1 Access matrix

| Resource/action | Signed out | Pending member | Active member | Moderator/admin |
|---|---:|---:|---:|---:|
| Public landing/sign-in | Read | Read | Read | Read |
| Own onboarding/request status | No | Read/update allowed onboarding fields | Read | Read for own account |
| Member directory | No | No | Read approved public profile fields | Read |
| Update own profile | No | Limited onboarding fields | Own profile only | Own profile; admin actions separate |
| View connection requests | No | No | Own sent/received requests | Only as required for moderation |
| Read DM/group messages | No | No | Current conversation participants only | No automatic access solely due to admin role |
| Upload/download private media | No | No | Authorized owner/conversation participants only | No automatic access solely due to admin role |
| Manage invitations/members | No | No | No | Admin only, server-verified |
| Review reports | No | No | Submit own reports/read own report status | Assigned/authorized moderators |
| Suspend/ban accounts | No | No | No | Admin/moderator according to explicit permissions |

**Administrators are not automatically allowed to read all private conversations.** Any exceptional support access must be a separately designed, auditable, justified process. Do not build a hidden admin backdoor.

### 7.2 RLS implementation rules

- Enable RLS on each exposed public table before the frontend can use it.
- Review and least-privilege `GRANT` statements as well as policies.
- Use `auth.uid()` as the identity source; do not accept a user ID from a client as proof of identity.
- Policies should check membership status and the exact relationship (connection, conversation membership, group role) needed for the record.
- Protect `profiles` columns so private account email/provider identifiers are not publicly selectable.
- Protect role, membership status, invitation usage, and moderation fields from client-side updates.
- Realtime Postgres Changes must be protected by the underlying table RLS. Broadcast/Presence channels must be private and protected by policies on `realtime.messages`; disable public channel access.
- Test both allowed and denied access with at least two ordinary users, a pending user, a blocked user, and an administrator.
- Re-test revocation behavior for already-open Realtime channels. Supabase notes that authorization may be cached for the lifetime of a channel connection; force appropriate re-authentication/disconnection and keep JWT expiry behavior understood.

## 8. Realtime and messaging design

### 8.1 Durable chat

- PostgreSQL `messages` is the source of truth. Realtime is a delivery/update mechanism, not the only message store.
- The client inserts a message through an authorized operation; PostgreSQL validates sender, conversation membership, active membership, block state, and payload limits.
- Clients subscribe only to authorized conversation updates. Use Postgres Changes for durable message insert/update events, with RLS.
- Use optimistic UI carefully: reconcile temporary client IDs with the database-assigned message ID and server timestamp; deduplicate events.
- Load older history with cursor pagination, not unbounded table queries.
- Apply message/body length limits and attachment count/size limits.
- Use `conversation_members.last_read_message_id` or `last_read_at` for initial read indicators. Avoid a receipt row per message per user until a demonstrated requirement justifies it.

### 8.2 Ephemeral chat signals

Use private Supabase Realtime Broadcast/Presence channels for typing state, online presence, and lightweight transient events. Do not persist every keystroke or presence heartbeat as a database row. Presence is best-effort and should not be treated as a security or availability fact.

### 8.3 Notification behavior

- First release: in-app notification list/badges and active-tab realtime updates.
- Browser push notifications are later and require an explicit permission request, subscription lifecycle, and secure delivery endpoint.
- Do not promise delivery while the browser is closed until push infrastructure is implemented and tested.
- No SMS notifications; phone numbers are outside the product scope.

## 9. Media storage design

- All private message attachments and profile assets use private buckets by default.
- Storage policies check the caller's active membership and the linked owner/conversation membership.
- Use opaque object paths such as `user_id/conversation_id/random_object_id.ext`; never trust a client-provided path to authorize access.
- Database stores object path and safe metadata, not permanent signed URLs.
- Generate short-lived signed URLs or use authenticated downloads after authorization.
- Configure allowed MIME types and maximum object size at bucket level; also enforce application limits before upload. Initial proposed limits: image 10 MB and video 25 MB when video uploads are enabled, subject to provider's current per-file maximum and owner approval.
- Do not put private content into public buckets. Public bucket URLs are intentionally accessible to anyone who has the URL.
- Use the Storage API for upload/delete; do not modify Supabase's internal `storage` schema directly.
- Define attachment cleanup when a message is deleted or an account is deleted; avoid orphaned billable objects.
- Do not record voice/video calls by default.

## 10. Trusted backend operations

Use a small number of narrowly scoped Edge Functions and SQL RPCs. Each user-facing function must validate the caller JWT and check permissions.

| Operation | Trusted implementation |
|---|---|
| Redeem invitation | Transactional SQL function/RPC with expiry, revocation, use-count, uniqueness and membership checks |
| Submit membership request | RLS-scoped insert or function with duplicate/pending checks |
| Approve/reject member | Admin-verified Edge Function or restricted SQL RPC; write audit record atomically |
| Suspend/restore member | Admin-verified function; revoke access and handle open realtime sessions |
| Create direct conversation | Transactional operation validating accepted connection and block rules; return existing pair conversation when present |
| Create group / change members | Validate creator/group-admin permission and active membership |
| Create call token | Authenticated Edge Function checks call invitation, membership and conversation permission; signs short-lived LiveKit token using server secret |
| Validate game move | SQL RPC or Edge Function validates player turn, game status, and legal move before state update |
| Process account deletion | Trusted workflow that handles Auth account, profile, messages policy, and storage cleanup according to documented retention rules |

Never disable JWT verification just to make an Edge Function work. If a webhook or scheduled function genuinely needs unauthenticated ingress, verify its signature/secret separately and document why.

## 11. Voice and video calling (later phase)

LiveKit Cloud is the preferred managed option for the initial call implementation. It uses WebRTC for participant media transport. The browser requests a call through the app; Supabase stores call state and delivers the invitation. After the recipient accepts, a trusted Edge Function checks that both participants are allowed and creates short-lived participant tokens. The browser joins the same LiveKit room using the token.

```mermaid
sequenceDiagram
  participant A as Caller browser
  participant S as Supabase
  participant B as Recipient browser
  participant L as LiveKit
  A->>S: Request call (authenticated)
  S->>S: Check membership, connection, block and call policy
  S-->>B: Realtime call invitation
  B->>S: Accept call
  A->>S: Request participant token
  B->>S: Request participant token
  S->>S: Authorize both; sign short-lived tokens
  S-->>A: Room URL + token
  S-->>B: Room URL + token
  A->>L: Join room
  B->>L: Join room
  L-->>A: Audio/video tracks
  L-->>B: Audio/video tracks
  A->>S: End call
  S->>S: Close/update call session
```

Call requirements:

- One-to-one voice call first, then one-to-one video, then group calls.
- Call invite must expire and become unavailable after decline, timeout, cancellation, or end.
- Only the intended recipient can accept. A user cannot join an arbitrary room by guessing its name.
- Tokens are server-generated, least-privileged, short-lived, and not stored in logs.
- Do not record calls by default. If recording is ever proposed, add explicit consent, retention, access, and legal review.
- Handle microphone/camera permission denial, unavailable devices, network changes, browser tab closure, busy state, and reconnect.
- Test browser compatibility and NAT/firewall behavior. Do not claim every network can connect reliably.
- Free LiveKit quotas are capped. Measure actual usage and do not enable paid overages without owner approval.
- Transport encryption is not equivalent to app-level end-to-end encryption. Do not claim E2EE unless a separate audited media encryption design is implemented and verified.

## 12. Social features (later phase)

Posts, comments, reactions, stories, and story views use separate tables and RLS rules. Decide whether content is visible to all active members or only connections; default to connections for personal stories and active members for an explicitly community-wide feed. Stories need server-controlled expiry and cleanup; client hiding alone is not deletion. Media remains in private storage unless the owner explicitly approves public sharing behavior.

## 13. Games (later phase)

Start with turn-based games such as Tic-tac-toe and Connect Four, followed by quiz/chess only after the first game is stable.

- A game invitation creates a private game room/session.
- Only accepted participants can join.
- The authoritative game state lives in PostgreSQL or a trusted function, not in an untrusted browser-only state object.
- Every move is validated: player identity, game status, turn order, legal move, and replay/idempotency protection.
- Realtime broadcasts the committed state after validation.
- Do not trust the client to declare a winner or alter scores.
- Faster action games need a dedicated authoritative game server and are out of the first gaming milestone.

## 14. Privacy and security threat model

| Threat | Required mitigation |
|---|---|
| User guesses IDs or calls APIs directly | RLS and grants on every exposed resource; negative authorization tests |
| User edits browser state to become admin | Protected roles; server-side role validation; no role updates from ordinary clients |
| Reuses invitation code past limit | Hash code; atomic redemption; unique redemption; rate-limit attempts |
| Reads another conversation | Conversation-membership checks in database policies and functions |
| Downloads private media via guessed path | Private buckets; Storage RLS; participant/owner checks; short-lived signed URLs |
| Stolen/long-lived session | Secure OAuth redirect configuration, session handling, short practical token lifetime, sign-out/revocation flow |
| Leaked service secret | Server-only secret storage, secret rotation, never expose through Vite/browser/Git |
| Abuse/spam | Request throttling, block/report tools, invitation controls, message/upload limits, moderation |
| XSS/content injection | Escape/render untrusted user content safely; sanitize allowed rich content; avoid unsafe HTML injection |
| Malicious upload | MIME/size restrictions, safe filenames, avoid serving executable content, consider scanning before public launch |
| Admin misuse | Least privilege, audit log, no hidden message-reading backdoor |
| Provider outage/quota | Graceful unavailable states, usage monitoring, export/restore plan, no claim of guaranteed uptime on free tier |

### 14.1 Encryption and claims

- Use HTTPS for all production traffic.
- Keep keys, tokens, and sensitive identifiers out of client logs and Git.
- Use provider-managed security features as documented, but do not claim a specific at-rest or end-to-end guarantee without checking the active provider plan and configuration.
- MVP private chats use authenticated, access-controlled storage and transport; **they are not app-level end-to-end encrypted**.
- End-to-end encryption is a later independent project requiring audited protocols, per-device keys, key verification/recovery, group-key changes, attachment encryption, and migration considerations. Do not invent custom cryptography.

## 15. Reliability, operations, and cost controls

- Track database size, storage, egress, Realtime messages/connections, Edge Function invocation count, LiveKit minutes/participants/egress, and Cloudflare builds.
- Add owner-visible quota warnings and feature-level upload/call limits where possible.
- Do not enable paid billing, overages, or service upgrades without explicit owner approval.
- Document provider free-plan limitations in the launch checklist. Supabase Free can pause after low activity; it is not an uptime guarantee.
- Export database and storage metadata before risky migrations. Test restore, not just backup creation.
- Supabase Free does not include the same daily backup features listed for paid plans; decide and test an independent backup/export approach before relying on real user data.
- Log request IDs, error categories, and non-sensitive metadata. Never log message bodies, OAuth tokens, invitation codes, passwords, or private media URLs.
- Define data retention and deletion workflows before the first external beta.

## 16. Current free-tier snapshot (checked 3 November 2026)

These are current published plan values at the review date and must be rechecked in provider dashboards before launch. They may change without this document changing.

| Provider | Current relevant free allowance / limitation | Architectural implication |
|---|---|---|
| Supabase Free | 500 MB database/project; 1 GB storage; 5 GB egress; 2 million Realtime messages; 200 peak Realtime connections; 500,000 Edge Function invocations; up to two active Free projects; low-activity projects may pause after around seven days | Good for a controlled prototype; media and bandwidth are the likely early constraints; use local development and monitor quotas |
| Cloudflare Pages Free | 500 builds/month; one concurrent build; 20-minute build timeout | Suitable for a static frontend with normal development cadence |
| LiveKit Build | 5,000 WebRTC minutes; 100 concurrent participants; 50 GB downstream transfer; 2 concurrent ingress and 2 egress requests in current quota docs | Calls are finite; defer calls, measure usage, and prevent unapproved charges |

Do not multiply per-project and organization-wide limits incorrectly. Verify whether each quota is project-scoped or organization-scoped in current billing documentation.

## 17. Architecture decision records (ADRs)

### ADR-001 — Static frontend host separate from backend

**Decision:** GitHub stores code; Cloudflare Pages hosts static React frontend; Supabase provides backend. **Reason:** GitHub Pages alone cannot provide server-side app functions or private backend, and GitHub warns against sensitive transactions on Pages. **Revisit when:** full-stack compute requirements emerge or provider quotas require migration.

### ADR-002 — Supabase as initial backend

**Decision:** Supabase Auth, PostgreSQL, Realtime, Storage, and Edge Functions. **Reason:** Integrated auth/database/RLS/realtime/file services reduce initial operations. **Trade-off:** Free-tier pausing and small storage/egress; vendor-specific functions require portability discipline.

### ADR-003 — Google OAuth first, no phone auth

**Decision:** Google OAuth + app username for MVP. **Reason:** Existing identity, no phone requirement, less initial email-delivery configuration. **Trade-off:** Users need a supported Google account; email/password is a later option requiring SMTP and recovery testing. Any separate Supabase confirmation-email flow also needs production SMTP configuration.

### ADR-004 — Membership and connection are separate

**Decision:** Sign-in does not equal membership; membership does not equal friendship; friendship does not equal conversation membership. **Reason:** Matches invite-only community privacy model.

### ADR-005 — Database is source of truth for chat/game state

**Decision:** Persistent state saved and authorized in Postgres; Realtime carries updates. **Reason:** Avoid message loss and client-controlled state.

### ADR-006 — Calls deferred and implemented with LiveKit

**Decision:** No custom media infrastructure for MVP. **Reason:** NAT traversal, TURN, signaling, and media routing are complex; managed infrastructure is safer for a first implementation. **Trade-off:** Free quotas and vendor dependency.

## 18. Official references

Review these sources again before implementation because provider documentation and pricing can change:

- [Supabase pricing](https://supabase.com/pricing)
- [Supabase billing and quotas](https://supabase.com/docs/guides/platform/billing-on-supabase)
- [Supabase Free project pausing](https://supabase.com/docs/guides/platform/free-project-pausing)
- [Supabase Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Supabase securing data](https://supabase.com/docs/guides/database/secure-data)
- [Supabase Google sign-in](https://supabase.com/docs/guides/auth/social-sign-in/auth-google)
- [Supabase custom SMTP](https://supabase.com/docs/guides/auth/auth-smtp)
- [Supabase Realtime authorization](https://supabase.com/docs/guides/realtime/authorization)
- [Supabase Storage access control](https://supabase.com/docs/guides/storage/security/access-control)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)
- [Supabase Edge Function security](https://supabase.com/docs/guides/functions/auth)
- [Cloudflare Pages limits](https://developers.cloudflare.com/pages/platform/limits/)
- [Cloudflare Pages redirects](https://developers.cloudflare.com/pages/configuration/redirects/)
- [GitHub Pages usage limits / prohibited sensitive use](https://docs.github.com/en/pages/getting-started-with-github-pages/about-github-pages)
- [LiveKit pricing](https://livekit.com/pricing)
- [LiveKit quotas and limits](https://docs.livekit.io/deploy/admin/quotas-and-limits/)
- [LiveKit token grants](https://docs.livekit.io/home/server/generating-tokens/)
