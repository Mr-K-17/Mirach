# Design — Private Community Communication App

> **Status:** UX and interaction specification; visual branding is intentionally undecided.
> **Review date:** 3 November 2026.

## 1. Design direction

Create a calm, modern, privacy-conscious community product. It should feel familiar to people who use messaging and social applications, but it must have its own name, visual identity, iconography, layouts, and component styling. Do not copy WhatsApp, Snapchat, or Instagram logos, brand colors as a complete identity, exact screen compositions, or proprietary visual assets.

### Design principles

1. **Messaging first:** Chats and connections are the primary experience; secondary features must not crowd the main navigation.
2. **Private by default:** Clear labels distinguish community membership, connections, group membership, and public-to-community content.
3. **Low cognitive load:** Keep navigation predictable, actions named clearly, and onboarding short.
4. **Responsive web:** Desktop and mobile browsers are first-class. No native-app-only interaction should be required.
5. **Accessible:** Keyboard navigation, visible focus, semantic controls, readable contrast, form labels, useful error messages, and reduced-motion support.
6. **Honest status:** Display pending, sent, delivered/read (only if implemented), offline, connecting, and failed states accurately.

## 2. Brand and visual system

The project name, logo, and final brand palette have not been selected. Use a neutral temporary product label in development and centralize theme values so branding can be changed without editing every component.

### Initial visual direction

- Clean, friendly, minimal, and community-oriented.
- Light theme first, with a carefully checked dark theme as a later enhancement or parallel theme.
- Neutral surfaces with one distinctive accent color chosen after the name is finalized.
- Rounded but not excessively pill-shaped controls; consistent spacing and typography.
- Use icon + text for important actions; do not rely on color alone to show status.
- Avoid visual imitation of any specific existing social product.

### Design tokens to define in code

- `color.background`, `color.surface`, `color.surfaceMuted`, `color.text`, `color.textMuted`, `color.border`, `color.accent`, `color.success`, `color.warning`, `color.danger`.
- Spacing scale based on a consistent small unit (for example 4 px increments).
- Typography scale for page title, section title, body, caption, and labels.
- Border radii for cards, inputs, and dialogs.
- Focus ring, shadow, and elevation tokens.
- Breakpoints for mobile, tablet, and desktop; use content-driven layouts rather than device-specific fixed widths.

## 3. Information architecture

### Primary member navigation

Desktop: left sidebar or top-level rail with clear labels; conversation list and current chat can be shown side by side.

Mobile browser: compact top bar and bottom navigation or a menu with clear back navigation. Chat list and active chat should occupy separate screens to avoid cramped layouts.

Suggested primary items:

1. **Chats** — one-to-one and group conversations.
2. **People** — member search, connection requests, and connections.
3. **Community** — feed and stories when Phase 7 is implemented.
4. **Calls** — call history and active call interface when calling is implemented.
5. **Games** — game lobby and invitations when Phase 8 is implemented.
6. **Profile/settings** — personal profile, privacy, and account controls.

Only show navigation for features that have actually shipped. Do not show nonfunctional placeholders that imply availability.

### Administrator navigation

- Overview / pending requests
- Members
- Invitations
- Reports and moderation
- Community settings
- Audit/activity history (restricted)

Admin controls are visible only to authorized roles and must still be validated by the backend.

## 4. Route and screen map

Routes are a proposal; exact routing library and URL scheme are implementation choices.

| Route | Screen | Access |
|---|---|---|
| `/` | Public landing page | Everyone |
| `/login` | Google sign-in and privacy note | Signed out |
| `/auth/callback` | OAuth callback/loading state | Auth flow |
| `/onboarding` | Username and invite code or request-access form | Authenticated, not yet active |
| `/pending` | Membership request pending | Pending member |
| `/rejected` | Access request rejected / contact admin guidance | Rejected member |
| `/app` | Authenticated app shell / redirect to Chats | Active member |
| `/app/chats` | Conversation list | Active member |
| `/app/chats/:conversationId` | Conversation detail | Current conversation participant |
| `/app/people` | Member search and connection requests | Active member |
| `/app/people/:username` | Member profile | Active member, subject to profile privacy |
| `/app/profile` | Own profile | Authenticated owner |
| `/app/settings` | Account, privacy, notifications, blocked users | Authenticated owner |
| `/app/calls` | Call history/lobby | Later phase |
| `/app/feed` | Community feed | Later phase |
| `/app/stories` | Stories viewer/creator | Later phase |
| `/app/games` | Game lobby | Later phase |
| `/admin` | Admin dashboard | Admin/moderator by sub-route permissions |

Unknown routes, stale sessions, pending memberships, and suspended accounts must be handled intentionally rather than falling into the main app shell.

## 5. Authentication and onboarding screens

### 5.1 Login

Elements:
- Product logo/name placeholder.
- Short explanation that this is a private community.
- “Continue with Google” primary action.
- Clear statement: phone number is not required; a Google account is used for sign-in/recovery, and its email is private and not shown in the member directory.
- Terms/privacy links when those documents exist.
- Loading, provider-cancelled, OAuth-error, and retry states.

Do not ask for a phone number. Do not ask users to paste Google passwords into the application.

### 5.2 Username setup

- Unique username input with allowed-character guidance.
- Display name input.
- Optional avatar upload (private bucket).
- Live username availability feedback, but the database unique constraint remains authoritative.
- Avoid collecting birth date, location, contacts, or other unnecessary personal data.

### 5.3 Join-community options

Present two clear paths:

**Have an invitation code**
- Enter code.
- Submit.
- Show success only after server validation.
- Explain whether the invitation grants immediate membership or needs review under current community settings.

**Don't have a code**
- Submit a membership request.
- Show pending state and what the administrator review means.
- Do not reveal other members' data while pending.

Error messages must not disclose sensitive invitation validity details to an attacker. Use generic failure feedback plus safe guidance.

### 5.4 Pending and rejected screens

- Show a clear “waiting for approval” state and sign-out action.
- Do not repeatedly poll at high frequency; refresh membership state on load and use a modest realtime/update strategy where appropriate.
- For rejected requests, provide neutral wording and a safe support/contact path if configured.

## 6. Member and connection experience

### 6.1 People directory

- Search by username or display name.
- Display only approved profile fields.
- Do not show email, OAuth subject/provider IDs, invite code, private notes, or hidden status fields.
- Empty state explains how to search or invite eligible people.
- Pagination or bounded result sets; no unbounded member dump.

### 6.2 Member profile

Actions depend on relationship:
- No relationship: Send connection request.
- Request sent: Pending; allow cancel.
- Request received: Accept or decline.
- Connected: Message, remove connection, block, report.
- Blocked: Show restricted state and avoid exposing private content.

Use confirmation for destructive actions such as removing a connection or blocking. Never imply a block has taken effect before the server confirms it.

### 6.3 Connection requests

Tabs or sections: Received, Sent, Connections. Include clear pending/accepted/declined states and reasonable empty states. Avoid double-submitting when the user clicks quickly.

## 7. Messaging experience

### 7.1 Chat list

Each conversation item may show:
- Group name or recipient display name.
- Avatar or group initials.
- Last message preview, with sensitive content omitted from notification previews when privacy settings request it.
- Timestamp.
- Unread indicator.
- Muted indicator if implemented.

Do not show online status as guaranteed presence. It is a best-effort signal.

### 7.2 Conversation view

Desktop layout:
- Conversation list panel.
- Main message thread.
- Conversation header with participants and actions.

Mobile layout:
- Chat list route, then a separate full-screen conversation route.
- Back action always returns to the correct chat list position where feasible.

Message composer:
- Text input with explicit send action.
- Attach action only when media upload is enabled.
- Character/size feedback when limits apply.
- Sending, sent, failed, retry, and offline states.
- Disable duplicate submission while the same message is being sent.

Message display:
- Distinguish sender and receiver without color-only cues.
- Show timestamps in a readable local format.
- Support safe text rendering; do not render arbitrary HTML from messages.
- Edited/deleted state must be explicit and truthful.
- Keep scroll position stable when older history loads.
- Use cursor pagination for history.

### 7.3 Group conversation

- Group title and avatar.
- Participant list and clear group-admin indicator.
- Add/remove members only for permitted group administrators.
- Leave group action.
- A removed or departed member should no longer receive new messages or access old messages/attachments under the working default. The records remain for other authorized participants according to retention policy; owner confirmation is required before production.

### 7.4 Read indicators

Use read indicators only after a reliable read cursor is implemented. Avoid suggesting a message has been delivered or read based solely on local send success or an open websocket.

## 8. Media sharing experience

When enabled:
- Show file preview before upload.
- Show file type, size, and progress.
- Enforce client-side checks for usability and backend/storage limits for security.
- Provide retry/cancel for failed uploads.
- Use authorized private download or short-lived signed URLs.
- Do not show permanent share links for private content.
- If the recipient no longer has access, show a clear unavailable state instead of a broken image.
- Provide deletion/report affordances according to retention policy.

Initial proposed upload limits are 10 MB per image and 25 MB per video, subject to current provider caps and owner approval. Do not activate video uploads merely because the UI control exists; it belongs to the media phase and must be tested against storage/egress costs.

## 9. Calling experience (later phase)

Screens/states:
- Incoming call prompt with caller identity and audio/video type.
- Accept, decline, and timeout.
- Outgoing/ringing state with cancel.
- Active audio call controls: mute, speaker/device selection where browser supports it, end call.
- Active video call controls: camera on/off, mute, end call, participant tiles.
- Reconnecting, poor network, permission denied, device unavailable, and call failed states.
- Call history entry with start time/duration and participants; no recording by default.

Browser camera/microphone permission prompts are controlled by the browser. Explain why the permission is needed and provide a recovery path if denied. Do not claim calls will ring while the recipient's browser is closed until a real push/background notification system is implemented.

## 10. Social and games experience (later phases)

### Community feed and stories

- Clear audience label: connections-only or all active community members.
- Audience selection before publishing.
- Story expiry is shown accurately and enforced on the server.
- Report content action is available.
- Media remains private unless a deliberately public-to-community policy is implemented.

### Games

- Game lobby with “Invite connection” action.
- Private room summary showing invited participants and status.
- Clear turn indicator and legal-move feedback.
- Reconnect/resume behavior for turn-based games.
- Result computed by trusted game logic; show the result only after server confirmation.
- No real-money stakes or gambling mechanics in the initial product.

## 11. Administrator interface

### Overview
- Counts of pending applications, active members, unredeemed invitations, and unresolved reports.
- Avoid showing private chat contents or unnecessary personal details.

### Membership queue
- Applicant username/display name, request time, invitation context where available.
- Approve, reject, suspend, restore actions according to role.
- Confirmation for consequential actions.
- Audit outcome and safe error handling.

### Invitations
- Create code with expiry and use limit.
- Reveal raw code only once at creation; store only hash server-side.
- Copy action with user confirmation/feedback.
- Revoke code.
- Show usage count and expiry, not the underlying secret.

### Moderation
- Report queue, reason, target, status, and resolution controls.
- Access to message content only if separately justified by the reporting flow and authorized; do not add a general message browser for admins.
- Log moderation actions.

## 12. Responsive behavior

- Start with mobile-first CSS, then enhance for tablet/desktop.
- Avoid fixed widths that break on narrow devices.
- Ensure forms, chat composer, modal dialogs, and media previews fit viewport height and safe areas.
- Do not depend on hover to expose essential actions.
- Keep touch targets comfortably sized and spaced.
- On narrow screens, use one primary navigation surface at a time.
- Test current stable versions of Chrome, Edge, Firefox, and Safari; record the exact tested versions in release notes.

## 13. Accessibility requirements

- Semantic landmarks, headings, buttons, links, labels, and form descriptions.
- Full keyboard access, logical tab order, visible focus indicators, and Escape behavior for dialogs.
- WCAG-oriented contrast; status cannot rely on color alone.
- Accessible names for icon-only buttons.
- Screen-reader announcements for new messages and errors without over-announcing every keystroke.
- Reduced-motion preference respected.
- Alt text for meaningful images; decorative images use empty alt text.
- Inputs include validation instructions and error associations.

## 14. Shared UI states and content guidance

Every data-driven screen needs:
- Loading/skeleton state.
- Empty state.
- Error state with a retry path where safe.
- Offline/reconnecting state when the feature depends on network.
- Permission-denied or access-revoked state.
- Success feedback only after server confirmation.

Use neutral, respectful language. Never blame users for network or permission errors. Do not expose database errors, stack traces, token details, internal IDs, raw SQL, or security-sensitive reasons in the user interface.

## 15. Design acceptance checklist

- The application works at mobile and desktop widths without horizontal overflow.
- Users can distinguish sign-in from community approval.
- Pending users cannot see member-only screens.
- The UI never exposes email or private identifiers in the member directory.
- Connection and chat actions reflect server-confirmed status.
- Private media does not render through public URLs.
- All controls are keyboard accessible and have accessible names.
- Loading, empty, error, offline, and revoked-access states are designed.
- Only released features appear as enabled navigation items.
