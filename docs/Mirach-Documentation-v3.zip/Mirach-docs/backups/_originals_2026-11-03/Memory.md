# Memory — Private Community Communication App

> **Purpose:** Durable hand-off context for the project owner and any future AI/developer sessions.
>
> **Document status:** Planning baseline; no application code or cloud resources are confirmed as created.
>
> **Last reviewed:** 3 November 2026 (Asia/Kolkata)

## 1. Project at a glance

The project is a private, browser-based community application inspired by the functionality of WhatsApp, Snapchat, and Instagram, with casual multiplayer games. It is for a small, controlled community, not an open public social network at launch.

Members create an account without a phone number, establish a community username, become approved community members, and send/accept connection requests before starting private one-to-one conversations. Group conversations and media sharing are part of the planned product. Voice/video calling, social publishing, stories, and games follow after the core messenger is dependable.

The product may use familiar interaction patterns, but must have its own name, visual identity, code, and implementation. Do not copy proprietary source code, logos, brand assets, or distinctive protected designs from existing services.

## 2. Decisions established by the owner

| Topic | Established decision |
|---|---|
| Product direction | Private community communication and social app with games |
| Community entry | Both invitation-code registration and administrator-reviewed membership requests |
| Platform | Browser-based web application |
| Initial budget | Free services first; no unapproved paid services or automatic billing |
| Authentication preference | Choose the option that best balances security and simplicity |
| Phone number | Not required; do not design phone-number authentication |
| Hosting idea | Owner initially proposed GitHub Pages; architecture now recommends GitHub for source control and Cloudflare Pages for the web frontend, with Supabase as backend |
| Audience/scale | Small private community; exact member count and expected concurrent use are not yet specified |

### 2.1 Recommended interpretation of “both” registration paths

Implement two ways to request/join the community:

1. **Valid invitation:** A user signs in, supplies a valid invitation code, and is admitted automatically by default. A community-wide setting may require an administrator to approve even invited applicants.
2. **No invitation:** A user signs in and submits a membership request. Their membership remains `pending` until an administrator approves or rejects it.

This default makes both methods useful without making an invitation code a permanent bypass around a future community-wide approval policy. The behavior must be visible in the onboarding UI and enforced server-side.

### 2.2 Recommended initial authentication

Use **Supabase Auth with Google OAuth** for the first release, plus a unique in-app username. This avoids collecting phone numbers and avoids needing an application-managed password-reset flow in the MVP. Users must have a supported Google account; their Google account remains their identity/recovery provider. Treat the returned email as private account identity, not as the community username, and verify the provider's email-verification claim. Do not add a separate app email-confirmation step unless a real SMTP provider is configured and tested.

Email/password may be added later after a real SMTP provider and recovery flow are configured and tested. Do not silently make Google the only permanent option; record it as the initial MVP choice because the owner asked for the best balance of security and simplicity.

## 3. Recommended technology baseline

| Concern | Planning choice | Notes |
|---|---|---|
| Frontend | React + TypeScript + Vite | Responsive browser application; strict TypeScript |
| Styling | Tailwind CSS, with accessible reusable components | Keep design tokens and components consistent |
| Frontend deployment | Cloudflare Pages | Static frontend deployment connected to GitHub |
| Source control | GitHub | Repository, issues, pull requests, and CI |
| Authentication | Supabase Auth; Google OAuth first | No phone auth |
| Database | Supabase PostgreSQL | Durable application records |
| Realtime | Supabase Realtime | Durable message updates plus private presence/typing channels |
| Media | Supabase Storage | Private buckets and policy-controlled access |
| Trusted server logic | Supabase Edge Functions and narrowly scoped SQL RPCs | Never expose service-role/secret keys in browser code |
| Voice/video | LiveKit Cloud, introduced in a later phase | Use short-lived backend-issued tokens; free plan limits apply |
| Game updates | Supabase Realtime initially | Server/database validates every move; begin with turn-based games |
| Tests | Vitest + React Testing Library; Playwright for browser flows; database/RLS tests | Test multiple users and unauthorized access |

This is a free-first starting stack, not a promise that unlimited production use will remain free. Current quotas and terms must be rechecked before launch or a provider change. Self-hosting or replacing a provider is a separate architecture decision, not an automatic response to a quota warning.

## 4. Product principles

1. **Private by default:** No public registration or public access to private conversations/media.
2. **Phone-number independent:** Do not require a number for registration, account lookup, or calling.
3. **Membership is separate from authentication:** A signed-in identity is not automatically a community member.
4. **Connections are separate from membership:** Being an approved member does not automatically grant access to another member's private chat.
5. **Backend-enforced permissions:** UI hiding is never a security boundary. Use database grants, RLS, and trusted server functions.
6. **Small, complete milestones:** Deliver a secure messenger before social feeds, calls, and games.
7. **Free-first, with explicit cost gates:** Monitor quotas and stop/limit optional features before incurring unapproved charges.
8. **Honest security claims:** Private access control and TLS do not equal end-to-end encryption.
9. **No fabricated completion:** Do not claim a feature, migration, test, backup, deployment, security review, or model has been completed unless it has actually been performed and verified.

## 5. Product scope snapshot

### First useful release — Private Messenger

- Google sign-in; no phone number.
- Unique community username and basic profile.
- Invitation-code flow and no-code membership request flow.
- Administrator approval/rejection, suspension, and role controls.
- Member search/directory with privacy-conscious fields.
- Connection requests, acceptance, rejection, removal, and blocking.
- One-to-one and group text conversations.
- Realtime message updates and persistent message history.
- Private image sharing, subject to upload limits and storage quota.
- Report/block controls and basic administrative moderation.

### Later releases

- Additional email/password authentication (after SMTP/recovery setup).
- Video and other media sharing, voice notes, richer message receipts.
- One-to-one voice/video calls, then group calls using LiveKit.
- Community posts, reactions, comments, and expiring stories.
- Turn-based games (Tic-tac-toe, Connect Four, quiz), then chess and more complex multiplayer experiences.
- Optional push notifications, advanced moderation, end-to-end encryption, mobile apps, or larger-scale infrastructure only after separate design and approval.

## 6. Hard constraints and non-goals

- The first target is a web application, not native Android/iOS software.
- A responsive browser interface is in scope. A PWA can be considered later but is not a current owner decision or a launch dependency.
- GitHub Pages alone cannot provide the backend, database, private object storage, or calling infrastructure. The chosen design uses GitHub for code and Cloudflare Pages for the static frontend.
- Do not build a custom Node.js backend at the beginning; Supabase Edge Functions/RPCs cover the initial trusted operations.
- Do not promise WhatsApp-level E2EE in the MVP. Do not invent or implement custom cryptography.
- No public user directory, public posts, anonymous chat, phone-number lookup, advertising, payments, or monetization in the initial scope.
- Group calling, real-time action games, native apps, and large-scale operations are not MVP requirements.

## 7. Current status (truthful hand-off)

- Six planning documents (`Memory.md`, `Architecture.md`, `Design.md`, `Phases.md`, `PRD.md`, and `Rules.md`) have been created as a consistent planning baseline and are awaiting owner review/approval.
- No project name has been selected.
- No GitHub repository, Supabase project, Cloudflare Pages site, LiveKit project, OAuth client, database schema, or application code is confirmed as created.
- No deployment, RLS policy, security test, or real-user test is confirmed as completed.
- No account credentials, API keys, secrets, or personal information should be placed in these documents.

Future sessions must ask the owner to share the actual repository/files or current command output before claiming implementation progress. Do not infer that a plan in these documents has been executed.

## 8. Decisions still open

Use the defaults below to proceed with a prototype; record owner confirmation before a public/community production launch.

| Open decision | Safe working default | When it must be finalized |
|---|---|---|
| Product name, logo, domain | Neutral temporary project label; no brand assets copied | Before public-facing beta |
| Community size and call concurrency | Small invite-only group; measure actual use | Before load/cost planning |
| Invitation policy | Valid code activates unless `require_admin_approval_for_all` is enabled; no-code request is pending | Before first onboarding test |
| Directory visibility | Only active members; display username and chosen public profile fields, never email | MVP |
| Who can DM whom | Accepted connections only; group messages only for group members | MVP |
| Group creation | Active members create groups with accepted connections; creator is group admin | MVP |
| Former group-member history | Default: a user who leaves or is removed loses access to group history and attachments; records remain for remaining participants under retention policy | Before MVP release |
| Default media limits | Images up to 10 MB; video up to 25 MB if enabled; confirm against current provider limits | Before media release |
| Profile picture visibility | Private to active members at launch | Before profile release |
| Message retention/deletion | Do not silently auto-delete; document account deletion and retention before launch | Before real user data |
| Age/minor policy and legal/privacy terms | Do not assume an age threshold; obtain owner decision and appropriate legal review before public release | Before inviting minors or public launch |
| Moderation team | One owner-admin at first, with a secure way to add moderators later | MVP |
| Authentication alternatives | Google OAuth first; email/password later with verified SMTP | Before beta if Google-only is unsuitable |
| Backup/recovery expectations | Test export/backup/restore process before real use; Free plan does not include Pro daily backups | Before production use |
| E2EE | Not in MVP; evaluate audited protocol and key-management design separately | Before claiming E2EE |

## 9. Current provider constraints to remember

Provider pricing and quotas are volatile. The following is a planning snapshot checked on 3 November 2026, not a permanent guarantee:

- Supabase Free currently lists 500 MB database per project, 1 GB storage, 5 GB egress, 2 million Realtime messages, 200 peak Realtime connections, and 500,000 Edge Function invocations; the Free project may pause after about seven days of low activity. Confirm the live plan before deployment.
- Cloudflare Pages Free currently lists 500 builds per month and one concurrent build. It is only the frontend host in this design.
- LiveKit Build currently lists 5,000 WebRTC minutes, 100 concurrent participants, and 50 GB downstream transfer. Those limits are finite and calls are intentionally deferred.
- A free-tier prototype is not an uptime, backup, disaster-recovery, or unlimited-storage guarantee.

Official source links are maintained in `Architecture.md`.

## 10. What to do next

1. Review the six documents as a set and approve or change the remaining defaults.
2. Choose a project name only when ready; keep names/configuration centralized.
3. Create the GitHub repository and local React/TypeScript/Vite scaffold.
4. Create a development Supabase project; configure Google OAuth and redirect URLs.
5. Implement migrations and security policies before connecting real users.
6. Deploy the first static shell to Cloudflare Pages.
7. Complete authentication, membership, connection, and messaging phases with multi-user security tests.
8. Add media, calls, social modules, and games only after their phase gates pass.

**Instruction for future contributors:** Read `Rules.md` first, then `PRD.md`, `Architecture.md`, `Design.md`, `Phases.md`, and this `Memory.md`. If implementation reality differs from this plan, update the documents rather than pretending the plan is already true.
