# Product Requirements Document (PRD)

## Private Community Communication App

> **Document status:** Version 1.0 planning baseline — proposed, not implemented.
>
> **Review date:** 3 November 2026.
>
> **Working product name:** Not selected.

## 1. Product summary

Build a private, browser-based communication and social platform for a small, controlled community. The product combines private messaging, member connections, photo/video sharing, voice/video calls, social content, and casual multiplayer games.

The initial release prioritizes identity, community access, connections, private one-to-one/group messaging, and secure image sharing. Calls, feed/stories, and games are later releases. The application does not require phone numbers. It uses community usernames for member discovery and connection requests.

The app may draw inspiration from common communication patterns in WhatsApp, Snapchat, and Instagram, but it must use its own identity, design, content, and implementation.

## 2. Problem and opportunity

A small community wants a single private place to discover approved members, establish connections, communicate, share media, and eventually play games together. Existing public social networks are not designed around this community's invitation/approval boundary and may require social graph exposure or phone-based onboarding.

The opportunity is a controlled, community-owned experience with clear membership rules and user-level privacy.

## 3. Goals

### Product goals

1. Allow community members to create accounts without phone-number authentication.
2. Control access through invitation codes and administrator-reviewed requests.
3. Let approved members discover one another and create explicit connections.
4. Deliver reliable one-to-one and group messaging with persistent history.
5. Support private media sharing with backend-enforced access control.
6. Provide a foundation for voice/video calls, social publishing, and games.
7. Keep the initial operational cost as close to zero as practical, while being honest about limits.

### Success measures for the first community beta

- A new user can sign in and complete the invitation or membership-request process without a phone number.
- An administrator can review requests and manage invitations.
- Two approved, connected users can exchange persistent messages in separate browser sessions.
- Group participants can communicate while nonparticipants are denied access.
- Authorized participants can access shared images; unrelated users cannot access them by guessing IDs or object paths.
- No critical/high authorization defect remains open at release.
- The app works on mobile and desktop browsers for the agreed test set.
- The owner can inspect provider usage and understand the free-tier limitations.

Do not use vanity metrics such as total signups as proof of a successful private community product.

## 4. Non-goals for the first release

- Rebuilding all features or infrastructure of WhatsApp, Snapchat, or Instagram at their scale.
- Public, anonymous, or unrestricted registration.
- Phone-number login, contact upload, or phone-number discovery.
- Native Android/iOS applications.
- Guaranteed push notifications while the browser is closed.
- Group video calling at initial release.
- Live-streaming or fast-action multiplayer games.
- Payments, advertising, subscriptions, marketplace, or gambling.
- Call recording.
- App-level end-to-end encryption in the MVP.
- Medical, financial, or other high-stakes services.

## 5. Target users and roles

### Member

An invited or approved individual who uses a username to find other members, send connection requests, chat, and share approved content.

### Applicant / pending user

A user who has authenticated but is not yet an active community member. They can complete their onboarding and see their own application status, but cannot browse members, chats, or private media.

### Administrator

A trusted person who manages invitation codes, member approvals, suspensions, community settings, and administrative roles. Administrators do not automatically receive access to all private conversations.

### Moderator

A trusted person who reviews reports and performs assigned moderation actions. Permissions should be narrower than administrator permissions.

## 6. Core product rules

1. Authentication does not automatically grant community membership.
2. A valid invitation code may grant immediate membership by default; the community can enable approval for every applicant.
3. Without a valid invitation, a user can request membership and must remain pending until approved.
4. Only active community members can use member features.
5. An active member is not automatically connected to every other member.
6. Private one-to-one messaging requires an accepted connection by default.
7. Group access requires current group membership. Working default: a user who leaves or is removed loses access to both new and historical group messages/attachments; records remain for other authorized participants under the retention policy. Confirm this before production.
8. Blocking prevents the interactions defined in the block policy, including new connection/chat activity.
9. Email and provider identifiers are private; community discovery uses username/display name.
10. Roles, membership status, invitation usage, message sender identity, and game results are controlled by the backend.

## 7. Functional requirements

Priority levels:
- **P0:** Required for Private Messenger MVP.
- **P1:** Important follow-on capability.
- **P2:** Later/advanced capability.

### 7.1 Identity and account access

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-AUTH-01 | P0 | Users can authenticate without a phone number. | Google OAuth works for users with a supported Google account; provider email verification is checked; no phone field or SMS verification is required. |
| FR-AUTH-02 | P0 | Each user has a unique community username. | Username is normalized, validated, and protected by a database unique constraint. |
| FR-AUTH-03 | P0 | Users can set a display name and optional avatar. | Only approved profile fields appear in the member directory. |
| FR-AUTH-04 | P0 | Users can sign out and recover a session safely. | Sign-out clears the app session; expired/invalid session returns to sign-in with a safe message. |
| FR-AUTH-05 | P1 | Email/password login may be added. | Only after production SMTP, verification, password reset, rate-limit, and abuse handling are tested. Any separate Supabase confirmation-email flow also requires working SMTP. |

### 7.2 Community onboarding and administration

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-MEM-01 | P0 | Users can register with an invitation code. | Valid active code is checked server-side; expired/revoked/exhausted codes fail; usage limit cannot be exceeded concurrently. |
| FR-MEM-02 | P0 | Users without a code can request membership. | Request is stored as pending; user sees pending screen; no member data is exposed. |
| FR-MEM-03 | P0 | Admin can approve/reject requests. | Only authorized admin can act; status and audit record are updated atomically. |
| FR-MEM-04 | P0 | Admin can create, limit, expire, and revoke invitations. | Raw code is shown only at creation; only a hash is stored; use count and expiry are visible. |
| FR-MEM-05 | P0 | Admin can suspend/restore members. | Suspended user loses access to member resources and cannot use existing sessions to make new requests. |
| FR-MEM-06 | P0 | Community can require approval for all applicants. | Protected setting controls whether invited applicants activate immediately or remain pending. |
| FR-MEM-07 | P0 | First admin is provisioned safely. | No public UI or client request can self-assign admin role. |
| FR-MEM-08 | P1 | Admin can view a moderation/audit history. | Privileged actions have actor, action, subject, and timestamp; sensitive values are excluded. |

### 7.3 Profiles, directory, and connections

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-CON-01 | P0 | Active members can search approved members. | Search is bounded/paginated and exposes only allowed fields. |
| FR-CON-02 | P0 | Members can send connection requests. | Only active members can send; self/duplicate/blocked requests are rejected. |
| FR-CON-03 | P0 | Recipient can accept or decline. | Only intended recipient can decide; state is updated server-side. |
| FR-CON-04 | P0 | Sender can cancel a pending request. | Only sender can cancel their pending request. |
| FR-CON-05 | P0 | Members can remove connections. | Relationship is removed and future DM policy is applied. |
| FR-CON-06 | P0 | Members can block/unblock and report users. | Blocking prevents prohibited interactions; report reaches authorized moderators. |
| FR-CON-07 | P0 | Private account identifiers remain private. | Email, OAuth subject, tokens, and private moderation notes never appear in directory responses. |

### 7.4 Messaging

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-MSG-01 | P0 | Connected members can start a one-to-one conversation. | A unique direct conversation is created or existing one returned; non-connections/blocked users are denied. |
| FR-MSG-02 | P0 | Members can create group conversations. | Only active users can create; membership and group role are recorded. |
| FR-MSG-03 | P0 | Users can send and receive text messages in realtime. | Message is persisted before/with delivery; separate browser session receives update without manual refresh under normal conditions. |
| FR-MSG-04 | P0 | Users can retrieve conversation history. | Only participants can read; history is cursor-paginated and consistently ordered. |
| FR-MSG-05 | P0 | Group admins can manage participants. | Only authorized group admins can add/remove; state changes are auditable where appropriate. A removed/departed member loses group-history and attachment access under the working default. |
| FR-MSG-06 | P1 | Message edit/delete may be supported. | Sender permissions, edit window (if any), deleted state, and history behavior are explicitly defined. |
| FR-MSG-07 | P1 | Read indicators are supported. | Read state is based on a server-saved conversation read cursor, not guessed from a local UI event. |
| FR-MSG-08 | P1 | Typing and online hints are supported. | Private Realtime channels authorize participants; status is treated as best effort. |
| FR-MSG-09 | P1 | In-app notifications show relevant events. | Notification belongs to recipient; read state is stored; no private message body is unnecessarily duplicated. |

### 7.5 Media sharing

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-MEDIA-01 | P0 | Users can share images in authorized conversations. | Upload is stored in private bucket; message attachment contains storage path and safe metadata. |
| FR-MEDIA-02 | P0 | Only authorized participants can access an attachment. | RLS/Storage policies deny unrelated members, pending users, and signed-out users. |
| FR-MEDIA-03 | P0 | Upload size/type is restricted. | Limits are enforced at application and storage/backend layers. |
| FR-MEDIA-04 | P1 | Users can share videos. | Enabled only after quota, MIME, file-size, and egress testing; proposed first limit 25 MB. |
| FR-MEDIA-05 | P1 | Users can send voice notes and other files. | Added only with format, size, and abuse controls. |

### 7.6 Calls

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-CALL-01 | P1 | Members can initiate one-to-one voice calls. | Caller/recipient authorization is checked and token is generated server-side. |
| FR-CALL-02 | P1 | Recipient can accept/decline incoming call. | Invitation has timeout/decline/cancel/end states. |
| FR-CALL-03 | P1 | Members can initiate one-to-one video calls. | Browser camera/mic permissions and failure states are handled. |
| FR-CALL-04 | P2 | Group calls are supported. | Participant limit, cost, network, and moderation rules are tested first. |
| FR-CALL-05 | P1 | Call token/API secret is protected. | Token is short-lived; API secret never enters browser bundle or logs. |
| FR-CALL-06 | P0 | Calls are not recorded by default. | No recording path is enabled without a new explicit requirement and consent/retention design. |

### 7.7 Social content

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-SOC-01 | P2 | Members can create posts and a community feed. | Audience is explicit; access is enforced on reads and media. |
| FR-SOC-02 | P2 | Members can react/comment. | Only eligible audience members can interact; rate limits and report controls exist. |
| FR-SOC-03 | P2 | Members can publish stories. | Stories expire according to server time and cleanup; expired content is no longer retrievable. |
| FR-SOC-04 | P2 | Audience and privacy rules are visible before publishing. | User understands who can see the content before submit. |

### 7.8 Games

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-GAME-01 | P2 | Members can invite accepted connections to a game. | Only invitees can join the private game session. |
| FR-GAME-02 | P2 | First game supports turn-based play. | Tic-tac-toe or Connect Four moves are validated by trusted backend logic. |
| FR-GAME-03 | P2 | Game state and result are persisted. | Browser cannot arbitrarily set moves, score, or winner. |
| FR-GAME-04 | P2 | Players can resume a supported turn-based game. | Reconnected participant receives current authoritative state. |
| FR-GAME-05 | P2 | Additional games can be added modularly. | Game rules/state are separated from generic invite/session infrastructure. |

## 8. Key user journeys

### Journey A — Invite-code registration

1. Visitor opens the landing page.
2. Visitor signs in using Google.
3. User selects a unique username/display name.
4. User enters invitation code.
5. Backend validates code and current community policy.
6. User becomes active or pending according to policy.
7. Active user opens member dashboard; pending user sees waiting state.

### Journey B — Request membership without a code

1. Visitor signs in.
2. User completes profile basics.
3. User submits membership request.
4. Backend stores pending request.
5. User sees pending status only.
6. Admin reviews and approves/rejects.
7. User receives in-app status update at next visit or through available notification.

### Journey C — Connect and chat

1. Active member A searches for member B by username.
2. A sends connection request.
3. B accepts.
4. A opens a new conversation.
5. Backend confirms active membership, accepted connection, and no block.
6. A sends a message; message is persisted.
7. B receives realtime update and can respond.

### Journey D — Group chat

1. Active connected members create a group.
2. Creator becomes group admin.
3. Participants are added through an authorized operation.
4. Members exchange messages.
5. Nonparticipants cannot retrieve group metadata, history, or attachments.

### Journey E — Media share

1. Member selects permitted image.
2. Client checks file size/type for immediate feedback.
3. Backend/Storage policy verifies user and destination authorization.
4. File is uploaded to private storage.
5. Message/attachment metadata is saved.
6. Recipient downloads through an authenticated request or short-lived signed URL.

### Journey F — Call (later)

1. Caller initiates call.
2. Backend verifies relationship and creates invitation.
3. Recipient accepts.
4. Backend issues short-lived LiveKit tokens to authorized participants.
5. Participants join room; call state is updated.
6. Call ends and session is closed; no recording by default.

## 9. Non-functional requirements

### Security and privacy

- Every exposed application table must have RLS enabled and least-privilege grants.
- Private Storage buckets must use Storage RLS policies.
- Service-role/secret keys, OAuth client secrets, LiveKit secrets, and database credentials must remain server-side.
- Membership, roles, connections, conversation participation, attachment access, call permissions, and game state are server-authoritative.
- Private email/provider identifiers are not member-directory fields.
- Block/report/suspend functions are required for a community beta.
- Security claims must distinguish access control/TLS from end-to-end encryption.

### Reliability

- Message history must persist in PostgreSQL; Realtime is not the only store.
- Failures must show actionable UI states; retry operations must be safe/idempotent where possible.
- Free plans are prototype constraints, not uptime guarantees.
- Data export/backup/restore must be planned and tested before relying on real user data.

### Performance (initial targets, to be validated)

- Common navigation and member-directory queries should return a bounded result set and avoid unbounded downloads.
- Chat history loads in pages/cursors.
- Under ordinary broadband conditions, realtime text messages should generally appear within a couple of seconds; measure this with two real browser sessions and report observed results, not a blanket guarantee.
- Avoid loading original high-resolution media in lists; use thumbnails or bounded previews when supported.
- Monitor query latency, Realtime connections, storage, and egress.

### Compatibility

- Support modern desktop and mobile browsers: current stable Chrome, Edge, Firefox, and Safari at release time.
- Authentication, chat, and media must remain usable in a normal browser; do not require installing a native app.
- Voice/video later requires secure context (HTTPS), browser media permissions, and tested WebRTC behavior.

### Accessibility

- Keyboard navigation, visible focus, semantic HTML, appropriate contrast, labeled controls, readable errors, screen-reader announcements, and reduced-motion support.

### Maintainability

- Modular feature-based frontend structure.
- Version-controlled database migrations.
- Strict TypeScript and automated lint/type/test/build checks.
- Document provider setup, environment variables, security policies, and operational procedures.

## 10. Data and privacy requirements

- Collect only what is necessary: Auth identity, username, display name, optional avatar, community status, conversation records, and content the user chooses to share.
- Do not request phone numbers or upload contact lists.
- Do not expose email, OAuth provider subject, invitation secrets, or moderator notes to ordinary members.
- Explain who can see profiles, messages, group messages, posts, stories, and uploaded media.
- Define retention, export, account deletion, and treatment of messages authored by a deleted account before external beta.
- Admins do not automatically have a general-purpose private-message viewer.
- Do not record calls by default.
- Publish community rules and a privacy notice before broader release; get appropriate legal review for intended audience/jurisdiction rather than claiming legal compliance from this document.

## 11. Cost and hosting requirements

Initial target is $0/month by using current free tiers:

- GitHub for source control.
- Cloudflare Pages for static frontend hosting.
- Supabase Free for authentication, PostgreSQL, Realtime, Storage, and Edge Functions.
- LiveKit Build only when calling is introduced.

Free tiers have finite quotas and terms can change. As of the planning review, Supabase Free lists 500 MB database, 1 GB file storage, 5 GB egress, 2 million Realtime messages, 200 peak Realtime connections, and 500,000 Edge Function invocations; low-activity projects may pause. Cloudflare Pages Free lists 500 builds/month. LiveKit Build lists 5,000 WebRTC minutes, 100 concurrent participants, and 50 GB downstream transfer. Recheck provider dashboards before implementation/release.

No service may be upgraded, paid overage enabled, or billing activated without the owner's explicit approval. Add quota monitoring and feature limits. If the free tier cannot support safe use, reduce scope or pause rollout; do not silently incur costs.

## 12. Dependencies and assumptions

- Owner can create and control a GitHub account/repository, Cloudflare account, Supabase account/project, and Google Cloud OAuth client.
- Google OAuth provider setup and exact redirect URLs are required.
- Browser frontend is public static code; backend security must not rely on keeping frontend code secret.
- Supabase Auth, PostgreSQL RLS, Realtime, Storage, and Edge Functions are available on the selected plan as documented at implementation time.
- LiveKit is a later dependency and may require a separate account/configuration.
- Community size, final product name, detailed retention policy, group-size cap, moderation policy, and age/minor policy remain open.

## 13. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Scope too large for first release | Release a focused private messenger first; defer calls, stories, games |
| RLS misconfiguration | Design policies before UI; test unauthorized direct API access with multiple users |
| Free-tier limits | Set conservative media/call limits; monitor usage; no automatic paid overages |
| OAuth configuration difficulty | Document Google callback setup and test local/preview/production redirect behavior |
| Video call network variability | Managed WebRTC provider; staged testing; clear failure/reconnect states |
| Abuse in private community | Invitation controls, block/report, moderation, rate limits |
| Incomplete deletion/retention | Decide and test before external beta |
| Misleading security claims | Do not call MVP messages end-to-end encrypted |

## 14. Acceptance criteria for Private Messenger MVP (R2)

The release is accepted only when all of the following are true:

1. A user can sign in without a phone number.
2. User can choose a unique username.
3. Valid invitation path and no-code admin-approval path both work.
4. Only a provisioned admin can manage membership and invitations.
5. Pending/suspended users cannot access member resources.
6. Active members can search approved member profiles without seeing email/private IDs.
7. Connection request/accept/reject/block operations work.
8. Direct chats require accepted connection and respect block state.
9. Group chat is restricted to authorized participants.
10. Two separate browser sessions can exchange persistent realtime messages.
11. Private image uploads are accessible only to authorized participants.
12. Negative RLS and Storage tests pass.
13. No secret key is present in frontend build or Git repository.
14. Basic reports/moderation and account suspension are available.
15. Mobile and desktop browser checks pass.
16. Owner has reviewed quotas, retention, privacy notice, known limitations, and restore/export process.

## 15. Known limitations at MVP

- No application-level E2EE unless a later audited design is implemented.
- Google OAuth is the first sign-in option; additional identity methods may follow.
- No phone-number registration or phone lookup.
- No native app; web browser only.
- No guaranteed closed-browser push notifications unless later implemented.
- Voice/video calls, social feed/stories, and games are not part of R2.
- Free plans may pause, throttle, or impose finite quotas; there is no unlimited free production guarantee.
