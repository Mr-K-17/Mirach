# Phases — Private Community Communication App

> **Status:** Ordered implementation roadmap; no phase is marked complete until its exit criteria are tested.
> **Review date:** 3 November 2026.

## 1. Delivery strategy

Build a small, secure product in vertical slices. The first release is a private messenger for a small community. Calls, social feed/stories, and games are later releases. This sequencing reduces risk and allows real user feedback before expensive or complex infrastructure is introduced.

No calendar estimates are promised here. The owner is learning the stack and the work is best measured by working milestones and acceptance gates, not arbitrary dates.

### Release definitions

- **R0 — Foundation:** Repository, frontend shell, deployment pipeline, development backend, and documented environment setup.
- **R1 — Community access:** Login, profiles, invitation/request approval, and administrator controls.
- **R2 — Private Messenger MVP:** Connections, one-to-one/group text chat, realtime updates, private image sharing, basic block/report, and security tests.
- **R3 — Calling:** One-to-one voice and video; group calls only after stability and quota review.
- **R4 — Social:** Posts, comments, reactions, stories, audience controls, and moderation.
- **R5 — Games:** Turn-based multiplayer games, invitations, validated moves, and results.
- **R6 — Production hardening:** Tested recovery/backup, stronger observability, accessibility, privacy/retention, provider cost review, and any required legal review.

## 2. Phase 0 — Confirm scope and prepare the workspace

### Work

- Review and approve the six planning documents.
- Select a project name when ready; until then use a neutral placeholder.
- Confirm initial member cohort, invitation policy, directory visibility, username rules, group policy, retention, and moderation contact.
- Create a GitHub repository with a README, license decision, `.gitignore`, and branch protection/checks as appropriate.
- Create the React + TypeScript + Vite scaffold.
- Add Tailwind CSS and shared design tokens.
- Configure linting, formatting, type-checking, and a minimal test runner.
- Add `docs/` and ensure these six files are committed.
- Create `.env.example` with variable names only; never real values.
- Decide local Supabase CLI/Docker workflow or a dedicated development Supabase project.

### Exit criteria

- `npm install`, type-check, lint, test, and build succeed locally.
- No secrets or user data are in Git.
- The repository structure and README explain how to run the project.
- The owner can distinguish local, preview, and production environments.
- The six documents have consistent project decisions and known open questions.

## 3. Phase 1 — Frontend shell and deployment

### Work

- Implement app shell, route guard structure, responsive navigation, and error/loading boundaries.
- Configure Cloudflare Pages to deploy the Vite `dist` output from GitHub.
- Add SPA fallback if the router needs it.
- Configure Supabase development project URL and publishable key as frontend environment variables.
- Configure Supabase Auth site URL and exact allowed redirect URLs.
- Add basic connection/error handling and sign-out UI.
- Add a simple health/diagnostic page for development only; never expose secrets.

### Exit criteria

- A Git push triggers a successful preview/production deployment as configured.
- A direct refresh on a nested route works.
- Preview and production environments do not share production data accidentally.
- Frontend bundle inspection shows no secret/service-role/API credential.
- The app displays a clear backend unavailable state instead of crashing.

## 4. Phase 2 — Authentication and community membership (R1)

### Work

- Configure Google OAuth in Google Cloud and Supabase.
- Use Supabase Auth session and PKCE-appropriate client flow for the browser.
- Create `profiles`, `memberships`, `membership_requests`, `invitation_codes`, and `invitation_redemptions` migrations.
- Implement username normalization, validation, and unique index.
- Create safe first-admin bootstrap procedure outside public signup.
- Implement invitation creation/revocation with hashed code storage.
- Implement atomic invitation redemption with expiry, revocation, max-use, duplicate-use, and optional all-members-approval checks.
- Implement no-code membership request flow.
- Implement admin approve/reject/suspend/restore actions and audit events.
- Build pending/rejected/active onboarding routes.
- Ensure pending/suspended accounts cannot query community resources.

### Tests

- New Google identity, returning user, OAuth cancellation, invalid callback, username collision.
- Valid, invalid, expired, revoked, max-use, duplicate, and concurrent invitation redemption.
- No-code request, duplicate request, approval, rejection, suspension, restoration.
- Ordinary user cannot edit role, membership status, invitation, or moderation data.
- Pending user cannot list members or read application resources.

### Exit criteria

- All membership transitions are server-authorized and database-tested.
- An invite's usage limit cannot be bypassed by concurrent redemption.
- Only a provisioned administrator can administer members/invitations.
- Phone number is not requested or needed.
- Email is not exposed in public member data.

## 5. Phase 3 — Member directory and connections

### Work

- Create migrations for `connection_requests`, `connections`, and `blocked_users`.
- Implement search by normalized username/display name with bounded results and pagination.
- Implement send, accept, decline, cancel, remove connection, and block/unblock flows.
- Enforce active membership on both sides.
- Prevent self-requests, duplicate pending requests, and requests blocked in either relevant direction according to policy.
- Build member profile and connection-request inbox.
- Add report-user action and basic report queue if not already delivered in Phase 2 moderation scaffolding.

### Tests

- Two active users can request and accept.
- Pending/rejected/suspended users cannot connect.
- Blocked users cannot create or maintain prohibited interactions.
- A client cannot forge requester/recipient identity.
- Duplicate requests and race conditions are handled consistently.

### Exit criteria

- The member directory shows only approved profile fields.
- Connection state is authoritative in the database.
- A member cannot create a DM to an unconnected user unless an explicitly approved product policy allows it.

## 6. Phase 4 — Private messaging (R2 core)

### Work

- Create migrations for `conversations`, `conversation_members`, `messages`, and `notifications`.
- Add transactional direct-conversation creation to avoid duplicate pairs.
- Implement group creation and group-admin membership management.
- Implement text message send/edit/delete rules (if edit/delete are approved), pagination, and persistent history.
- Use Supabase Realtime Postgres Changes for durable message updates, filtered/secured through RLS.
- Add private Realtime Broadcast/Presence for typing and online hints only after authorization policies are in place.
- Add optimistic UI with retry and deduplication.
- Implement conversation last-read cursor; add more detailed receipts only if needed.
- Add in-app notifications for connection and chat events.
- Implement safe rendering of untrusted message text.

### Tests

- Direct chat requires accepted connection and no block.
- Group history and attachments are visible only to current/authorized participants; a departed/removed member loses access under the working default.
- Non-participant cannot query, insert, update, delete, or subscribe to the conversation.
- Sender cannot forge another sender ID.
- Message length/type/payload limits are enforced.
- Realtime event delivery is tested with two separate browser sessions.
- Duplicate send/retry does not create accidental duplicate messages.
- Revoked/suspended membership loses new access; open Realtime channels are handled.

### Exit criteria

- Two users on separate browsers can exchange persistent realtime messages.
- Group chat works with correct membership controls.
- RLS denies access to unrelated users even when they call the API directly.
- Chat history loads with bounded pagination and stable ordering.

## 7. Phase 5 — Private media sharing and R2 MVP hardening

### Work

- Create private storage buckets and Storage RLS policies.
- Implement secure image upload and authorized download.
- Add client-side file validation for user experience plus bucket/backend enforcement.
- Store object path and metadata in `message_attachments`; do not store permanent signed URLs.
- Add progress, cancel, failure, retry, preview, and deletion handling.
- Set conservative image limits (initial proposal: 10 MB) and measure actual storage/egress.
- Enable video uploads only after image sharing is stable and the owner approves quota/retention implications; initial proposal: 25 MB.
- Add block/report and account moderation flows needed for a community beta.
- Write privacy notice, community rules, data retention, and account deletion process before inviting people outside the trusted test group.
- Establish and test a backup/export and restore plan.

### Tests

- Sender/recipient and authorized group participants can access permitted attachments.
- Unrelated active members, pending users, signed-out visitors, and former group members cannot download files.
- Guessing object paths does not grant access.
- Wrong MIME type, oversized file, upload interruption, and expired signed URL are handled.
- Deleted message/account cleanup follows the documented retention rule.

### R2 release gate — Private Messenger MVP

R2 may be released to a small trusted group only when:

- Authentication, membership, connection, DM/group chat, private images, and basic moderation work end to end.
- RLS and Storage negative tests pass.
- Secrets are not in the frontend or Git.
- No critical/high unresolved security defect remains.
- Quota monitoring and a data export/restore procedure exist.
- The interface is usable on mobile and desktop browsers.
- Known non-features (no E2EE, no calls yet, no stories/games yet) are clearly communicated.

## 8. Phase 6 — Voice and video calling (R3)

### Work

- Create LiveKit project only when this phase is approved.
- Store LiveKit API key/secret in Supabase Edge Function secrets.
- Implement `call_sessions` and participant state.
- Create authenticated call invitation/accept/decline/cancel/timeout/end operations.
- Implement Edge Function that validates membership, connection, blocks, and invitation before generating a short-lived LiveKit token.
- Implement one-to-one voice calls first.
- Add video and browser device controls.
- Add reconnect, device-unavailable, permission-denied, network-failure, and busy states.
- Add group calls only after separate participant/cost tests.
- Add usage monitoring and safe stop/disable behavior at quota threshold.

### Tests and exit criteria

- Only intended participants can enter the room.
- Tokens are short-lived and API secrets never reach the client.
- Call invitations expire and state transitions cannot be forged.
- Test across different browsers, devices, Wi-Fi/mobile networks, and camera/microphone permission settings.
- Calls work within the actual provider free allowance; no paid overage is enabled without approval.
- No call recording is enabled by default.

## 9. Phase 7 — Social feed and stories (R4)

### Work

- Decide content audience rules: connections-only or all active community members.
- Create posts, post media, comments, reactions, stories, and story-view schema/migrations.
- Implement feed pagination, create/edit/delete, comments, reactions, reporting, blocking, and audience enforcement.
- Implement server-side story expiry and cleanup process.
- Keep private media buckets and apply the audience rule to attachment access.
- Add moderation and rate limits to reduce spam.

### Tests and exit criteria

- Content is visible only to the chosen audience.
- Blocked users cannot see prohibited content or interact.
- Expired stories cannot be retrieved by direct API or object path.
- Reports are visible only to authorized reviewers.
- Upload/storage/egress quota behavior is measured before broad release.

## 10. Phase 8 — Games (R5)

### Work

- Define a generic game-session state model.
- Implement game invitations and private rooms.
- Deliver Tic-tac-toe first, then Connect Four or a quiz.
- Validate all moves and turn transitions in trusted database/function logic.
- Persist state/results and broadcast only committed updates.
- Add reconnect/resume and forfeit/timeout rules.
- Add chess only after the framework and test suite prove reusable.
- Consider a dedicated authoritative server only for future fast-action games.

### Tests and exit criteria

- Only invited players can join.
- Invalid, out-of-turn, duplicate, and replayed moves are rejected.
- Client cannot set winner or score.
- Concurrent move submissions resolve deterministically.
- Game session cannot be manipulated by editing browser state.

## 11. Phase 9 — Production hardening and advanced capabilities (R6)

### Work

- Recheck all provider plans, quotas, privacy terms, data processing terms, and regional needs.
- Add stronger monitoring and abuse/rate-limit controls.
- Test backups, restore, data export, account deletion, and incident response.
- Run dependency and security review; address high/critical vulnerabilities.
- Perform multi-user and limited load tests.
- Conduct accessibility review and fix blockers.
- Finalize age/minor policy, community rules, privacy notice, terms, and applicable legal review before public or broader use.
- Assess whether a paid plan is required for uptime, backups, traffic, storage, calls, or support. Obtain explicit approval before any cost.
- Evaluate E2EE using a vetted protocol/library and separate key-management architecture; no custom cryptography.
- Consider PWA/native clients only through a new approved scope and architecture update.

### Exit criteria

- Owner has reviewed operational risks and provider costs.
- Recovery procedures have been exercised.
- No unresolved critical/high security defect remains.
- Privacy, retention, moderation, and account deletion behavior are documented and tested.
- Launch limitations and support process are communicated to members.

## 12. Definition of Done for every feature

A feature is not complete merely because the UI appears. It is done only when:

- Requirements and acceptance criteria are met.
- Loading, success, empty, error, offline, and permission-denied states are handled.
- Backend authorization is enforced; no security depends only on hidden controls.
- Relevant unit, integration, RLS, and browser tests pass.
- Mobile and desktop behavior is checked.
- Accessibility basics are satisfied.
- Logs do not expose private content or credentials.
- Documentation, migration files, and environment examples are updated.
- No real secrets or user data are committed.
- The owner has been told what was tested and what remains unverified.

## 13. Main risks and mitigations

| Risk | Mitigation |
|---|---|
| Free storage/egress exhausted by photos/videos | Conservative limits, image-first release, quota monitoring, cleanup and explicit upgrade approval |
| Supabase Free project pauses | Keep active for prototype, warn owner, do not promise uptime; move to paid only with approval |
| RLS mistakes expose messages/media | Define policies before UI, negative tests with multiple identities, review grants and policies together |
| Invitation-code abuse | Hash codes, atomic redemption, limits, rate limiting, revocation |
| OAuth redirect/configuration mistakes | Exact redirect allowlist, separate environments, verify callback flow and session behavior |
| Video calls unreliable on restrictive networks | LiveKit managed service, TURN/network testing, graceful failure states, no universal connectivity promise |
| Feature scope expands before messenger is complete | Phase gates; no social/games/calls until R2 is accepted |
| Unclear retention or deletion | Owner decision and tested deletion/export workflow before external beta |
| Secrets committed or exposed | `.env.example` only, secret scanning, server-only storage, rotate compromised keys |
| App looks complete but is insecure | Treat backend tests, not screenshots, as release gates |

## 14. Suggested first work session

Do only Phase 0 and the beginning of Phase 1:

1. Create the repository and `docs/` folder.
2. Add these six documents.
3. Scaffold React + TypeScript + Vite.
4. Add lint, type-check, and test scripts.
5. Deploy a blank static shell to Cloudflare Pages.
6. Create a development Supabase project and configure local redirect URLs.
7. Stop before implementing messaging until membership/schema/RLS migrations have been reviewed.
