# Rules — Development, Security, and AI-Agent Operating Rules

> **Purpose:** Binding engineering guardrails for the owner, developers, and coding agents.
>
> **Review date:** 3 November 2026.

## 1. Read and follow the project documents

Before planning or changing code, read:

1. `Rules.md` — these operating and security rules.
2. `PRD.md` — what the product must do and what is out of scope.
3. `Architecture.md` — technology, data model, trust boundaries, and service choices.
4. `Design.md` — screens, flows, accessibility, and UI behavior.
5. `Phases.md` — delivery order and release gates.
6. `Memory.md` — owner decisions, current status, unresolved questions, and hand-off context.

### Document precedence

- Security and privacy guardrails in `Rules.md` cannot be weakened by a feature request without an explicit owner decision and a security review.
- `PRD.md` controls product scope and acceptance criteria.
- `Architecture.md` controls technical boundaries and data/security design.
- `Design.md` controls interaction and visual behavior.
- `Phases.md` controls implementation order and exit gates.
- `Memory.md` records current owner decisions and hand-off facts; it must be updated when decisions change.

If documents conflict, do not silently choose one. Explain the conflict, propose a minimal change, and update the affected documents before implementing the conflicting feature.

## 2. General development rules

- Work in small, reviewable changes. Prefer one feature or migration set per task.
- Explain the intended change and affected files before making broad edits.
- Do not rewrite the whole application to fix a localized issue.
- Do not delete, rename, move, or overwrite user files without confirming the exact target and impact.
- Inspect the repository and existing code before assuming file paths, branch names, package manager, framework version, or implementation state.
- Preserve working behavior unless the requirement explicitly changes it.
- Do not fabricate test results, deployments, account setup, security reviews, or completion status.
- Report what changed, what tests actually ran, what failed, and what remains unverified.
- Do not promise background work or future delivery; complete the available task in the current session or describe the blocker.

## 3. Scope control

- Build the first Private Messenger MVP before social feeds, stories, games, or calling.
- Do not add native Android/iOS, PWA-specific behavior, payments, advertising, public registration, or a custom server without an approved scope change.
- Do not introduce additional cloud providers or paid services just because they are convenient.
- Before using a new provider, plugin, library, or API, explain the capability, data shared, free-tier limits, lock-in, and fallback.
- Recheck current provider docs/pricing at the time of implementation; values in planning documents are snapshots, not permanent promises.
- Do not enable paid usage, automatic overages, or a billing upgrade without the owner's explicit approval.

## 4. Secrets and configuration

- Never commit `.env`, `.env.local`, OAuth client secrets, Supabase secret/service-role keys, database passwords, LiveKit API secrets, SMTP credentials, signing keys, raw invitation codes, access tokens, refresh tokens, or real user data.
- Commit `.env.example` with variable names and safe placeholders only.
- Frontend `VITE_*` variables are public because they are compiled into browser assets. They may contain the Supabase URL and publishable/anon key only; they must never contain a service secret.
- Store backend secrets in Supabase Edge Function secrets or an approved server secret store.
- If a secret is exposed, stop using it, rotate/revoke it, inspect logs/access, and report the incident. Deleting it from the latest commit is not enough if it exists in Git history.
- Never paste secrets into prompts, chat, issue trackers, screenshots, or documentation.
- Use least-privilege credentials and separate development and production keys/projects.

## 5. Authentication and identity rules

- No phone number is required or collected for authentication in the initial design.
- Use Supabase Auth and Google OAuth first, as approved in the planning baseline.
- Do not ask users to type a Google password into this application.
- Treat authenticated identity, community membership, connection status, and conversation membership as separate states.
- Use the authenticated JWT identity (`auth.uid()` or the verified server-side user claims) as the source of user identity.
- Never trust a client-supplied `user_id`, `sender_id`, `role`, `membership_status`, `is_admin`, or provider subject to prove who is acting.
- Do not expose Auth email or OAuth subject in the public profile/member directory.
- Do not create an admin role during ordinary sign-up. Bootstrap the initial admin using a trusted, documented procedure.
- Email/password login may be added only with verified SMTP, email confirmation, password reset, rate limiting, abuse controls, and tests. Any separate Supabase confirmation-email flow must not be enabled for real users until custom SMTP is configured and tested.

## 6. Authorization and database rules

- Enable RLS on every table exposed through Supabase APIs.
- Review database grants and RLS policies together. Policies do not automatically remove excessive table privileges.
- Default-deny is preferred. Grant only the operations needed by each role.
- Use database policies for row-level privacy; do not rely on frontend filtering, hidden buttons, route guards, or hard-to-guess UUIDs as authorization.
- Pending/rejected/suspended users must be denied member-only data and operations.
- Direct conversations require the documented connection rule and no block.
- Group conversations require current participant membership. Under the working default, leaving or removal revokes access to both new and historical group messages/attachments; database records remain for other authorized participants according to retention policy. Owner confirmation is required before production.
- Private media requires owner/conversation authorization.
- Ordinary users cannot update membership status, role, invitation usage, moderator assignment, or audit records.
- Ensure the sender is a current participant and derive sender identity from the JWT.
- Validate state transitions and enforce foreign keys, unique constraints, check constraints, and transaction boundaries in PostgreSQL.
- Use indexes for RLS joins and common lookup/sort columns; inspect query plans when performance becomes a concern.
- Do not expose internal schemas such as Supabase `auth`, `storage`, or `realtime` for arbitrary mutation. Use supported APIs and documented policies.

## 7. Invitation and administrator rules

- Store invitation hashes, not raw invitation codes.
- The raw code is displayed/copyable only at creation and must not be logged.
- Redemption must be atomic and resistant to concurrent use-limit bypass.
- Enforce expiry, revocation, max use, duplicate redemption, and any scope/email constraints in trusted backend logic.
- Rate-limit redemption attempts.
- Every privileged action must re-check administrator/moderator permission server-side.
- Record administrative actions in an audit log without storing secrets or private message bodies.
- Do not build a hidden admin backdoor to private conversations.
- Admin status alone does not grant permission to read all private messages or files.

## 8. Messaging and Realtime rules

- PostgreSQL is the durable source of truth for messages; Realtime is a delivery mechanism.
- Use authorized database inserts/updates and RLS-protected Postgres Changes for durable message events.
- Private Broadcast/Presence channels must be explicitly configured as private and protected by authorization policies.
- Do not treat presence/online indicators as proof of availability or security status.
- Use cursor pagination; never download a complete conversation without a limit.
- Validate message type, text length, attachment count, and attachment size.
- Make retries/idempotency safe so repeated sends do not create unintended duplicate messages.
- Render user text as text; do not inject arbitrary message HTML.
- Never log message bodies, attachment contents, private signed URLs, or access tokens.
- Re-check behavior after connection removal, blocking, member suspension, or conversation removal, including already-open Realtime channels.

## 9. Storage and media rules

- Use private Storage buckets for member-only media by default.
- Never place private conversations/media in a public bucket as a shortcut.
- Storage RLS must verify active membership and the relevant owner/conversation authorization.
- Store object paths and safe metadata in the database, not long-lived signed URLs.
- Use short-lived signed URLs or authenticated downloads after an authorization check.
- Enforce MIME type and file-size restrictions at storage/backend level; client-side validation is only a usability feature.
- Use random/opaque object names; never trust a client filename or object path as permission.
- Do not execute or render user-uploaded files as application code.
- Define file deletion, orphan cleanup, account deletion, and retention behavior.
- Use Supabase Storage APIs; do not directly mutate internal `storage` tables.
- Do not enable video uploads or large files without checking quotas and egress implications.

## 10. Calling and LiveKit rules

- Calling is a later phase; do not implement it before the messenger release gate.
- LiveKit API secrets remain server-side.
- The backend must authorize every participant and generate short-lived, least-privileged tokens.
- Never let a client choose an arbitrary privileged room or mint its own token.
- Validate call invitation, acceptance, participant status, connection/block rules, and timeout state.
- Handle denied camera/microphone permissions and browser/network errors honestly.
- Do not record calls by default.
- Do not claim E2EE for calls unless a separate, verified end-to-end media encryption design is active.
- Monitor free usage; no paid overages or upgrades without explicit owner approval.

## 11. Games rules

- Start with turn-based games.
- Server/database logic is authoritative for game state, legal moves, turn order, and results.
- A browser cannot declare itself the winner or directly update scores.
- Validate player membership, game status, legal move, turn order, and replay/duplicate actions.
- Use transaction/locking or another correct concurrency method so simultaneous moves cannot corrupt state.
- Do not add gambling, cash stakes, or paid random rewards.
- Real-time action games require a separate design and an authoritative server.

## 12. Frontend, code quality, and dependencies

- Use TypeScript strict mode where practical; avoid `any` unless justified and localized.
- Keep components small and feature-oriented; avoid one giant component or file.
- Separate UI, data access, validation, and trusted server operations.
- Centralize route guards and session state, but remember they are UX controls rather than authorization.
- Use accessible semantic controls, form labels, focus states, keyboard interaction, and readable error messages.
- Handle loading, empty, success, error, offline, retry, and access-denied states.
- Avoid excessive dependencies. Before adding a package, check maintenance, license, bundle impact, known vulnerabilities, and whether existing tools suffice.
- Commit the package lockfile and use reproducible installs.
- Run lint, type-check, tests, and production build for relevant changes.
- Do not suppress TypeScript/ESLint errors to make CI green without documenting the reason.
- Do not store secrets or sensitive personal data in local storage unless the security model explicitly requires and justifies it. Follow Supabase's supported session storage guidance.

## 13. Database migration rules

- All schema changes must be represented in version-controlled migrations.
- Never rely on manual dashboard edits as the only record of schema changes.
- Review migrations for grants, RLS, constraints, indexes, function search paths, and rollback/recovery implications.
- Test migrations against a disposable/local development database before production.
- Do not edit Supabase-managed internal schemas.
- Make migrations idempotent only when the migration framework requires it; do not hide a failed partial migration with broad exception handling.
- Back up/export important data before destructive migrations and verify restore capability.
- Prefer additive changes and explicit data migration steps over dropping columns or tables.

## 14. Testing requirements

Every feature must have tests appropriate to its risk:

- Unit tests for validation, state transitions, and business rules.
- Integration tests for Supabase queries/functions and database constraints.
- RLS tests for allowed and denied paths.
- Storage policy tests for private media.
- Browser/E2E tests with at least two independent users for connection/chat workflows.
- Regression tests for invitation concurrency, duplicate messages, blocked users, suspension, and removed group members.
- Manual tests on mobile and desktop browsers for user-facing flows.
- Security review before any wider release.

For privacy-sensitive features, a positive test is insufficient. Include negative tests proving that a different user cannot read, write, subscribe, or download.

## 15. Logging, monitoring, and user data

- Log operational metadata only: request/correlation ID, action category, error type, and timing where useful.
- Do not log message bodies, private media, authentication tokens, raw invite codes, passwords, OAuth secrets, private emails, or signed URLs.
- Keep audit events separate from application chat data.
- Limit retention of logs and user data to a documented policy.
- Provide a safe user-facing error message; keep detailed stack traces in protected development/operations logs only.
- Monitor free-tier quotas and pause/limit features before quota exhaustion.
- Maintain a tested export/restore procedure; do not assume a free plan supplies production-grade backups.

## 16. Privacy, retention, and public launch

- Collect the minimum information needed for community functionality.
- Do not upload phone contacts or request phone numbers.
- Make audience and visibility clear before users share content.
- Define account deletion, message retention, attachment cleanup, moderation evidence retention, and export before external beta.
- Do not silently change private messages into community-visible content.
- Do not invite minors or claim legal compliance without an explicit age policy and suitable jurisdiction-specific review.
- Publish community rules, privacy notice, and terms appropriate to the launch before broad access.

## 17. Git and workspace safety

- Check `git status`, current branch, remotes, and repository size before large operations.
- Never run `git push --force`, history rewrite, mass deletion, `git clean -fdx`, or destructive reset without explicit owner permission and a verified backup/recovery path.
- Do not move or delete project directories to free disk space without first identifying exact data and verifying a copy.
- Avoid committing datasets, generated binaries, build output, secrets, user uploads, or local database dumps unless explicitly intended and safe.
- Use `.gitignore` for `.env*` (except `.env.example`), `node_modules/`, `dist/`, test artifacts, local Supabase data, and secrets.
- Do not overwrite an existing user-authored file with generated content without checking it first.

## 18. Completion report format

At the end of each implementation task, report:

1. **Changed:** files, migrations, functions, and behavior changed.
2. **Why:** requirement/phase satisfied.
3. **Tests run:** exact commands and pass/fail outcomes; do not claim tests that were not run.
4. **Security impact:** relevant RLS, secrets, Storage, auth, and role behavior.
5. **Not done / risks:** blockers, known limitations, quota/cost effects, and unverified behavior.
6. **Next approved step:** one logical action that follows the phase plan.

Never say “production ready,” “secure,” “fully encrypted,” “unlimited free,” or “completed” as a blanket claim without evidence and a defined scope.
