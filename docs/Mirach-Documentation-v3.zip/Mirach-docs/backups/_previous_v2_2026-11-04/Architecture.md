# Architecture — Mirach

> **Status:** Revised planning baseline (v2). Nothing described here is confirmed as built.
> **Last reviewed:** 4 November 2026 (Asia/Kolkata).
> **Authority:** Controls technical boundaries, data model and security design. See `Rules.md` §1 for document precedence.
> **Evidence:** Provider facts are dated snapshots listed in `SOURCE_REGISTER.md`. Anything not verified is labelled **UNVERIFIED**.

## 1. Goals and constraints

Mirach is a private, browser-based community messenger with later calls, games and social features, for a small invited community (initially India-based).

**Non-negotiable constraints (owner decisions, see `Memory.md` §2):** browser web app; free-first budget; invitation-code **and** admin-approved registration; no phone numbers; small private community; incremental delivery.

**Architectural goals, in priority order:** security → correctness → reliability → maintainability → user experience → cost → scalability.

**Design stance:** use managed services; keep trusted logic in PostgreSQL (RLS + narrowly scoped functions) and a few Edge Functions; no custom server; keep every provider replaceable behind a thin module boundary.

## 2. Final technology stack

| Component | Alternatives considered | **Recommended** | Reason | Free-tier limits (checked 4 Nov 2026) |
|---|---|---|---|---|
| Frontend framework | Next.js; SvelteKit; plain React | **React + TypeScript (strict) + Vite SPA** | Whole app sits behind login, so SSR/SEO adds no value; Next.js adds a server runtime and a second trust boundary; static output deploys anywhere | n/a |
| Routing / data | — | **React Router (SPA mode), TanStack Query, Zod, React Hook Form** | Small, mainstream, testable; Zod schemas shared between forms and RPC input checks | n/a |
| Styling | CSS modules; component kits | **Tailwind CSS + design tokens** (`Design.md` §2) | Fast, consistent; accessible primitives added deliberately | n/a |
| Auth | Firebase Auth; Appwrite Auth; Clerk | **Supabase Auth** — Google OAuth (PKCE) at MVP; email OTP added before inviting members without Google; passkeys evaluated later | Same system as the database, so RLS uses `auth.uid()`; no SMTP/domain needed for Google sign-in | 50,000 MAU; custom SMTP allowed on Free; default SMTP only emails project-team addresses at ~2/hour |
| Database | Firestore; Appwrite DB | **Supabase PostgreSQL** | Relational integrity, transactions, constraints, RLS — required for invitation atomicity, pair uniqueness, membership rules | 500 MB/project; shared CPU, 500 MB RAM; **no automatic backups**; pauses after 1 week inactivity; 2 active projects |
| Realtime | Postgres Changes; custom WebSocket | **Supabase Realtime Broadcast (private channels), fed by database triggers**; Presence only per open conversation | Supabase docs recommend Broadcast over Postgres Changes for scale and security | 200 peak connections; 2 M messages/month; 256 KB max message |
| Media storage | Firebase Storage; Cloudflare R2; Backblaze B2 | **Supabase Storage, private buckets** (R2 is a documented escape hatch) | Policy-controlled, same auth; Firebase Storage needs a billing plan since Feb 2026 (secondary sources) | 1 GB; 50 MB max upload; 5 GB cached egress; no image transformations |
| Trusted logic | Custom Node server | **SQL RPCs (`SECURITY DEFINER`) + Supabase Edge Functions** | RPCs for atomic DB rules; Edge Functions only where secrets, Admin API or Storage API are needed | 500,000 Edge invocations/month |
| Frontend hosting | GitHub Pages; Cloudflare Pages; Vercel; Netlify | **Cloudflare Workers Static Assets** (Pages acceptable fallback) | Free static delivery, custom response headers (CSP), Git deploys; Cloudflare directs new projects to Workers (`DECISIONS.md` ADR-002) | Pages: 500 builds/month, 1 concurrent, 20 min timeout, 20,000 files, 25 MiB/file. Workers Builds quotas **UNVERIFIED** |
| Source control / CI | GitLab | **GitHub (private repo) + GitHub Actions** | Owner already uses it | Verify Actions minutes at setup (**UNVERIFIED**) |
| Voice/video | Native WebRTC; Daily; 100ms; Agora | **LiveKit Cloud (Build plan), later phase** | Managed SFU + TURN; open-source server gives an exit path; Build plan is a hard cap (no surprise bills) | 5,000 WebRTC minutes; 100 concurrent participants; 50 GB downstream |
| Transactional email (only when email OTP is added) | Resend; Brevo; Amazon SES | **Resend or Brevo via Supabase custom SMTP** — chosen at that time | Needed for email OTP; requires an owned sending domain (a cost) | Resend 3,000/month (100/day); Brevo 300/day (secondary sources) |
| Tests | — | **Vitest, React Testing Library, Playwright, pgTAP via `supabase test db`** | Unit, UI, two-user browser and database/RLS tests | Free/open source |

**Optional (not required for MVP):** LiveKit; custom SMTP; Cloudflare R2; PWA/push; custom domain.
**Highest lock-in:** Supabase Auth user IDs and RLS policies, Realtime private-channel policies, Edge Functions (Deno). Mitigation: schema and policies live in version-controlled SQL migrations; frontend data access is wrapped in `src/lib/api/*`; Postgres is portable.
**Rejected:** Next.js (no SSR need); Firebase (relational ACLs poor; Storage needs billing); Appwrite (Free caps 2 GB storage / 5 GB bandwidth and pauses idle projects; smaller ecosystem; database/permission model not evaluated in depth); GitHub Pages as host (§15.1); native WebRTC (needs TURN, signaling, SFU).

## 3. System architecture

```mermaid
flowchart TB
  U["Member browser<br/>React SPA"] -->|HTTPS| CF["Cloudflare Workers Static Assets<br/>static files + security headers"]
  U -->|"supabase-js, user JWT"| API["Supabase API gateway"]
  subgraph SB["Supabase project"]
    API --> AUTH["Auth<br/>Google OAuth, email OTP later"]
    API --> DB[("PostgreSQL<br/>RLS + SECURITY DEFINER RPCs")]
    API --> ST["Storage<br/>private buckets"]
    API --> EF["Edge Functions"]
    DB -->|"trigger: realtime.send, ids only"| RT["Realtime<br/>private Broadcast channels"]
  end
  RT -->|WebSocket| U
  EF -->|"Admin API / service key"| AUTH
  EF -->|"signed access token (R4)"| LK["LiveKit Cloud"]
  U <-->|"WebRTC media (R4)"| LK
  GH["GitHub repo + Actions"] -->|deploy| CF
  GH -->|"migrations (reviewed)"| DB
```

### 3.1 Trust boundaries and responsibilities

| Layer | May do | Must never do |
|---|---|---|
| **Browser** (untrusted) | Render UI; validate for UX; call `supabase-js` with the user's JWT; read rows allowed by RLS; call RPCs; upload to Storage within policy; compress images and strip EXIF before upload | Hold secrets; decide authorization; set `sender_id`, role, status, counters, winners |
| **PostgreSQL** (authoritative) | RLS on every exposed table; constraints; transactions; all membership/connection/conversation rules; audit writes | Trust any client-supplied identity or role |
| **RPCs** (`SECURITY DEFINER`, `set search_path = ''`) | Atomic multi-row operations (redeem invite, send message, create DM) | Be callable by `anon`; accept a `user_id` parameter as identity |
| **Edge Functions** | Operations needing secrets/Admin API/Storage API: account deletion, data export, storage cleanup, LiveKit tokens, scheduled jobs | Disable JWT verification for user-facing functions; log secrets/bodies |
| **Cloudflare** | Serve static assets; set security headers | Hold user data or secrets |
| **LiveKit** | Carry call media for tokens we issue | Decide who may call whom |

The frontend is public static code. Security never depends on hiding it.

## 4. Authentication architecture

Authentication, membership, connection and conversation membership are four separate states (ADR-005):

1. **Authenticated identity** — Supabase Auth session (JWT).
2. **Community membership** — `memberships.status` (`pending | active | rejected | suspended | left`).
3. **Connection** — accepted row in `connections`.
4. **Conversation membership** — active row in `conversation_members`.

### 4.1 Authentication methods (decision)

| Method | SMTP/domain | Security | Verdict |
|---|---|---|---|
| **Google OAuth** | none | Strong; Google handles recovery; verified-email claim | **MVP default** |
| **Email OTP (6-digit code)** | custom SMTP + owned domain | Good; no password storage; rate-limit dependent | **Second method; required before inviting members without Google** |
| Magic link | custom SMTP + domain | Email scanners can consume single-use links | Prefer OTP |
| Email + password | custom SMTP + domain | Needs reset flow; breached-password check is not on Supabase Free | Rejected for now |
| Passkeys | none beyond first sign-in | Phishing-resistant; Supabase passkeys are **beta/experimental** (May 2026) and need a linked email first | Re-evaluate at R7 |
| Other OAuth (GitHub, Discord, Apple) | none | Excludes non-developers; Apple has paid-program friction (**UNVERIFIED**) | Not planned |
| Username-only | n/a | Not authentication | Rejected |

A username is an **application identity**. An invitation code is an **enrollment credential**, not proof of identity. Neither authenticates anyone.

**Trade-off recorded:** Google-only excludes people without a Google account. Email OTP removes that limitation but costs a domain and SMTP setup, so it is gated on owner approval (`DECISIONS.md` OD-03).

### 4.2 Client and session rules

- Browser OAuth uses `flowType: 'pkce'`. Redirect allow-list contains exact URLs only (local, preview, production); no wildcards in production.
- Do not add a separate app-level email-confirmation step unless custom SMTP is configured and tested.
- Verify the provider's email-verified claim before creating the profile. Email and provider subject are never exposed through any API readable by members.
- Sessions: default Supabase JWT expiry (do not extend). **Authorization never reads status or role from JWT claims**: RLS and RPCs look up `memberships` on every call, so suspension takes effect immediately even for an unexpired token. Suspension also calls the Admin API to ban the auth user (stops refresh) and signs out all sessions.
- "Sign out of all devices" uses global sign-out (`scope: 'global'`).
- Test automatic identity linking (same verified email across Google and email OTP) before enabling the second method (**UNVERIFIED** behavior; treat as an account-takeover test case).

### 4.3 Onboarding flow

1. Sign in with Google (no phone field anywhere).
2. A trigger on `auth.users` inserts a minimal `profiles` row (`status = 'incomplete'`) and **no** `memberships` row.
3. User picks username and display name (`claim_username` RPC: normalization, reserved names, uniqueness).
4. User chooses a path:
   - **Has code:** `redeem_invitation(code)`. Valid code → `memberships.status = 'active'`, unless `community_settings.require_admin_approval_for_all` → `pending`.
   - **No code:** `request_membership(message)` → `pending` + `membership_requests` row.
5. Admin approves/rejects via `review_membership`. Rejected users see a neutral screen; they may re-apply after a cooldown (default 30 days).
6. Suspension/removal: `set_member_status` (see §8).

Pending profiles that never complete onboarding are purged after 30 days (scheduled function); usernames of pending users are reserved but never shown in the directory.

### 4.4 Invitation invariants

- Codes are random, ≥ 80 bits (e.g. 20 hex characters shown in groups); displayed to the admin **once**; only `sha256(code)` stored (a slow hash is unnecessary for high-entropy random codes).
- Fields: `expires_at` (default 7 days), `max_uses` (default 1), `uses_count`, `revoked_at`, `created_by`, `note`. Invitations can only grant `member`, never an elevated role.
- Redemption is one SQL transaction: lock the invitation row, validate (not revoked, not expired, `uses_count < max_uses`), insert `invitation_redemptions` (unique `(invitation_id, user_id)`), increment `uses_count`, set membership, write audit. Concurrent redemption cannot exceed `max_uses`.
- Throttle: ≤ 5 failed attempts per user per hour (`invitation_attempts`); responses are generic (never "almost correct", never distinguishing expired from invalid).
- Revoking a code blocks future use; already-admitted members stay active (admin may suspend separately).

### 4.5 Roles and bootstrap

Roles live in `memberships.role`: `owner > admin > moderator > member`. Ordinary clients have no write access to that table.

- **Owner bootstrap (once):** the owner signs in with Google normally, then runs a documented SQL snippet (SQL editor or a one-off migration committed with the real user ID **not** committed to Git; supply it as a parameter) that calls `app.bootstrap_owner(user_id)`. The function refuses to run if any owner exists.
- Invariants enforced in the database: at least one owner always exists; no one can change their own role; admins cannot act on owners; only owners create admins.
- **Recovery:** if the owner loses Google access, recover through the Google account first; the break-glass path is the Supabase dashboard SQL editor (owner of the Supabase organization) calling the same function after clearing the owner row under a written, audited procedure (`Rules.md` §11).

### 4.6 Account deletion and suspension

- Deletion request → 14-day grace → `delete_account` Edge Function: tombstones the profile (`display_name = 'Deleted member'`, avatar removed, username released), ends all memberships, deletes the member's uploaded objects, deletes the auth user. Messages already delivered remain for other participants as messages from "Deleted member" (decision: retention in `DECISIONS.md` OD-06).
- Suspended users keep their data but lose all access; their messages remain visible to others.

## 5. Membership and authorization model summary

| Resource | Signed out | Incomplete/Pending/Rejected | Active member | Moderator | Admin / Owner |
|---|:-:|:-:|:-:|:-:|:-:|
| Landing, sign-in | ✔ | ✔ | ✔ | ✔ | ✔ |
| Own profile & request status | ✘ | ✔ (limited) | ✔ | ✔ | ✔ |
| Member directory | ✘ | ✘ | ✔ (allowed fields) | ✔ | ✔ |
| Connections | ✘ | ✘ | own only | own only | own only |
| DM / group messages | ✘ | ✘ | participants only | participants only | participants only (**no** role-based access) |
| Media | ✘ | ✘ | participants only | participants only | participants only |
| Reports | ✘ | ✘ | submit; read own status | review queue + evidence snapshots | review queue + evidence snapshots |
| Invitations, members, settings | ✘ | ✘ | ✘ | ✘ | ✔ (owner-only: roles, last-owner rules) |
| Audit log | ✘ | ✘ | ✘ | ✘ | ✔ read-only (viewer UI ships in R3; entries are written from R1) |

**No role can read private conversation content directly.** Moderation works from evidence snapshots attached to a report (§6.4).

## 6. Data architecture

Conventions: UUID primary keys (`gen_random_uuid()`), `timestamptz` in UTC, explicit FKs, check constraints for enums (or Postgres enums), snake_case, every FK column indexed, migrations are the single source of truth. Tables live in `public` but have **grants revoked from `anon` and `authenticated` by default**; each table is then granted only what the client needs (usually `SELECT` under RLS). Writes go through RPCs.

**Member identifier:** `profiles.user_id` equals `auth.users.id`. It is deliberately **not** a foreign key with a delete action, so a deleted auth user leaves a tombstone profile and messages keep a valid sender (`DECISIONS.md` ADR-012). A trigger creates the profile on sign-up.

### 6.1 Entity relationship diagram (core relationships)

Helper tables without relationships to draw (`reserved_usernames`, `invitation_attempts`, `rate_limits`, `account_deletion_requests`) are listed in §6.2. Later-phase tables are added to this diagram when their phase is approved.

```mermaid
erDiagram
  PROFILES ||--o| MEMBERSHIPS : has
  PROFILES ||--o{ MEMBERSHIP_REQUESTS : submits
  INVITATIONS ||--o{ INVITATION_REDEMPTIONS : redeemed_in
  PROFILES ||--o{ INVITATION_REDEMPTIONS : redeems
  PROFILES ||--o{ INVITATIONS : creates
  PROFILES ||--o{ CONNECTIONS : participates
  PROFILES ||--o{ BLOCKS : blocks
  CONVERSATIONS ||--o{ CONVERSATION_MEMBERS : has
  PROFILES ||--o{ CONVERSATION_MEMBERS : joins
  CONVERSATIONS ||--o{ MESSAGES : contains
  PROFILES ||--o{ MESSAGES : sends
  MESSAGES ||--o{ MESSAGE_ATTACHMENTS : has
  MESSAGES ||--o{ MESSAGE_REACTIONS : receives
  PROFILES ||--o{ NOTIFICATIONS : receives
  PROFILES ||--o{ REPORTS : files
  PROFILES ||--o{ ADMIN_AUDIT_LOG : acts_in
  COMMUNITY_SETTINGS {
    int id
  }
```

### 6.2 Table catalogue

| Table | Key columns and constraints | Delete behavior / retention |
|---|---|---|
| `profiles` | `user_id` PK; `username` (display form), `username_normalized` **unique**, `display_name`, `avatar_path`, `bio` (≤ 160), `discoverability` (`members` \| `exact_username`), `username_changed_at`, `deleted_at`, timestamps. Normalization: lowercase `[a-z0-9_]`, 3–20 chars, no leading/trailing `_` | Tombstoned, never hard-deleted |
| `reserved_usernames` | `name` PK (admin, support, mirach, moderator, system, root, owner, …) | static |
| `community_settings` | single row (`id = 1` check); `registration_open`, `require_admin_approval_for_all`, `max_group_size` (default 50), `invite_default_expiry_days`, `reapply_cooldown_days` | n/a |
| `memberships` | `user_id` PK/FK `profiles`; `status`, `role`, `joined_at`, `reviewed_by`, `reviewed_at`, `reason_code` (no free-text moderator notes visible to users) | Kept after leaving |
| `membership_requests` | `id`; `user_id`; `message` (≤ 500); `status` (`pending|approved|rejected`); `reviewed_by/at`; **partial unique** `(user_id) where status='pending'` | 1 year then purge |
| `invitations` | `id`; `code_hash bytea` **unique**; `created_by`; `expires_at`; `max_uses int ≥ 1`; `uses_count int` with `check (uses_count <= max_uses)`; `revoked_at`; `note` | Kept for audit |
| `invitation_redemptions` | `id`; `invitation_id`; `user_id`; `redeemed_at`; `outcome`; **unique** `(invitation_id, user_id)` | Kept for audit |
| `invitation_attempts` | `user_id`, `attempted_at`, `succeeded` | Purge > 24 h |
| `connections` | `id`; `user_low`, `user_high` with `check (user_low < user_high)`; `requested_by`; `status` (`pending|accepted|declined`); `created_at`, `responded_at`; **unique** `(user_low, user_high)` | Cancel/remove = delete row; `declined` rows kept for the re-request cooldown (default 7 days) |
| `blocks` | PK `(blocker_id, blocked_id)`; `check (blocker_id <> blocked_id)` | Deleted on unblock |
| `conversations` | `id`; `type` (`direct|group`); `direct_key text unique` (`least(a,b)||':'||greatest(a,b)`, null for groups); `title`, `avatar_path`; `created_by`; `last_seq bigint default 0`; `last_message_at` | Retained; groups deleted when empty after 30 days |
| `conversation_members` | `id`; `conversation_id`; `user_id`; `role` (`member|group_admin`); `joined_at`; `joined_seq`; `left_at`; `left_reason` (`left|removed`); `last_read_seq`; `muted_until`; **partial unique** `(conversation_id, user_id) where left_at is null` | A re-added user gets a new row (history only from the new `joined_seq`) |
| `messages` | `id` uuid PK; `conversation_id`; `seq bigint` **unique with** `conversation_id`; `sender_id`; `kind` (`text|image|system`); `body` (≤ 4,000 chars); `reply_to_id`; `client_msg_id uuid`; `created_at`, `edited_at`, `deleted_at`; **unique** `(conversation_id, sender_id, client_msg_id)` | Soft delete: `body` nulled, tombstone kept |
| `message_attachments` | `id`; `message_id`; `bucket`; `object_path` **unique**; `thumb_path`; `mime_type`; `byte_size`; `width`, `height` | Objects deleted with message/account |
| `message_reactions` (R3) | PK `(message_id, user_id, emoji)`; emoji from a fixed allow-list | cascade with message |
| `notifications` | `id`; `user_id`; `type`; `ref_type`, `ref_id`; `created_at`; `read_at`. **No message bodies** | Purge after 30 days |
| `reports` | `id`; `reporter_id`; `target_user_id`; `target_message_id`; `category`; `details`; `status`; `assigned_to`; `resolution`; `evidence jsonb` (snapshot, §6.4); `evidence_expires_at`; timestamps | Evidence purged 90 days after resolution |
| `admin_audit_log` | `id bigint identity`; `actor_id`; `action`; `subject_type`; `subject_id`; `metadata jsonb` (no secrets, no message text); `created_at`. `UPDATE`/`DELETE` revoked from every role | 1 year minimum (§14) |
| `rate_limits` | `(user_id, action, window_start)` PK; `count` | Purge > 24 h |
| `account_deletion_requests` | `user_id` PK; `requested_at`; `scheduled_for`; `status` | Purged after completion |

**Later phases (create only when approved):** R3 `announcements`; R4 `call_sessions`, `call_participants`; R5 `game_sessions`, `game_players`, `game_moves`; R6 `posts`, `post_attachments`, `comments`, `reactions`, `stories`, `story_views`; push `push_subscriptions`.

**Changes from the previous proposal and why:** `friend_requests` + `connections` merged into one `connections` table (one canonical pair row prevents duplicates and races); `blocked_users` → `blocks`; `message_receipts` removed (replaced by `last_read_seq`, avoiding a row per message per user); `seq` and `client_msg_id` added for ordering and idempotency; `invitation_attempts`, `rate_limits`, `reserved_usernames`, `account_deletion_requests` added; `reports.evidence` added so moderation never needs a message browser; `call_sessions`, `posts`, `stories`, `games`, `game_players` deferred to their phases.

### 6.3 Integrity rules

- A user cannot connect to, block, or message themselves (check constraints).
- Only `active` members can create connections, join conversations, upload, or read member data.
- Exactly one direct conversation per pair (`direct_key` unique; `get_or_create_direct` is transactional).
- Message `seq` is assigned inside `send_message` by `update conversations set last_seq = last_seq + 1 … returning` (a row lock gives gap-free, strictly ordered numbers per conversation). Clients detect gaps and refetch.
- Unread count = `conversations.last_seq − conversation_members.last_read_seq` (no counting queries).
- Group history rule (owner default, confirmed in `DECISIONS.md` OD-05): leaving or removal ends access to all history and attachments; re-adding grants access only from the new `joined_seq`. Messages remain for remaining participants.
- **Block semantics:** blocking prevents new connection requests, new direct-conversation creation, and (R4) calls, in both directions. An existing direct conversation becomes read-only for both parties (sending rejected by `send_message`). Blocking does not remove either person from shared groups; messages in shared groups remain visible (documented limitation; a client-side "hide messages from blocked members" option is a later enhancement).
- Edit window 15 minutes (sender only); delete-for-everyone by sender any time (soft delete). Neither is allowed for `system` messages.
- Never accept `sender_id`, role, status, `seq`, counters or winners from the client.

### 6.4 Moderation evidence (no admin message browser)

`submit_report` copies, at report time, the reported message plus up to 10 immediately preceding messages **visible to the reporter** into `reports.evidence`. Moderators see only this snapshot plus report metadata. This keeps the "no admin backdoor" rule while allowing action on abuse, and deleting the original does not destroy evidence. The report form tells the reporter exactly which messages will be shared.

## 7. Authorization and RLS

- RLS is enabled on every table in an exposed schema. **Review grants and policies together**: a policy does not remove an over-broad grant.
- Policies use `(select auth.uid())` (initPlan-friendly) and helper functions `app.is_active_member()`, `app.is_conversation_member(conversation_id)`, `app.has_role(...)` that are `SECURITY DEFINER`, `stable`, with `set search_path = ''`.
- Default-deny. Typical grants: clients `SELECT` (RLS-filtered) on `profiles` (via view/RPC with allowed columns only), `connections`, `conversations`, `conversation_members`, `messages`, `message_attachments`, `notifications`, own `reports`; **no direct INSERT/UPDATE/DELETE** on any table except where explicitly listed (e.g. `profiles` own non-privileged columns via RPC only).
- `messages` `SELECT` policy: caller has an active `conversation_members` row for the conversation **and** `messages.seq >= joined_seq`, and caller's membership is `active`.
- `profiles` directory access is by RPC (`search_members`) returning only `user_id, username, display_name, avatar_path` for `discoverability = 'members'`, or exact-username match otherwise; minimum query length 3; page size ≤ 20; rate-limited.
- Realtime and Storage have their own policy sets (§9, §10); each needs negative tests.
- Every RPC: validates `auth.uid()` is not null, checks active membership/role itself, validates input length/format, writes audit rows for privileged actions, and is `revoke … from public, anon` + `grant execute … to authenticated`.
- Dashboard **Security Advisor** and `supabase db lint` run in CI/release checklist.

## 8. Trusted operations catalogue

| Operation | Where | Responsibility |
|---|---|---|
| `claim_username`, `update_profile` | RPC | Normalize, reserve, enforce change cooldown (30 days; old name held 30 days) |
| `redeem_invitation`, `request_membership` | RPC | §4.3–4.4; throttle |
| `create_invitation` | RPC | Generate code in DB; return raw code once; store hash; audit |
| `revoke_invitation`, `review_membership`, `set_member_status`, `set_member_role`, `update_community_settings` | RPC (admin) | Role-check, last-owner/hierarchy rules, audit in same transaction |
| Suspension side effects | Edge Function called by `set_member_status` workflow | Admin-API ban + global sign-out; mark membership; Realtime signal on `user:{id}` |
| `search_members` | RPC | §7 |
| `send_connection_request`, `respond_connection`, `cancel_connection`, `remove_connection` | RPC | Active members, no self, no block, cooldown, canonical pair |
| `block_user`, `unblock_user` | RPC | §6.3 effects |
| `get_or_create_direct` | RPC | Requires accepted connection and no block |
| `create_group`, `add_group_member`, `remove_group_member`, `leave_group`, `set_group_admin` | RPC | Creator = group admin; members must be the actor's accepted connections; size cap |
| `send_message` | RPC | Active participant, not read-only, length limits, idempotency via `client_msg_id`, assigns `seq`, rate limit (default 30 messages/minute/user), emits Realtime signal |
| `edit_message`, `delete_message` | RPC | §6.3 |
| `mark_read` | RPC | Monotonic `last_read_seq` |
| `register_attachment` | RPC | Verifies the uploaded object exists, path belongs to the conversation, MIME/size match allow-list |
| `submit_report`, `resolve_report` | RPC | §6.4. Moderators: dismiss, warn (notification to the member) or escalate; only admins/owners suspend (via `set_member_status`) |
| `request_account_deletion`, `delete_account` | RPC + Edge Function | §4.6 |
| `export_my_data` | Edge Function | JSON of the user's profile, memberships, connections, authored messages |
| Scheduled cleanup | Edge Function (cron) | Orphaned storage objects, expired invitations/attempts/rate limits, purged evidence, stale pending profiles |
| `create_call_token` (R4) | Edge Function | §11 |
| `submit_game_move` (R5) | RPC | Validates turn/legal move atomically |

Edit, delete, reaction, typing and announcement operations ship in Phase 6 (R3); call and game operations in Phases 7–8. Edge Functions verify the caller's JWT in code per current Supabase documentation. Do not disable JWT verification; any unauthenticated webhook must verify its own signature.

## 9. Realtime and messaging architecture

**Principle:** PostgreSQL is the source of truth; Realtime is a **signal**. Broadcast payloads contain only ids and sequence numbers — never message bodies — so a client whose access was revoked but whose channel is still open learns nothing. Clients fetch bodies through RLS-protected `select`.

- Topics (all `private: true`): `conversation:{conversation_id}` and `user:{user_id}`.
- An `AFTER INSERT` trigger on `messages` calls `realtime.send` with `{conversation_id, seq, message_id, kind}` on the conversation topic (verify current function signature at implementation; `realtime.broadcast_changes` is the documented alternative but sends the full row).
- Authorization policies on `realtime.messages`: `SELECT` allowed for `conversation:*` topics only when the caller has an active membership in that conversation; for `user:{id}` only when `id = auth.uid()`. Client `INSERT` (typing indicator, extension `broadcast`) allowed under the same membership test. Public channels disabled.
- **Revocation:** Supabase notes channel authorization may be cached for the lifetime of the connection. On removal/suspension the client is told via `user:{id}` signal, tears down channels, and re-authenticates; ids-only payloads limit exposure until then. Test this explicitly.
- **Typing** is client-originated Broadcast on the conversation topic (best effort, never persisted, spoofable names are mitigated by rendering the name from the member list by `user_id`). **Presence** is used only inside an open conversation (no global "online" list in MVP — less data, fewer connections).

```mermaid
sequenceDiagram
  participant A as Sender browser
  participant DB as PostgreSQL (send_message RPC)
  participant RT as Realtime (private channel)
  participant B as Recipient browser
  A->>DB: send_message(conversation_id, client_msg_id, body)
  DB->>DB: check membership, block, limits; lock conversation row; seq = last_seq + 1; insert message
  DB-->>A: message row (id, seq, created_at)
  DB->>RT: trigger: realtime.send {conversation_id, seq, id}
  RT-->>B: signal (ids only)
  B->>DB: select messages where seq > last_seen (RLS)
  DB-->>B: message rows
  B->>DB: mark_read(conversation_id, seq)
```

- **Delivery/ordering:** per-conversation `seq`; clients keep `last_seen_seq`; on reconnect they fetch `seq > last_seen_seq` (cursor pagination, page ≤ 50). Duplicates are ignored by `(conversation_id, seq)`.
- **Optimistic UI:** the client generates `client_msg_id`; retry with the same id is idempotent (unique constraint returns the existing row).
- **Read state:** `last_read_seq` only. "Delivered" ticks are not offered (no honest signal); "Seen by" is shown for direct chats from the peer's `last_read_seq` when the peer has read receipts enabled (setting, default on).
- **History:** newest-first cursor pagination by `seq`.
- **Notifications (MVP):** `notifications` rows + unread badges in the open app. No browser push, no email, no SMS. Web push is a later, separate decision (iOS requires home-screen installation for web push — **UNVERIFIED** in this audit).
- Free-tier Realtime budget: 200 peak connections and 2 M messages/month (§16).

## 10. Media storage

- Buckets: `chat-media` (private), `avatars` (private; read by active members). No public buckets for member content.
- Path: `{conversation_id}/{uuid}.{ext}`; thumbnails at `{conversation_id}/{uuid}.thumb.webp`. Never trust a client path or filename.
- **Client pipeline (mandatory):** decode → resize (longest edge ≤ 1600 px; thumbnail ≤ 320 px) → re-encode WebP/JPEG at moderate quality → upload. Re-encoding strips EXIF (including GPS location) and keeps typical images in the hundreds of KB, protecting the 1 GB quota. Supabase image transformations are not available on Free.
- Allowed MIME types at bucket level: `image/jpeg`, `image/png`, `image/webp`. **SVG, HTML and executables are rejected.** Bucket max size 10 MB (hard cap is 50 MB on Free); video disabled in MVP.
- Storage policies: `INSERT` only when caller is an active member of the conversation named by the first path segment; `SELECT` only for active members of that conversation whose membership covers the message (`register_attachment` links object ↔ message). Access is by short-lived signed URL (≤ 5 minutes) created after authorization; the database stores paths, never URLs.
- Serving: Supabase serves objects from its own domain, not the app origin; app CSP restricts `img-src` to the Supabase project origin.
- Quota guard: per-user daily upload cap (default 30 images) and a conversation-level cap enforced in `register_attachment`.
- Cleanup: message/account deletion enqueues object deletion (Storage API only — never SQL on `storage` tables); nightly job removes orphans.
- Escape hatch: if storage becomes the bottleneck, evaluate Cloudflare R2 (10 GB free, no egress fees per secondary sources; payment-method requirement **UNVERIFIED**) behind the same `lib/media` interface, or Supabase Pro.

## 11. Voice and video (R4, LiveKit)

- Flow: caller creates a `call_sessions` row (RPC checks membership, accepted connection, no block, callee not busy) → Realtime `user:{callee}` signal → callee accepts → each side calls `create_call_token`.
- `create_call_token` (Edge Function): verifies JWT; loads the session; confirms caller/callee identity and status `accepted`; room name is an unguessable id derived from the session; signs a LiveKit token with `roomJoin`, `canPublish`, `canSubscribe`, TTL ≤ 10 minutes, for that room only. API key/secret exist only in Edge Function secrets.
- States: `ringing → accepted → ended`, or `declined | missed | cancelled | failed`; ringing times out at 45 s; server-side transitions only.
- One-to-one voice first, then one-to-one video, then (optional) small group. No recording. No claim of E2EE.
- STUN/TURN and media routing are provided by LiveKit Cloud; native peer-to-peer WebRTC is rejected because symmetric NATs and corporate firewalls need TURN relay, and meshes do not scale.
- The Build plan allowance is a **hard cap**: calls fail after the monthly quota until reset (official docs). Show a clear "calling unavailable until next month" state; do not enable paid plans without owner approval.
- Handle permission-denied, device-unavailable, reconnecting, busy, and tab-close states. Calls do not ring when the browser is closed (no push).

## 12. Social and games (R5–R6)

- **Games (R5):** turn-based first (tic-tac-toe, Connect Four). State is authoritative in PostgreSQL; `submit_game_move` locks the session row, validates player, turn, legality and idempotency key, writes the move, and signals via Realtime. Clients never submit winners or scores. Disconnect → state persists; forfeit after a configurable timeout enforced by a scheduled job.
- **Social (R6):** posts/comments/reactions/stories as separate tables with explicit audience (`connections` or `community`); stories expire by server time plus cleanup (client hiding is not deletion); media in private buckets under the same quota controls. Reuses report/block flows.

## 13. Security architecture

### 13.1 Threat model

| Threat | Mitigation |
|---|---|
| Calling the API directly / guessing IDs | RLS + revoked default grants + RPC-only writes; negative tests |
| Privilege escalation by editing browser state | Roles only in `memberships`; no client write; hierarchy and last-owner rules in DB |
| Invitation brute force / reuse | ≥ 80-bit codes, hash-only storage, atomic redemption, attempt throttling, generic errors |
| Reading another conversation | `is_conversation_member` in RLS, Realtime and Storage policies; ids-only Realtime payloads |
| Stale access after suspension | Per-request DB check (not JWT claims); Admin-API ban; channel teardown |
| Media path guessing / leaked links | Private buckets; policy on path; 5-minute signed URLs; no permanent URLs stored |
| Malicious upload (SVG/HTML/oversize) | MIME allow-list; size limits; re-encode client-side; no inline serving on app origin |
| XSS | Render text as text; no `dangerouslySetInnerHTML`; strict CSP; sanitize any future rich text with a vetted library |
| Account takeover | Google/Email-OTP with verified emails; global sign-out; identity-linking tests; admin-action audit |
| Spam/abuse | Rate limits (messages, requests, uploads, searches), block/report, invitation controls |
| Admin misuse | Least privilege, append-only audit log, no content browser, owner-only role changes |
| Leaked secret | Server-only secrets; secret scanning in CI; rotation runbook |
| Directory scraping | Min 3 characters, page ≤ 20, rate limit, `discoverability` setting |
| Dependency compromise | Lockfile, `npm audit`, Dependabot, pinned CI actions |
| Provider outage / quota | Status screens; monitoring checklist; tested export/restore |

### 13.2 Frontend headers and configuration

Set via Cloudflare `_headers` (support on Workers Static Assets **UNVERIFIED** — confirm in the Phase 1 spike; Pages supports it): `Content-Security-Policy` (default-src 'self'; connect-src 'self' the Supabase REST/Realtime origins and later the LiveKit origin; img-src 'self' data: blob: the Supabase storage origin; no `unsafe-inline` scripts; frame-ancestors 'none'), `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy` (camera/microphone only after R4), HSTS on the production domain. GitHub Pages cannot set custom response headers, which is a real security argument against it.

Public config (`VITE_SUPABASE_URL`, publishable key) may be bundled. `service_role`/secret keys, Google OAuth client secret, LiveKit secret, DB password and SMTP credentials never appear in `VITE_*`, the repo, logs or chats.

### 13.3 Encryption — what is and is not claimed

| Layer | Status |
|---|---|
| TLS in transit (browser↔Cloudflare, browser↔Supabase) | Yes |
| Encryption at rest by provider | Provider-managed; **not independently verified here**; make no specific claim without checking the live plan |
| **End-to-end encryption** | **No.** Mirach servers and Supabase can technically read message text. Admins are policy-restricted, not cryptographically prevented |

E2EE is a separate future project (audited protocol such as MLS/Signal-family library, per-device keys, verification, recovery, group key rotation, encrypted attachments, loss of server-side search/moderation evidence). It must never be implemented with home-made cryptography. Until then the product, terms and UI say plainly: **private and access-controlled, not end-to-end encrypted.**

## 14. Privacy and legal (India) — requires professional review

**What the primary sources establish (checked 4 Nov 2026, see `SOURCE_REGISTER.md`):** the DPDP Act 2023 and DPDP Rules 2025 were notified on 13–14 Nov 2025 with phased commencement; most Data Fiduciary obligations (notice and consent, security safeguards, breach reporting, rights handling, children's data) take effect 18 months later, on or about **13–14 May 2027** (sources differ by one day — confirm in the Gazette notification). Until then the IT Act framework governs. Processing a child's (under 18) personal data requires verifiable parental consent.

**Engineering implications (not legal conclusions):**
- Default policy: **18+ only**, stated in terms and onboarding (owner decision OD-07). Self-declaration is not verification; do not invite minors until counsel advises.
- Build now, because it is cheap: consent/privacy notice at sign-in; data-minimisation (no phone, contacts, birth date); account deletion; data export; breach-response runbook; named contact/grievance route; retention schedule (§6.2).
- Choose the Supabase region nearest to members (Mumbai exists per Supabase regions — **UNVERIFIED**, confirm in dashboard). Cross-border transfer rules and provider data-processing terms need review.
- Whether a small private group qualifies for any personal/domestic-use exemption, whether the owner is a "Data Fiduciary", and obligations as an online "intermediary" (grievance officer, takedown timelines under the IT Rules) are **open legal questions** (`DECISIONS.md` OD-08). Do not claim compliance from this document.

## 15. Deployment, environments and operations

### 15.1 Hosting decision

| Option | Verdict |
|---|---|
| GitHub Pages | Static only; sites are publicly reachable even from a private repo (private-repo Pages needs a paid plan); cannot set custom security headers; terms say not to use it for sensitive transactions such as passwords or for commercial SaaS. Technically able to serve an SPA, but a **poor fit** for an auth-gated private-communications app |
| **Cloudflare Workers Static Assets** | **Chosen.** Free static delivery; custom headers; Git deploy; Cloudflare's stated direction for new projects |
| Cloudflare Pages | Acceptable fallback; fully supported but described as maintenance-mode by secondary sources |
| Vercel Hobby / Netlify | Not needed; Vercel Hobby is non-commercial-only; Netlify free is credit-based |

Hosting layers, kept distinct: source code → GitHub; frontend → Cloudflare; API/database/auth/storage/realtime → Supabase; calls → LiveKit. A static host cannot run the backend.

### 15.2 Environments

| Environment | Frontend | Backend | Data |
|---|---|---|---|
| Local | Vite dev server | `supabase start` (Docker) | Synthetic seed only |
| Staging/preview | Cloudflare preview deployments | Supabase Free project #1 | Test accounts only |
| Production | Cloudflare production | Supabase Free project #2 (until Pro is approved) | Real members |

Supabase Free allows two active projects; production and staging therefore use both. Previews never point at production. If Pro is approved later, use branching.

### 15.3 Repository layout (target)

```
/docs                      the six documents + REVIEW_REPORT, DECISIONS, SOURCE_REGISTER
/src/app                   shell, router, providers, guards
/src/features/<feature>    components/ hooks/ api/ schemas/ tests/
/src/lib/{api,realtime,media,format}
/supabase/migrations       ordered SQL (source of truth)
/supabase/tests            pgTAP RLS/RPC tests
/supabase/functions        Edge Functions
/e2e                       Playwright multi-user tests
.env.example               names only
```

### 15.4 CI/CD and Git

`main` is deployable; changes via PR; CI runs type-check, lint, unit tests, build, `supabase db reset` + pgTAP, secret scan (gitleaks), `npm audit`. Migrations are reviewed as SQL diffs and applied to staging before production. GitHub Actions pinned by commit hash. No force-push to `main`.

### 15.5 Environment variables

Documented in `.env.example`: `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_APP_ENV`. Server-only (Supabase secrets/CI secrets): `SUPABASE_SERVICE_ROLE_KEY` (or current secret key), `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`, `LIVEKIT_URL`, SMTP credentials, `BACKUP_ENCRYPTION_KEY`. Development and production keys differ.

### 15.6 Backup and recovery (required before real data)

Free plan has **no automatic backups**. Until Pro (7-day daily backups) is approved:

1. Scheduled (weekly, and before every migration) `supabase db dump` of schema and data, **encrypted** with a key kept outside the repo, stored in the owner's private storage (not in a public repo or unencrypted CI artifact).
2. Storage objects: periodic object-list + download of `chat-media` and `avatars` (script run by the owner) or accept media as best-effort with a stated limitation.
3. **Restore drill** into a scratch project before launch and quarterly after; record the result.
4. RPO/RTO stated honestly to members (e.g. "up to 7 days of data may be lost in a disaster").

### 15.7 Operations

Monthly checklist: Supabase usage page (DB size, storage, egress, Realtime messages/peak connections, Edge invocations), LiveKit usage, Cloudflare builds; advisor findings; dependency updates; review audit log. Logs: request IDs, error class, timings only — never bodies, tokens, codes or signed URLs. The Free project may pause after 1 week of inactivity: treat it as an incident type with a documented resume step; do not rely on keep-alive hacks.

## 16. Scalability and cost scenarios

Assumptions are **assumptions, not measurements** (labels A1–A5). Provider limits are the verified ones in §2/§18. Full arithmetic is in `REVIEW_REPORT.md` §6.

- A1: 40 text messages sent per active member per day; 30 days.
- A2: Realtime counted messages ≈ 8 per sent message (signal fan-out plus typing); deliberately conservative.
- A3: ≈ 0.5 KB stored per message including indexes.
- A4: 1 image per member per day, compressed to ≈ 0.3 MB (without compression ≈ 2 MB).
- A5: 1:1 call = 2 participant-minutes per minute; ≈ 1 Mbps video per direction.

| Members | Realtime msgs/month | DB growth/month | Image storage/month (compressed) | Verdict on Free |
|---|---:|---:|---:|---|
| 10 | ≈ 96,000 (4.8% of 2 M) | ≈ 6 MB | ≈ 90 MB (1 GB lasts ≈ 11 months) | Fits |
| 50 | ≈ 480,000 (24%) | ≈ 30 MB | ≈ 450 MB (≈ 2 months) | **Storage is the limit**; compress, cap uploads, plan Pro or R2 |
| 100 | ≈ 960,000 (48%) | ≈ 60 MB (500 MB lasts ≈ 8 months) | ≈ 900 MB (≈ 1 month) | Needs Pro (or R2) for media; DB also approaching limit within a year |

Cost layers: **development** $0 (own time); **initial launch** $0 required (domain only if email OTP/custom domain is approved; price **UNVERIFIED**); **ongoing** $0 while inside Free quotas, which have no backups and can pause; **future** Supabase Pro from $25/month (verified) buys 8 GB disk, 100 GB storage, 250 GB egress, daily backups, no pausing; LiveKit Ship from $50/month; overages per provider pages.

Scaling path: Pro plan first (no architecture change) → R2 for media → larger compute. A dedicated realtime/game server is out of scope.

## 17. Reconsideration triggers

| Decision | Reconsider if |
|---|---|
| Supabase | Pause/backups unacceptable without Pro; Realtime limits hit; a data-residency requirement Supabase cannot meet |
| Workers vs Pages | Workers Builds quotas or `_headers` support prove inadequate |
| Google-only → +email OTP | Any invitee lacks a Google account |
| LiveKit Build | Monthly 5,000 participant-minutes exhausted regularly |
| Supabase Storage | 1 GB reached; egress above 5 GB cached |
| Postgres RLS model | Policy performance degrades at scale (inspect plans) |
| No E2EE | Community requires server-blind confidentiality |

## 18. Provider verification snapshot (4 November 2026)

| Provider | Verified facts | Source tier |
|---|---|---|
| Supabase Free | 50,000 MAU; 500 MB DB (shared CPU, 500 MB RAM); 5 GB egress + 5 GB cached egress; 1 GB storage; 50 MB max upload; 200 peak Realtime connections; 2 M Realtime messages; 256 KB max message; 500,000 Edge invocations; custom SMTP allowed; no automatic backups; pause after 1 week inactivity; 2 active projects; Pro $25/month | Primary (pricing page fetched) |
| Supabase default SMTP | Only team addresses; ~2/hour; no SLA; custom SMTP raises to 30/hour default | Primary (docs excerpt) + secondary |
| Supabase Realtime | Broadcast recommended over Postgres Changes for scale and security | Primary (docs excerpt) |
| Supabase passkeys | Beta/experimental (28 May 2026) | Primary |
| Cloudflare Pages Free | 500 builds/month; 1 concurrent; 20 min timeout; 20,000 files; 25 MiB/file | Primary (docs excerpt) |
| Cloudflare Workers Static Assets | Docs point new static/full-stack hosting to it; Pages still supported | Primary (partial) + secondary |
| GitHub Pages | Public sites; 1 GB; 100 GB/month soft; sensitive-transaction and commercial-SaaS wording | Primary (docs excerpt) |
| LiveKit Build | $0; 5,000 WebRTC min; 50 GB; 100 concurrent participants; free allowance is a **hard cap**; Build quota shared across projects | Primary (docs/blog excerpts) |
| Firebase | Cloud Storage requires Blaze since 3 Feb 2026; budgets alert but do not stop spend | Secondary |
| Appwrite Free | 75K MAU; 2 GB storage; 5 GB bandwidth; 1 DB/1 bucket per project; pauses after 1 week | Primary (excerpts) |
| DPDP | Rules notified Nov 2025; 18-month phasing; verifiable parental consent for under 18 | Primary (PIB) |

## 19. Decision records

All ADRs (ADR-001 to ADR-016) and open decisions (OD-01 to OD-12) are in `DECISIONS.md`. Changes to anything in §2–§15 require a new or amended ADR and updates to the dependent documents (`Rules.md` §21).
