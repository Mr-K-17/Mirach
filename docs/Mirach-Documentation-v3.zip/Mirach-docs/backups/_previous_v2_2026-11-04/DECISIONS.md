# Decisions — Mirach

> **Last reviewed:** 4 November 2026 (Asia/Kolkata).
> **Purpose:** Architecture Decision Records (ADRs) and the register of open decisions. Supporting document; the six core documents remain authoritative.

## 1. How to use

- Changing anything in `Memory.md` §2–§3 or `Architecture.md` §2–§15 requires a new or amended ADR here, updates to dependent documents, and owner approval (`Rules.md` §2, §21).
- Open decisions (§3) have a **safe working default**. Prototype work may proceed on the default; the owner must confirm by the stated gate.
- Statuses: **Accepted** (planning baseline, awaiting owner review of this revision), **Superseded**, **Proposed**.

## 2. Architecture decision records

### ADR-001 — Frontend hosted statically, separate from the backend; GitHub holds code only
**Status:** Accepted (revised). **Decision:** GitHub stores source and runs CI; a static host serves the SPA; Supabase provides backend; LiveKit (later) provides call media. **Why:** a static host cannot run a database, auth, private storage or calling infrastructure; the layers must be named separately. **Revisit if:** full-stack compute is needed.

### ADR-002 — Cloudflare Workers Static Assets as the frontend host (Pages fallback)
**Status:** Accepted, with a Phase 1 spike. **Context:** the owner initially proposed GitHub Pages. GitHub Pages is static-only, publishes sites publicly even from private repositories (private-repo Pages needs a paid plan), cannot set custom response headers (no real CSP), and its documentation says Pages should not be used for sensitive transactions such as passwords or as a commercial SaaS host. Cloudflare Pages is still supported, but Cloudflare's docs direct new static/full-stack hosting to Workers Static Assets and secondary sources describe Pages as maintenance mode. **Decision:** use Workers Static Assets with Git deploys and a `_headers` file; fall back to Pages if the spike finds Workers Builds quotas or header support inadequate. **Rejected:** GitHub Pages (poor fit, not "forbidden"), Vercel Hobby (non-commercial restriction), Netlify (credit-based free plan, no advantage). **Spike must record:** Workers Builds free quotas, `_headers` support, SPA fallback behavior (all **UNVERIFIED** today). **Revisit if:** spike fails or Cloudflare changes direction.

### ADR-003 — Supabase as the backend
**Status:** Accepted. **Why:** PostgreSQL gives constraints, transactions and RLS needed for invitation atomicity, pair uniqueness and membership rules; Auth, Realtime and Storage share the same identity. **Compared:** Firebase (document model, weak relational access rules, Cloud Storage needs a billing plan since 3 Feb 2026 per secondary sources); Appwrite (Free caps 2 GB storage/5 GB bandwidth, pauses idle projects, smaller ecosystem; database model not evaluated in depth). **Trade-offs:** Free tier pauses after one week idle, has no automatic backups, small storage; vendor-specific Auth/Realtime/Edge pieces. **Mitigation:** SQL migrations as source of truth; data access behind `src/lib/api`. **Revisit if:** see `Architecture.md` §17.

### ADR-004 — Google OAuth first, email one-time code second, no phone auth
**Status:** Accepted. **Why:** Google OAuth needs no SMTP or domain and gives a verified email and recovery; email OTP removes the Google-account exclusion but requires an owned domain and SMTP (default Supabase SMTP only emails project-team addresses at about 2/hour). Magic links rejected (email scanners can consume single-use links); password login rejected (reset flow, no breached-password check on Free); passkeys are beta/experimental in Supabase (May 2026) — revisit at R7. **Trade-off:** until OD-03 is resolved, members need Google accounts.

### ADR-005 — Authentication, membership, connection and conversation membership are separate
**Status:** Accepted (retained). Matches the invite-only privacy model.

### ADR-006 — PostgreSQL is the source of truth; Realtime Broadcast carries ids-only signals
**Status:** Accepted (replaces "Postgres Changes for durable messages"). **Why:** Supabase documentation recommends Broadcast over Postgres Changes for scalability and security; Postgres Changes processes changes on one thread and checks RLS per subscriber. Ids-only payloads mean a revoked client with a still-open channel learns nothing. **Cost:** one extra fetch per message. **Note:** verify the current `realtime.send` signature at implementation.

### ADR-007 — Clients never write tables directly; RPC-only writes; default-deny grants
**Status:** Accepted. **Why:** one validated entry point per operation, prevents mass assignment, centralizes rate limits and audit. RPCs are `SECURITY DEFINER` with `search_path = ''`, executable only by `authenticated`.

### ADR-008 — Per-conversation `seq`, `client_msg_id` idempotency, read cursor instead of receipts
**Status:** Accepted. **Why:** deterministic ordering, gap detection, safe retries, cheap unread counts. Removes the `message_receipts` table (a row per message per user). "Delivered" ticks are not offered because no honest signal exists.

### ADR-009 — Single `connections` table with a canonical user pair
**Status:** Accepted (merges `friend_requests` + `connections`). **Why:** `unique(user_low, user_high)` prevents duplicates and mutual-request races by construction; declined rows keep a cooldown.

### ADR-010 — Moderation by evidence snapshots; no administrator message access
**Status:** Accepted. **Why:** preserves "no hidden backdoor" while letting moderators act; snapshots survive deletion and are purged 90 days after resolution.

### ADR-011 — Client-side image compression and EXIF removal; no video in MVP
**Status:** Accepted. **Why:** Supabase Free has 1 GB storage and no image transformations; EXIF may contain location; video would exhaust quota. Allowed types JPEG/PNG/WebP only (no SVG).

### ADR-012 — `profiles.user_id` equals the auth user ID without a cascading FK; deletion tombstones
**Status:** Accepted. **Why:** a hard FK with delete behavior would either cascade-delete members' messages or block account deletion. Tombstoning keeps conversations coherent. **Risk:** integrity depends on the sign-up trigger and the deletion workflow; both are covered by tests.

### ADR-013 — LiveKit Cloud for calls, deferred to R4
**Status:** Accepted. **Why:** TURN, signaling and SFU are non-trivial; the Build plan is a hard cap, not an overage trap; the server is open source (exit path). **Other managed providers (Daily, 100ms, Agora, Twilio):** not price-verified — **UNVERIFIED**. **Revisit if:** quota exhausted regularly or pricing changes.

### ADR-014 — No end-to-end encryption in the MVP; no custom cryptography
**Status:** Accepted. **Why:** E2EE needs an audited protocol, per-device keys, verification, recovery, group key rotation and encrypted attachments, and removes server-side moderation evidence; it is a separate project. The product states plainly that it is not E2EE.

### ADR-015 — Release re-sequencing and early gates
**Status:** Accepted. **Change:** privacy, backup and deletion work moved into the MVP gate; R3 "community essentials" added; games before social; calls before games. **Why:** see `Phases.md` §1.

### ADR-016 — Authorization from database lookups, not JWT claims
**Status:** Accepted. **Why:** claims persist until token expiry; a suspended member must lose access immediately. Admin-API ban and global sign-out supplement this.

## 3. Open decisions register

Each item lists the **safe working default** (used until the owner decides) and the **gate** by which it must be settled.

| ID | Decision needed | Safe working default | Gate |
|---|---|---|---|
| OD-01 | Final product name, logo, domain; trademark and existing-product check for "Mirach" (unverified) | Use "Mirach" internally; centralize name/config; no logo copied | Before any public-facing beta |
| OD-02 | Expected community size and call concurrency | Start ≤ 25 invited members; measure | Before Gate C |
| **OD-03** | Do all initial members have Google accounts? Approve domain purchase and SMTP for email OTP? | Google-only until confirmed; email OTP built in Phase 6, earlier if any invitee lacks Google | Before inviting anyone without Google; Phase 2 if needed |
| OD-04 | Directory visibility and DM policy | Active members only; username + display name + avatar; DMs only between accepted connections; discoverability default "all members" with exact-username option | Before Phase 3 |
| OD-05 | Group history after leaving/removal | Loses all history; re-add sees only from re-join | Before Gate B |
| OD-06 | Retention and deletion numbers; treatment of a deleted member's messages | Messages remain as "Deleted member"; evidence 90 days after resolution; audit 1 year; notifications 30 days; pending profiles 30 days; membership requests 1 year; deletion grace 14 days | Before Gate B |
| **OD-07** | Age policy | 18+ only, declared at onboarding; no minors until counsel advises | Before Gate A (declaration) and before any minor is invited |
| **OD-08** | Legal review scope: DPDP applicability (data fiduciary status, any personal/domestic-use exemption), consent notice, breach reporting, grievance contact, cross-border transfer, IT Rules intermediary duties | Build privacy features early; no compliance claim; counsel before widening | Gate C and before 13–14 May 2027 |
| **OD-09** | Backups and Supabase Pro ($25/month) | Manual encrypted backups + restore drill on Free; decide Pro before Gate C, or earlier if data loss or pausing is unacceptable | Gate A (manual backup), Gate C (Pro decision) |
| OD-10 | Moderation staffing | Owner as admin plus a second admin appointed before Gate B; moderators optional | Gate B |
| OD-11 | Media limits | Images ≤ 10 MB bucket cap (typical < 0.5 MB after compression); 30 uploads/user/day; video disabled | Before Phase 5 |
| OD-12 | Supabase region and data residency | Nearest region to members (Mumbai if available — **UNVERIFIED**) | Before creating the production project |

## 4. Decision log (changes to this file)

| Date | Change |
|---|---|
| 2026-11-04 | Initial v2 ADR set and open decision register created during the documentation audit |
