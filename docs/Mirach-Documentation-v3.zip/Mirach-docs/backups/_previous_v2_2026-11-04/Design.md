# Design — Mirach

> **Status:** UX and interaction specification v2. Visual tokens are proposals to be confirmed in Phase 1.
> **Last reviewed:** 4 November 2026 (Asia/Kolkata).
> **Authority:** Controls interaction, screens and visual behavior. Requirements are in `PRD.md`; data and security in `Architecture.md`.

## 1. Design philosophy

Mirach should feel like **one calm, private place**, not several apps stitched together. It borrows familiar conventions (conversation list, bubbles, tabs) but has its own name, palette, icons and layouts; nothing is copied from WhatsApp, Instagram or Snapchat.

Principles:
1. **Messaging first.** Chats and people are the primary surfaces; later features join navigation only when shipped.
2. **Private by default and legible.** Every screen that shares content states its audience in words ("Only this chat", "All members", "Connections").
3. **Honest status.** Sending, sent, failed, offline, reconnecting, pending, read — shown only when the server has confirmed them. No fake "delivered" ticks.
4. **Low cognitive load.** One primary action per screen; short onboarding; plain language.
5. **Accessible and responsive.** Keyboard, screen reader, touch and small screens are first-class. WCAG 2.2 AA is the target.
6. **Safe by design.** Destructive actions confirm; reporting is easy; we never display identifiers, emails or internal errors.
7. **Quiet.** No streaks, no engagement nudges, no global "online" list.

Priority order when principles conflict: privacy and accessibility over visual polish.

## 2. Visual system

Tokens are defined once in code (CSS variables mapped into Tailwind) so branding can change in one place. Contrast ratios below were computed against the stated backgrounds on 4 Nov 2026; re-verify with a checker if values change.

### 2.1 Color tokens (light theme first)

| Token | Value | Use | Contrast |
|---|---|---|---|
| `color.bg` | `#FFFFFF` | Page background | — |
| `color.surface` | `#F6F5F3` | Cards, panels, received bubbles | text on it ≥ 7.0:1 |
| `color.text` | `#1C1917` | Body text | 17.49:1 on bg |
| `color.textMuted` | `#57534E` | Secondary text | 7.63:1 on bg, 7.0:1 on surface |
| `color.border` | `#D6D3D1` | Decorative dividers only (1.49:1) | not for controls |
| `color.borderStrong` | `#78716C` | Input and control outlines | 4.80:1 (≥ 3:1 required) |
| `color.accent` | `#C2410C` | Primary buttons, links, sent bubbles | white on accent 5.18:1 |
| `color.success` | `#15803D` | Success text/icons | 5.02:1 |
| `color.warning` | `#B45309` | Warnings | 5.02:1 |
| `color.danger` | `#B91C1C` | Errors, destructive | 6.47:1 |

Dark theme (parallel, shipped with R2 only if tested): `bg #1C1917`, `surface #292524`, `text #FAFAF9` (16.74:1), `textMuted #A8A29E` (6.93:1 on bg, 6.01:1 on surface), `accent #FB923C` (7.73:1), `success #4ADE80`, `warning #FBBF24`, `danger #F87171`. Theme follows system preference with a manual override in Settings. Status is never conveyed by color alone (icon + text always).

### 2.2 Typography, spacing, shape, motion

- **Type:** system font stack (`ui-sans-serif, system-ui, …`) — no external font hosts (privacy, speed, CSP). Scale (rem): caption 0.75, label 0.875, body 1, section title 1.25, page title 1.5, display 2. Line-height 1.5 body, 1.25 titles. Body minimum 16 px on mobile inputs (prevents iOS zoom).
- **Spacing:** 4 px base unit (4, 8, 12, 16, 24, 32, 48).
- **Radius:** controls 8 px, cards 12 px, bubbles 16 px, avatars full.
- **Elevation:** at most two shadow levels (card, dialog); borders preferred.
- **Focus:** 2 px solid ring `color.accent` with 2 px offset on every interactive element.
- **Motion:** 150–200 ms ease-out; `prefers-reduced-motion` disables non-essential animation.
- **Iconography:** one open-source icon set (license checked before adoption); icon + text for primary actions.
- **Touch targets:** ≥ 44 × 44 px.

## 3. Navigation architecture

**Member primary navigation (only shipped features appear):**

| Item | Release | Contents |
|---|---|---|
| Chats | R2 | Conversation list; new chat; new group |
| People | R2 | Search, requests (received/sent), connections |
| Notifications | R2 | Bell with unread count (header on desktop, tab on mobile) |
| Community | R3 | Announcements (R3); feed and stories (R6) |
| Calls | R4 | History; incoming/active call overlay is global |
| Games | R5 | Lobby, invitations |
| Profile & settings | R2 | Own profile, privacy, blocked members, sessions, data export/delete |

**Desktop (≥ 1024 px):** left rail with labelled items; middle column = list (chats or people); right = detail (conversation or profile). **Tablet (640–1023 px):** rail collapses to icons; list and detail side by side where width allows. **Mobile (< 640 px):** bottom tab bar (max 5 items: Chats, People, Notifications, Community/Games when shipped, Me); list and detail are separate screens with a visible Back button; the tab bar hides inside an open conversation.

**Admin navigation** (appears only for moderator/admin/owner; every action still validated server-side): Overview · Requests · Members · Invitations · Reports · Settings · Audit log (viewer ships in R3). Moderators see Reports only.

## 4. Route map

| Route | Screen | Access |
|---|---|---|
| `/` | S1 Welcome | Everyone (redirects signed-in users by status) |
| `/login` | S1 Sign-in | Signed out |
| `/auth/callback` | OAuth callback + loading | Auth flow |
| `/join` | S2 Registration & invitation | Signed in, not active |
| `/pending` | S3 Pending membership | Signed in, `pending` |
| `/rejected` | S3 Rejected/suspended notice | `rejected` or `suspended` |
| `/app` | Shell → redirect to `/app/chats` | Active |
| `/app/chats`, `/app/chats/:conversationId` | S4 Home, S7/S8 Conversation | Active; participant for detail |
| `/app/chats/:conversationId/media/:attachmentId` | S9 Media viewer | Participant |
| `/app/people`, `/app/people/requests`, `/app/people/:username` | S5, S6, profile view | Active |
| `/app/notifications` | S15 | Active |
| `/app/me`, `/app/me/settings`, `/app/me/privacy` | S10, S16 | Active |
| `/app/community` | S11 (announcements R3, feed R6) | Active, when shipped |
| `/app/stories` | S12 | Active, R6 |
| `/app/calls` | S13 | Active, R4 |
| `/app/games`, `/app/games/:sessionId` | S14 | Active, R5 |
| `/admin`, `/admin/requests`, `/admin/members`, `/admin/invitations`, `/admin/reports`, `/admin/settings`, `/admin/audit` | S17, S18 | By role |
| `*` | Not found | Everyone |

URLs never contain tokens, emails or other members' personal identifiers (conversation IDs are opaque UUIDs and authorization never depends on them). Route guards are UX only. Unknown routes, stale sessions, pending/suspended users and revoked access all land on intentional screens (§16).

## 5. Authentication and onboarding

### S1 — Welcome and sign-in (`/`, `/login`)
- **Purpose:** explain Mirach is a private invited community and let people sign in.
- **Components:** logo/name, one-paragraph description, **Continue with Google** (primary), privacy statement ("No phone number needed. Your Google email is private and never shown to members."), links to notice/terms/rules, small "Not end-to-end encrypted" line.
- **Actions:** start OAuth; read documents.
- **Navigation:** success → by status (`/join`, `/pending`, `/app`).
- **Access:** signed out.
- **States:** loading (button spinner, disabled), user-cancelled ("Sign-in was cancelled. Try again."), OAuth error (neutral message + retry), offline (banner), provider unavailable.
- Never ask for a Google password; never show a phone field.

### S2 — Registration and invitation (`/join`)
- **Purpose:** complete the profile and choose how to join.
- **Components:** step 1 username (rules shown, live availability hint — DB is authoritative), display name, optional avatar (compressed before upload); step 2 age/terms checkbox group (18+, privacy notice, community rules, with links and the "not end-to-end encrypted" statement); step 3 two clear options: **I have an invitation code** (single field, Submit) and **I don't have a code** (short message to admins, Request access). Copy states whether an approved code activates immediately or waits for review.
- **Actions:** claim username; redeem code; request access.
- **Navigation:** code accepted → `/app` or `/pending`; request sent → `/pending`.
- **Access:** signed in, not active.
- **States:** username taken/invalid/reserved (inline, specific); wrong code → **generic** "That code didn't work" (never reveals expired vs invalid); too many attempts → "Please wait before trying again"; network error with retry; submit disabled while pending response.

### S3 — Pending, rejected, suspended
- **Pending (`/pending`):** "Your request is with the admins." Shows submitted date, withdraw option, Sign out, Delete my account. Refreshes on load and on a low-frequency check (no tight polling).
- **Rejected (`/rejected`):** neutral wording; re-apply date if applicable; support contact if configured.
- **Suspended:** neutral notice, contact route, sign out; no content or member data shown.
- **Access:** corresponding status only. **States:** loading skeleton; error with retry.

## 6. People and connections

### S5 — Member discovery (`/app/people`)
- **Purpose:** find members by username or display name.
- **Components:** search field (hint: "Type at least 3 characters"), result list (avatar, display name, @username, relationship chip), empty state ("No members match that. Check the spelling or ask them for their username."), pagination ("Load more").
- **Actions:** open profile; send request.
- **Access:** active. **States:** idle (no list dump), loading, empty, rate-limited ("Searching too fast. Try again in a moment."), error + retry. Members who chose "exact username only" appear only for an exact match.

### S6 — Connection requests (`/app/people/requests`)
- **Components:** tabs Received · Sent · Connections; row actions Accept/Decline, Cancel, Message/Remove.
- **Behavior:** buttons disable on first press; status changes only after server confirmation; destructive actions (Remove, Decline-and-block) confirm.
- **States:** empty per tab with explanation; error/retry; offline banner.

### Member profile (`/app/people/:username`)
Avatar, display name, @username, bio; actions depend on relationship — none: **Send request**; sent: **Cancel request**; received: **Accept / Decline**; connected: **Message**, **Remove**, **Block**, **Report**; blocked: restricted notice with Unblock. Blocking explains its effects before confirming.

## 7. Messaging

### S4 — Home / Chats list (`/app/chats`)
- **Purpose:** dashboard and entry to all conversations.
- **Components:** header (title, notification bell, new chat/group), announcement banner (R3), pending-requests chip, conversation list (avatar or group initials, name, last-message preview, time, unread count, mute icon), search-in-list.
- **Actions:** open conversation; new chat (pick from connections); new group.
- **Access:** active. **States:** skeleton rows; empty ("No chats yet. Connect with someone in People to start."); error/retry; reconnecting banner; "access removed" row state if removed while open.

### S7 — Private chat (`/app/chats/:id`, direct)
- **Components:** header (name, back on mobile, menu: view profile, mute, block, report), message thread (date separators, bubbles with text and time; sent vs received distinguished by alignment **and** a label for assistive tech), composer (multiline input, Send, Attach image), connection/reconnection banner, jump-to-latest button.
- **Behavior:** send creates a pending bubble with a client ID; on failure shows "Not sent — Retry / Delete"; retries are idempotent. Scroll position is preserved when older history loads. Text is rendered as text (no HTML). Edited/deleted labels appear only when true (R3). "Seen" appears only when the peer's read cursor allows and they have not opted out.
- **Read-only state:** if blocked or no longer connected, composer is replaced by an explanatory notice.
- **States:** loading older, empty thread ("Say hello 👋" — decorative emoji, text label present), error per message, offline queue banner, rate-limit notice ("Slow down a moment"), revoked access (full-screen neutral state with a way back).

### S8 — Group chat
Same as S7 plus: header shows group name/avatar and participant count; **Group info** drawer (participants with group-admin badges, Add members and Remove for group admins, Leave group); system messages for joins/leaves; typing indicators (R3). Leaving explains that history will no longer be available. Removed members see the revoked-access state at once.

### S9 — Media viewer
- **Purpose:** view an image full-screen.
- **Components:** image, close, previous/next within the conversation, download (if enabled), report, caption/time; alt text from the sender's caption or "Image from <name>".
- **Behavior:** image URL is a short-lived signed URL fetched on open; if expired, it is silently re-requested once; if access was lost, show "This image is no longer available to you."
- **States:** loading blur-up thumbnail, error/retry, revoked.

### Composer image flow
Pick image → local preview with size → automatic resize/re-encode (EXIF removed; a note says "Location data is removed") → progress with Cancel → success shows in thread; failure shows retry. Type or size violations are explained ("Only JPEG, PNG or WebP up to 10 MB").

## 8. Notifications, profile, settings

### S15 — Notifications (`/app/notifications`)
List of: connection request received/accepted, membership decision, announcement (R3), call missed (R4), game invite (R5). Tapping navigates to the source; mark all read. No message text in items. **States:** empty ("You're all caught up"), loading, error. Push/email notifications do not exist in MVP.

### S10 — Profile (`/app/me`)
Avatar (change with compression), display name, bio (≤ 160), username (change allowed every 30 days from R3), who can find me (`discoverability`: All members / Exact username only). Save is explicit; success shown after server confirmation.

### S16 — Settings and privacy (`/app/me/settings`, `/app/me/privacy`)
Sections: **Account** (signed-in method, sign out, **sign out of all devices**), **Privacy** (discoverability, "Show when I've read messages" toggle), **Notifications** (mute defaults; richer options R3), **Blocked members** (list, unblock), **Your data** (Export my data, Delete my account with the 14-day grace explained and a final confirmation naming consequences), **About** (version, notice, terms, rules, "Mirach is not end-to-end encrypted"), **Appearance** (theme).

## 9. Calls (R4)

### S13 — Calls
- **Components:** call history (name, type, time, duration, missed/declined), start-call buttons in a direct chat header, **incoming-call overlay** (caller, audio/video, Accept, Decline, 45 s timeout), outgoing "Ringing…" with Cancel, in-call view: audio controls (mute, device picker where supported, End), video (camera toggle, mute, End, tiles), connection-quality and reconnecting indicators.
- **States:** permission denied (explains how to re-enable in browser settings), device unavailable, busy ("Already in a call"), declined, missed, failed, **calls unavailable** (quota used up — "Calling is paused until next month."), blocked/not connected (button absent).
- **Copy rule:** never imply ringing when the browser is closed; no end-to-end encryption claims. No recording indicator is needed because recording does not exist.

## 10. Games, feed and stories (later)

- **S14 Games (R5):** lobby (invite a connection, active sessions), game room (board, clear turn indicator, legal-move feedback, forfeit, rematch), result shown only after server confirmation. States: waiting for opponent, opponent disconnected (state preserved), timed out/forfeit.
- **S11 Community (R3 announcements, R6 feed):** announcement list (pinned first) then feed with composer showing **audience label before posting**; reactions/comments; report action on every item.
- **S12 Stories (R6):** tray, viewer with progress segments, expiry time visible, "Seen by" list for the author; audience chosen before posting; expired stories are unavailable.
- None of these appear in navigation until their release ships.

## 11. Administration and moderation

### S17 — Admin dashboard (`/admin`)
- **Overview:** counts (pending requests, active members, open reports, expiring invitations), quota panel (Supabase and LiveKit usage entered or linked by the owner — informational), recent audit entries. No private content anywhere.
- **Requests:** applicant username, display name, message, date, invitation context; Approve / Reject with confirmation and optional reason code.
- **Members:** search; status/role badges; Suspend / Restore (confirm; explains immediate effect); Role change (owner only; last-owner guard messaging).
- **Invitations:** create (expiry, max uses, note) → **raw code shown once** in a modal with Copy and a warning that it cannot be shown again; list with uses/expiry/status; Revoke.
- **Settings:** registration open, require approval for all, group size cap.
- **Audit log (R3):** read-only table (actor, action, subject, time); before R3, entries exist in the database but have no UI.
- **States:** every table has loading/empty/error; destructive actions need confirmation; admin entry hidden from ordinary members.

### S18 — Moderation and reports (`/admin/reports`)
Queue (status, category, reporter, target, age), detail view showing **only the evidence snapshot** (reported message and preceding context captured at report time) and report metadata, actions: Dismiss, Warn (notification to the member), Escalate to admin; **Suspend is available to admins/owners only**; resolution reason; every action logged. No general message browser exists.
Member-side report sheet: category, optional details, a plain list "These messages will be shared with moderators: …", Submit; confirmation afterwards.

## 12. Component architecture

- **Primitives** (`src/components/ui`): Button, IconButton, TextField, TextArea, Checkbox, Switch, Select, Avatar, Badge/Chip, Dialog/Sheet, Toast, Tabs, Skeleton, EmptyState, ErrorState, Banner (offline/reconnecting), VisuallyHidden, Tooltip. Built with accessible semantics (consider a headless accessible library after dependency review).
- **Layout:** AppShell (rail/tab bar), ListDetailLayout, PageHeader, AdminShell.
- **Feature modules** (`src/features/<feature>`): `auth`, `onboarding`, `membership`, `people`, `connections`, `chats` (ConversationList, MessageThread, MessageBubble, Composer, GroupInfo), `media` (ImagePicker, ImageViewer, upload hooks), `notifications`, `profile`, `settings`, `reports`, `admin`, later `calls`, `games`, `community`.
- **State:** server state via TanStack Query; realtime signals invalidate/append queries; local UI state in components; session/membership state in one provider (UX only). No global store unless a need is documented.
- **Data access** only through `src/lib/api/*`; components never call Supabase directly (keeps provider swappable and testable).
- **Conventions:** named exports, small components, props typed, no `dangerouslySetInnerHTML`, all strings in a messages module, every data component renders loading/empty/error/revoked states.

## 13. Key user flows

```mermaid
flowchart TD
  A["Open Mirach"] --> B{"Signed in?"}
  B -- No --> L["S1 Sign in with Google"]
  L --> B
  B -- Yes --> C{"Membership status"}
  C -- "profile incomplete" --> J["S2 Join: username, terms, code or request"]
  C -- pending --> P["S3 Pending"]
  C -- "rejected or suspended" --> R["S3 Notice"]
  C -- active --> H["S4 Chats"]
  J -- "valid code" --> D{"Approval for all?"}
  D -- No --> H
  D -- Yes --> P
  J -- "request" --> P
  P -- "admin approves" --> H
  H --> PE["S5 People: search and request"]
  PE --> CH["S7 Chat after acceptance"]
  H --> CH
```

Message send flow: compose → pending bubble → RPC → server `seq` returned → bubble confirmed → peer receives signal → fetches message → reads → `mark_read`. Failure at any step shows the explicit retry state; nothing is shown as delivered unless confirmed.

## 14. Responsive behavior

Mobile-first CSS; fluid layouts with `min()`/`clamp()`; no fixed widths that overflow; composer and dialogs respect viewport height and safe-area insets; the on-screen keyboard must not hide the composer; no essential action depends on hover; long-press actions have visible menu equivalents; images use `max-width: 100%` and constrained heights; tables in admin scroll horizontally inside a container. Test current stable Chrome, Edge, Firefox and Safari on desktop and mobile; record exact versions in release notes.

## 15. Accessibility (WCAG 2.2 AA target)

- Semantic landmarks, headings and lists; one `h1` per screen; skip link.
- Full keyboard operation; logical tab order; visible focus (§2.2); Escape closes dialogs/sheets and returns focus to the trigger; focus trapped inside modals.
- Labels and error text programmatically associated; errors announced (`aria-live="polite"` for non-blocking, `assertive` only for blocking errors).
- New messages announced politely for the open conversation without announcing every keystroke or typing indicator; unread counts have text alternatives.
- Contrast per §2.1; status never by color alone; target size ≥ 44 px.
- Icon-only buttons have accessible names; images have alt text (decorative = empty alt); avatars default to the name.
- Respect `prefers-reduced-motion`, `prefers-color-scheme`, text zoom to 200% and reflow at 320 px width.
- Test with keyboard-only, a screen reader on at least one desktop and one mobile browser, and an automated checker (axe) in CI for key screens.

## 16. Shared states and content guidance

Every data-driven screen defines: **loading** (skeleton, no layout jump), **empty** (what this is, what to do next), **error** (what happened in plain words, safe retry, no stack traces or IDs), **offline/reconnecting** (persistent banner; composer queues or blocks with an explanation), **permission-denied / access-revoked** (neutral explanation, a way back; never reveal whether a resource exists), and **success** (shown only after server confirmation).

Copy: calm, plain, respectful; never blame the user; no jargon; never expose database errors, tokens, internal IDs, SQL, or security-sensitive reasons ("That didn't work. Please try again." beats "RLS violation"). Invitation and sign-in errors stay generic. Dates/times in the viewer's locale, relative for recent items with absolute time on hover/long-press and in assistive text.

## 17. Design acceptance checklist

- Works from 320 px to wide desktop without horizontal page scroll.
- Sign-in is clearly distinct from community approval.
- Pending/rejected/suspended users never see member-only screens or data.
- No screen or response exposes email or private identifiers.
- Connection, block and chat state reflect server-confirmed truth.
- Private media never renders through a public or permanent URL.
- All controls are keyboard-operable with accessible names; focus is always visible.
- Every screen has loading, empty, error, offline and revoked states where applicable.
- Only released features appear as enabled navigation.
- The not-end-to-end-encrypted and 18+ statements appear in onboarding and Settings → About.
