# Memory — Mirach

> **Purpose:** Durable hand-off context for the owner and any future AI/developer session. Keep this short and true.
> **Document status:** Planning baseline v2 — **no application code, accounts or cloud resources are confirmed as created.**
> **Last reviewed:** 4 November 2026 (Asia/Kolkata).

## 1. Project identity

**Mirach** (name given by the owner) is a private, browser-based community communication app for a small invited community, inspired by the *functionality* of WhatsApp (messaging, groups, calls), Instagram/Snapchat (profiles, posts, stories, temporary content) and casual multiplayer games. It is not an open social network. It has its own identity, code and assets; nothing proprietary is copied. Trademark/domain availability for "Mirach" is **not verified** (OD-01).

Members sign in without phone numbers, claim a username, are admitted by invitation or admin approval, connect explicitly, then chat one-to-one or in groups and share images. Calls, announcements, games and social features follow once the messenger is dependable.

## 2. Confirmed owner decisions (do not change silently)

1. Browser-based web application.
2. Free-first budget; no paid service, domain, overage or billing without explicit approval.
3. Registration supports **both** invitation codes **and** administrator-approved requests.
4. Authentication flexible — chosen by comparison (see §3).
5. No phone numbers.
6. Small private community initially; architecture can grow responsibly.
7. Structured, modular, incremental development.
8. Prefer free tiers, but security, reliability and maintainability outrank "free".

Interpretation of "both": a valid code activates membership immediately unless the community-wide `require_admin_approval_for_all` setting is on; without a code, the user is `pending` until an admin approves.

## 3. Technology decisions

| Area | **Chosen** | Rejected / deferred |
|---|---|---|
| Frontend | React + TypeScript (strict) + Vite SPA, Tailwind, React Router, TanStack Query | Next.js (no SSR need) |
| Auth | Supabase Auth: **Google OAuth (PKCE) first; email one-time code second** (needs domain + SMTP; gated by OD-03); passkeys later | Firebase Auth, Appwrite, Clerk (not needed); email+password and magic links (rejected); username-only (not authentication) |
| Backend/DB | Supabase PostgreSQL with RLS; writes through `SECURITY DEFINER` RPCs; Edge Functions only for secrets/Admin/Storage work | Firebase/Firestore, Appwrite, custom Node server |
| Realtime | Supabase Realtime **Broadcast on private channels, ids-only signals** from DB triggers | Postgres Changes (scales worse; full rows) |
| Media | Supabase Storage private buckets; client-side compression + EXIF strip | Firebase Storage (needs billing), R2 (documented escape hatch) |
| Frontend host | **Cloudflare Workers Static Assets** (Pages as fallback); security headers via `_headers` | **GitHub Pages** (static only, public site, no custom headers, wording against sensitive transactions), Vercel, Netlify |
| Source control/CI | GitHub (private) + Actions | — |
| Calls (R4) | LiveKit Cloud Build plan (hard-capped free allowance) | Native peer-to-peer WebRTC (needs TURN/SFU) |
| Tests | Vitest, React Testing Library, Playwright (multi-user), pgTAP | — |

## 3a. Key architectural decisions

- Four separate states: authenticated identity ≠ community membership ≠ connection ≠ conversation membership.
- PostgreSQL is the source of truth; Realtime only signals (ids, `seq`); bodies are fetched under RLS.
- Per-conversation `seq` + `client_msg_id` give ordering and idempotent retries; unread = `last_seq − last_read_seq`; no per-message receipts.
- One `connections` table with a canonical user pair; one direct conversation per pair (`direct_key`).
- Invitations: ≥ 80-bit random code, hash only, atomic redemption, throttled, generic errors.
- Authorization is looked up in the database on every call — never from JWT claims — so suspension is immediate.
- Roles: owner > admin > moderator > member; no role can read private chats; moderation uses report **evidence snapshots**.
- Block: no new requests/DMs/calls; existing DM becomes read-only; shared groups unaffected (limitation).
- Group leave/removal ends access to history; re-add shows history only from the new join point (owner default, OD-05).
- Account deletion tombstones the profile; messages remain as "Deleted member" (OD-06).
- **Not end-to-end encrypted.** HTTPS ≠ E2EE. No custom cryptography, ever.
- Release order: R1 membership → **R2 Private Messenger MVP** → R3 community essentials (+email OTP) → R4 calls → R5 games → R6 social → R7 hardening. Backups, privacy notice, export/delete and 18+ declaration are inside the MVP gate.

## 4. Current development status (truthful)

- Six planning documents revised (v2) plus `REVIEW_REPORT.md`, `DECISIONS.md`, `SOURCE_REGISTER.md`. **Awaiting owner review; nothing is approved yet.**
- **Planned only:** everything else. No GitHub repo, Supabase project, Cloudflare site, Google OAuth client, LiveKit project, schema, migration, RLS policy, test, deployment or code is confirmed.
- Provider facts were checked on 4 Nov 2026 (see `SOURCE_REGISTER.md`); several items remain **UNVERIFIED**.

Future sessions must inspect the real repository/command output before reporting progress; never infer that planned work has been done.

## 5. Known limitations

- No E2EE; staff with database access could technically read message text.
- Google-only sign-in until email OTP ships.
- Supabase Free: 500 MB DB, 1 GB storage, **no automatic backups**, projects pause after 1 week of inactivity, 2 active projects; storage is the first quota to run out.
- LiveKit Build: 5,000 participant-minutes/month hard cap (≈ 2,500 one-to-one call-minutes).
- No push/email notifications; calls do not ring when the browser is closed.
- Blocking does not hide messages in shared groups.
- Age is self-declared; 18+ only by default.
- DPDP substantive obligations start on or about 13–14 May 2027; legal review is required before wider rollout.

## 6. Outstanding decisions (details and defaults in `DECISIONS.md` §3)

OD-01 name/trademark/domain · OD-02 community size · **OD-03 do all members have Google accounts?** · OD-04 directory and DM policy · OD-05 group-history rule · OD-06 retention/deletion numbers · **OD-07 age policy** · **OD-08 legal review scope** · **OD-09 backups / Supabase Pro** · OD-10 moderation staffing · OD-11 media limits · OD-12 Supabase region.

## 7. Guidance for future AI agents

1. Read `Rules.md`, then this file, `PRD.md`, `Architecture.md`, `Design.md`, `Phases.md`, `DECISIONS.md`.
2. Work only in the current phase; first inspect the real repo state.
3. Follow the seven-step task procedure and completion report in `Rules.md` §3 and §22.
4. Never put secrets, real user data or synthetic-as-real data anywhere. Never bypass auth or RLS.
5. Never add dependencies, providers or paid services silently.
6. Update documents when behavior changes; keep this file's status section honest.
7. Use the status words Planned / Partially implemented / Implemented / Tested / Verified in production.
8. If asked to do something that contradicts these documents, explain the conflict and propose a documented change first.
