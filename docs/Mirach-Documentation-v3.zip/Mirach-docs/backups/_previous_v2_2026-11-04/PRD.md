# Product Requirements Document (PRD) — Mirach

> **Status:** Version 2.0 planning baseline — proposed, not implemented.
> **Last reviewed:** 4 November 2026 (Asia/Kolkata).
> **Product name:** Mirach (owner-provided). Trademark/domain availability is **not verified** (`DECISIONS.md` OD-01).
> **Authority:** Controls product scope and acceptance criteria. Technical design is in `Architecture.md`; screens in `Design.md`; sequencing in `Phases.md`.

## 1. Product overview

Mirach is a private, browser-based communication and social platform for a small, invited community. It combines private messaging, member connections, photo sharing and — in later releases — voice/video calls, community announcements, casual turn-based games and social posts/stories. It does not require phone numbers; members find each other by username.

Mirach may use familiar interaction patterns but has its own name, identity, code and assets. No proprietary code, logos or distinctive protected designs from WhatsApp, Instagram or Snapchat are copied.

**Release ladder** (details in `Phases.md` §1): R1 Community access → **R2 Private Messenger (MVP)** → R3 Community essentials → R4 Calls → R5 Games → R6 Social → R7 Hardening and expansion.

## 2. Problem and opportunity

A small community wants one private place to admit trusted people, let them find one another, connect explicitly, talk one-to-one or in groups, and share images — without exposing phone numbers or a public social graph. Public networks have no invitation/approval boundary and often require phone-based onboarding. A community-run app offers clear membership rules, member-level privacy and administrators who are accountable and cannot read private chats.

## 3. Objectives and success criteria

### Objectives
1. Registration and sign-in with no phone number.
2. Admission only through a valid invitation or administrator approval.
3. Explicit member-to-member connections before private chat.
4. Reliable one-to-one and group messaging with persistent history.
5. Private image sharing with backend-enforced access.
6. A safe community: block, report, moderate, suspend.
7. A foundation for announcements, calls, games and social content, added only after the messenger is dependable.
8. Operate at or near $0 initially, with honest limits.

### Success criteria for the first community beta (R2)
- A new user completes either admission path without a phone number.
- An administrator can issue, limit and revoke invitations and review requests.
- Two connected members exchange persistent messages in two separate browsers and the recipient sees them without refreshing under normal conditions (observed delay measured and reported, not promised).
- A non-participant cannot read, subscribe to, insert into, or download from a conversation by calling APIs directly (negative tests pass).
- No open critical or high-severity authorization defect.
- A restore drill from backup has been performed successfully.
- The owner has reviewed quotas, the privacy notice, retention, and the known limitations in §18.

Vanity metrics (total sign-ups) are not success measures.

## 4. Target audience and roles

**Target audience:** an invited community of adults (initially India-based), starting with roughly 10–100 members. Minors are out of scope pending an owner decision and legal advice (OD-07); the default is **18+ only**.

| Role | Definition | Key abilities |
|---|---|---|
| Visitor | Not signed in | See landing page and sign-in |
| Applicant | Signed in; profile incomplete, `pending`, or `rejected` | Complete onboarding; see own status; sign out; delete own account |
| **Member** | `memberships.status = active`, role `member` | Search directory, connect, chat, share images, report, block, manage own privacy |
| **Moderator** | Member with role `moderator` | Review reports and evidence snapshots; dismiss, warn or escalate to an admin (cannot suspend, cannot see invitations or settings) |
| **Admin** | Member with role `admin` | Manage invitations, membership, settings, moderation |
| **Owner** | Member with role `owner` (initially one) | Everything an admin can; create/remove admins and moderators; cannot be demoted by others; at least one owner always exists |

Hierarchy: owner > admin > moderator > member. **No role grants access to private conversation content**; moderators and admins see only report evidence snapshots.

## 5. Core product rules

1. Authentication does not grant community membership.
2. A valid invitation grants immediate membership by default; if `require_admin_approval_for_all` is on, invited applicants wait in `pending` as well.
3. Without an invitation a user can request membership and remains `pending` until approved.
4. Only `active` members can use member features.
5. An active member is not automatically connected to anyone.
6. Direct messaging requires an accepted connection and no block.
7. Group access requires current group membership. Leaving or removal ends access to all earlier history and attachments (owner default, OD-05); re-adding grants history only from the new join point; remaining members keep their copy under the retention policy.
8. Blocking prevents new connection requests, new direct conversations and calls in both directions; an existing direct chat becomes read-only; shared groups are unaffected (documented limitation).
9. Email and provider identifiers are private. Community discovery uses username and display name only.
10. Roles, membership status, invitation use, message sender, sequence numbers, game results are set by the backend only.
11. Mirach never claims end-to-end encryption (§18).

## 6. Functional requirements

**Priority:** P0 = required for MVP (R1–R2); P1 = next releases (R3–R4); P2 = later (R5–R6); P3 = future possibility, not committed.
**Phase** refers to `Phases.md`. Architecture references are in `Architecture.md`.

### 6.1 Identity and account access (Arch §4, Design §5.1–5.2)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-AUTH-01 | P0 | Sign in with Google OAuth; no phone field or SMS anywhere | Works for a Google account with verified email; no phone prompt exists; email never visible to other members | 2 |
| FR-AUTH-02 | P0 | Unique community username | Normalized lowercase `[a-z0-9_]`, 3–20 chars; reserved names rejected; DB unique constraint is authoritative | 2 |
| FR-AUTH-03 | P0 | Display name, optional avatar, short bio | Only approved fields in the directory; avatar via private bucket after compression | 2 |
| FR-AUTH-04 | P0 | Sign out; sign out of all devices | Local and global sign-out both end sessions; suspended users cannot refresh | 2 |
| FR-AUTH-05 | P0 | Expired/invalid sessions handled safely | User is returned to sign-in with a neutral message; no data flash | 2 |
| FR-AUTH-06 | P1 | Email one-time-code sign-in as a second method | Only after custom SMTP + owned domain are configured and tested; rate-limited; account-linking behavior tested | 6 (earlier if OD-03 requires) |
| FR-AUTH-07 | P1 | Username change | At most once per 30 days; old name reserved 30 days | 6 |
| FR-AUTH-08 | P3 | Passkeys | Revisit when Supabase passkeys leave beta | 10 |

### 6.2 Community onboarding and administration (Arch §4.3–4.5, Design §5.3–5.4, §11)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-MEM-01 | P0 | Join with invitation code | Code checked server-side; expired/revoked/exhausted/invalid return the same generic error; `max_uses` cannot be exceeded under concurrency | 2 |
| FR-MEM-02 | P0 | Request membership without a code | Pending request stored; user sees pending screen; no member data exposed | 2 |
| FR-MEM-03 | P0 | Admin approves/rejects requests | Only admin/owner; status + audit record written atomically; rejected users may re-apply after 30 days | 2 |
| FR-MEM-04 | P0 | Admin creates, limits, expires, revokes invitations | Raw code shown once; only hash stored; default 1 use / 7 days; codes can only grant `member` | 2 |
| FR-MEM-05 | P0 | Admin suspends/restores members | Suspended user loses access immediately, including open sessions and channels | 2 |
| FR-MEM-06 | P0 | Community-wide "require approval for all" setting | Protected setting changes invited applicants from `active` to `pending` | 2 |
| FR-MEM-07 | P0 | Owner provisioned safely | No UI/client path can self-assign a role; bootstrap function refuses if an owner exists | 2 |
| FR-MEM-08 | P0 | Role management | Only owner assigns admin/moderator; cannot change own role; last owner cannot be removed | 2 |
| FR-MEM-09 | P0 | Privileged actions are audited | Every admin/mod action writes an append-only record without secrets or message text | 2 |
| FR-MEM-10 | P1 | Admin audit log viewer | Read-only, filterable | 6 |
| FR-ADM-01 | P0 | Admin overview | Counts: pending requests, active members, open reports, unused/expiring invitations; no private content | 2, 5 |

### 6.3 Directory, profiles and connections (Arch §6.3, §7, Design §6)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-CON-01 | P0 | Search active members | Min 3 characters; page ≤ 20; rate-limited; allowed fields only | 3 |
| FR-CON-02 | P0 | Send connection request | Active both sides; no self, duplicate, block or cooldown violation | 3 |
| FR-CON-03 | P0 | Accept / decline | Only the recipient; server updates state; declined requester waits 7 days | 3 |
| FR-CON-04 | P0 | Cancel pending request | Only the sender | 3 |
| FR-CON-05 | P0 | Remove connection | Row removed; direct chat becomes read-only until reconnected | 3 |
| FR-CON-06 | P0 | Block / unblock | Effects per core rule 8; confirmed by server before UI shows it | 3 |
| FR-CON-07 | P0 | Private identifiers stay private | Email, auth subject, moderator notes never appear in any member-readable response | 3 |
| FR-CON-08 | P1 | Discoverability setting | `members` (default) or `exact_username` only | 6 |

### 6.4 Messaging (Arch §6.3, §9, Design §7)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-MSG-01 | P0 | Start direct conversation | Requires accepted connection, no block; existing pair conversation returned (no duplicates) | 4 |
| FR-MSG-02 | P0 | Create group | Active member creates; members are the creator's connections; creator is group admin; size ≤ 50 | 4 |
| FR-MSG-03 | P0 | Send/receive text in realtime | Message persisted with server `seq`; second browser receives a signal and renders it without manual refresh | 4 |
| FR-MSG-04 | P0 | History | Participants only; newest-first cursor pagination (≤ 50); stable order | 4 |
| FR-MSG-05 | P0 | Group admin manages members | Add/remove by group admin; removed member loses access immediately | 4 |
| FR-MSG-06 | P0 | Leave group | Access to history ends; system message posted | 4 |
| FR-MSG-07 | P0 | Reliable delivery | Retry with the same `client_msg_id` never duplicates; reconnect fetches missed `seq` range | 4 |
| FR-MSG-08 | P0 | Unread counts and read position | Unread = `last_seq − last_read_seq`; read cursor is monotonic and server-stored | 4 |
| FR-MSG-09 | P1 | Edit (15 min) and delete-for-everyone | Sender only; tombstone shown; truthful "edited/deleted" labels | 6 |
| FR-MSG-10 | P1 | Typing indicator | Private channel, best-effort, never stored | 6 |
| FR-MSG-11 | P1 | Reactions (fixed emoji set) and replies | Participants only | 6 |
| FR-MSG-12 | P1 | Mute conversation | Per-member; suppresses badges | 6 |
| FR-MSG-13 | P1 | "Seen" in direct chats | Based on peer `last_read_seq`; per-user opt-out (default on) | 6 |

### 6.5 Media (Arch §10)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-MEDIA-01 | P0 | Share images in a conversation | Client resizes/re-encodes (EXIF removed) then uploads to a private bucket; attachment row holds path and metadata | 5 |
| FR-MEDIA-02 | P0 | Only participants can view | Pending, signed-out, unrelated and former members are denied; guessed paths fail | 5 |
| FR-MEDIA-03 | P0 | Type/size/quota limits | JPEG/PNG/WebP only, ≤ 10 MB at bucket level; per-user daily cap (30); SVG/HTML rejected | 5 |
| FR-MEDIA-04 | P2 | Video sharing | Disabled until quota/egress testing and owner approval | later |
| FR-MEDIA-05 | P3 | Voice notes, files | Not committed | — |

### 6.6 Notifications (Arch §9)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-NOT-01 | P0 | In-app notifications and badges | Connection requests/acceptances, membership decisions, unread chats; no message bodies in notification rows | 4 |
| FR-NOT-02 | P1 | Notification preferences | Per-conversation mute; global quiet toggle | 6 |
| FR-NOT-03 | P3 | Browser push | Separate design; permission, lifecycle, secure delivery; not promised for closed browsers | 10 |

### 6.7 Safety and moderation (Arch §6.4, §13)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-SAFE-01 | P0 | Report a member or message | Reporter is told which messages are shared; evidence snapshot stored | 5 |
| FR-SAFE-02 | P0 | Moderation queue | Moderators/admins act from snapshots only; actions audited | 5 |
| FR-SAFE-03 | P0 | Rate limiting | Messages (30/min), connection requests, searches, invitation attempts (5 failed/hour), uploads | 3–5 |
| FR-SAFE-04 | P0 | Suspension takes effect immediately | See FR-MEM-05 | 2 |

### 6.8 Privacy and account control (Arch §4.6, §14)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-PRIV-01 | P0 | Privacy notice, terms and community rules shown before access | Versioned; acceptance recorded; states **not end-to-end encrypted** and 18+ only | 5 (draft shown from 2) |
| FR-PRIV-02 | P0 | Export my data | Member receives a JSON file of their profile, connections and authored messages | 5 |
| FR-PRIV-03 | P0 | Delete my account | 14-day grace; tombstone profile; objects deleted; messages remain as "Deleted member" per retention rule | 5 |
| FR-PRIV-04 | P0 | Retention jobs | Evidence, attempts, notifications, stale pending profiles purged per schedule | 5 |
| FR-PRIV-05 | P0 | Age declaration | 18+ confirmation recorded at onboarding (a declaration, not verification) | 2 |

### 6.9 Community essentials (R3)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-COM-01 | P1 | Announcements | Admin/moderator posts; all active members read; pinned; not a chat | 6 |
| FR-COM-02 | P3 | Polls, events | Not committed; revisit after R4 | — |

### 6.10 Calls (R4; Arch §11, Design §9)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-CALL-01 | P1 | One-to-one voice call | Caller/callee authorization, no block, server-issued token ≤ 10 min | 7 |
| FR-CALL-02 | P1 | Accept/decline/timeout/cancel/missed | Server-side transitions; 45 s ring timeout | 7 |
| FR-CALL-03 | P1 | One-to-one video | Camera/mic permission failures handled | 7 |
| FR-CALL-04 | P1 | Quota guard | Calls disabled with a clear message when the free allowance is used up; no paid overage | 7 |
| FR-CALL-05 | P0 (rule) | No call recording | No recording path exists | 7 |
| FR-CALL-06 | P3 | Group calls, voice rooms | Not committed | — |

### 6.11 Games (R5)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-GAME-01 | P2 | Invite a connection to a game | Only invitee joins the private session | 8 |
| FR-GAME-02 | P2 | Turn-based game (tic-tac-toe first) | Moves validated in the database; out-of-turn/duplicate moves rejected | 8 |
| FR-GAME-03 | P2 | Persist state and results | Browser cannot set moves, winner or score | 8 |
| FR-GAME-04 | P2 | Resume and forfeit | Reconnect shows authoritative state; timeout forfeits | 8 |
| FR-GAME-05 | P2 | Modular games | Rules separated from invite/session infrastructure | 8 |

### 6.12 Social (R6)

| ID | Pri | Requirement | Acceptance criteria | Phase |
|---|:-:|---|---|---|
| FR-SOC-01 | P2 | Posts and community feed | Audience chosen and shown before publishing; enforced on reads and media | 9 |
| FR-SOC-02 | P2 | Comments and reactions | Audience-only; rate-limited; reportable | 9 |
| FR-SOC-03 | P2 | Stories | Expire by server time; expired content unretrievable by API or path | 9 |

## 7. User stories (acceptance = the FRs above)

- **Visitor:** I can sign in with Google without giving a phone number so that I can apply to join. *(FR-AUTH-01)*
- **Applicant:** I can enter an invitation code or request access, and see where I stand. *(FR-MEM-01/02)*
- **Member:** I can find people by username and send a connection request. *(FR-CON-01/02)*
- **Member:** I can chat one-to-one and in groups and see new messages immediately and after reconnecting. *(FR-MSG-03/07)*
- **Member:** I can share a photo knowing only that conversation can open it and its location data is stripped. *(FR-MEDIA-01/02)*
- **Member:** I can block or report someone and be told exactly what a report shares. *(FR-CON-06, FR-SAFE-01)*
- **Member:** I can export or delete my data. *(FR-PRIV-02/03)*
- **Admin:** I can create single-use invitations, approve or reject requests, and suspend a member. *(FR-MEM-03/04/05)*
- **Moderator:** I can review a report's evidence and act without a general message browser. *(FR-SAFE-02)*
- **Owner:** I can add/remove admins and be sure the community always has an owner. *(FR-MEM-07/08)*
- **Member (R4):** I can call a connection and see a clear message when calling is unavailable. *(FR-CALL-01/04)*
- **Member (R5):** I can play a turn-based game with a connection and rejoin after disconnecting. *(FR-GAME-02/04)*

## 8. Key user journeys

**A — Invitation:** sign in with Google → choose username/display name → confirm 18+ and accept notice → enter code → server validates → `active` (or `pending` if approval-for-all) → dashboard or waiting screen.
**B — Request:** sign in → profile → submit request → pending screen → admin decision → next visit shows result (in-app notification).
**C — Connect and chat:** search username → request → recipient accepts → open chat → send message → recipient sees it live.
**D — Group:** create group from connections → add members → chat; removed member loses access immediately.
**E — Image:** pick image → preview (compressed) → upload → message appears → participants view via short-lived link.
**F — Report:** long-press/menu on message → choose reason → see what will be shared → submit → moderator reviews snapshot.
**G — Call (R4), H — Game (R5):** see Architecture §11–12.

## 9. Non-functional requirements

- **Security:** RLS and least-privilege grants on every exposed table; server-authoritative state; secrets server-side; negative authorization tests for every private resource; security headers and CSP.
- **Reliability:** database is the source of truth; idempotent writes; reconnect catch-up; actionable error states. Free plans are prototype-grade, not uptime guarantees.
- **Performance (targets to be validated, not promises):** bounded queries and page sizes; first meaningful load of the shell is a small static bundle; realtime text typically visible within a couple of seconds on ordinary broadband (measure with two real sessions and report).
- **Compatibility:** latest stable Chrome, Edge, Firefox and Safari (desktop and mobile); record exact versions per release.
- **Accessibility:** WCAG 2.2 AA as the target — keyboard operation, visible focus, semantic HTML, contrast, screen-reader announcements, reduced motion (`Design.md` §15).
- **Maintainability:** feature-based modules, strict TypeScript, versioned migrations, CI checks, documented environments.
- **Internationalization readiness:** English UI first; strings centralized; times shown in the viewer's locale/timezone, stored in UTC.
- **Observability:** request IDs, error classes; no content in logs.
- **Data durability:** tested export/backup/restore before real data; stated RPO/RTO.

## 10. Data and privacy requirements

- Collect only: Auth identity, username, display name, optional avatar/bio, membership status, relationships, conversation content the user sends, age declaration, consent record.
- Never request phone numbers, contacts, birth dates or precise location; strip EXIF from images.
- Show who can see what before the user acts (profile, group, announcement, post).
- Define and publish retention: messages kept until deleted by sender/conversation end or account policy; evidence 90 days after resolution; audit log 1 year; notifications 30 days; stale pending profiles 30 days.
- Provide export and deletion (FR-PRIV-02/03).
- Privacy notice and terms must exist and be reviewed by suitable counsel before any member outside the trusted test group (`Architecture.md` §14). DPDP substantive obligations take effect on or about 13–14 May 2027.
- State plainly: administrators cannot browse chats; Mirach is **not end-to-end encrypted** and staff with database access could technically read message text.

## 11. Cost and hosting requirements

Target: **$0/month** to start. GitHub (source), Cloudflare (static frontend), Supabase Free (backend), LiveKit Build only when calls start. Facts and quotas are in `Architecture.md` §2, §16, §18; arithmetic in `REVIEW_REPORT.md` §6.

- No upgrade, overage, domain purchase or billing activation without the owner's explicit approval.
- Quota monitoring is part of Phase 5's definition of done.
- Foreseeable paid triggers: backups/no pausing (Supabase Pro, from $25/month), storage beyond 1 GB, calls beyond 5,000 participant-minutes, a domain for email OTP.

## 12. MVP scope (R1 + R2)

**In:** Google sign-in; username/profile; invitation and request flows; approval-for-all setting; admin console (invitations, requests, members, roles, reports, settings, audit write); directory search; connections; blocks; DMs and groups with realtime, history, unread, read cursor; compressed private image sharing; in-app notifications; reports with evidence snapshots; export and delete account; privacy notice/terms/rules; backup + restore drill; quota monitoring.

**Out (MVP):** email OTP, edit/delete, reactions, typing, mute, announcements, calls, games, feed/stories, video, push, PWA, E2EE.

## 13. Out of scope (all releases unless a new decision is recorded)

Public or anonymous registration; phone-number login or lookup; contact upload; payments, ads, marketplace, gambling; call recording; native apps; fast-action multiplayer; live streaming; app-level E2EE (until separately designed); medical or financial services; global "who is online" list; "friend activity" feeds.

## 14. Product refinement — feature classification

| Feature | Class | User value | Complexity | Security / privacy | Infra impact | Priority |
|---|---|---|---|---|---|---|
| Invitations + admin approval | Essential (MVP) | Defines the community | Medium | Brute-force, bootstrap | Low | P0 |
| Connections, DMs, groups, images | Essential | Core use | High | RLS, media access | Storage/egress | P0 |
| Report/block/suspend, audit | Essential | Safety | Medium | Evidence snapshots | Low | P0 |
| Export + delete account | Essential | Trust, DPDP readiness | Medium | Deletion completeness | Low | P0 |
| Community announcements | Next release | Reaches everyone without chat noise | Low | Low | Low | P1 |
| Message reactions, replies, edit/delete | Next release | Expressiveness | Low–Med | Tombstones, edit window | Low | P1 |
| Conversation mute, notification preferences | Next release | Calm | Low | Low | Low | P1 |
| Email OTP (second sign-in) | Next release (gated) | Inclusion of non-Google users | Medium | SMTP, linking | Domain cost | P1 |
| Voice, then video calls | Next release | Parity with messengers | High | Token authorization | LiveKit quota | P1 |
| Turn-based games | Later | Fun, low storage cost | Medium | Server-side validation | Low | P2 |
| Posts, comments, stories | Later | Social glue | High | Audience rules, media | Storage-heavy | P2 |
| Polls, events | Future | Community coordination | Low–Med | Low | Low | P3 |
| Web push, PWA install | Future | Reach when closed | High | Subscription security | Push service | P3 |
| Passkeys | Future | Stronger sign-in | Medium | Beta status | Low | P3 |
| Group calls, voice rooms | Future | Gatherings | High | Moderation | LiveKit cost | P3 |
| End-to-end encryption | Future (separate project) | Server-blind privacy | Very high | Key management | Low | P3 |
| Shared albums | Deferred | Nice-to-have | Medium | Media access | Storage-heavy | defer |
| Global presence / last seen | **Rejected for MVP** | Minor | Low | Privacy cost, Realtime load | Connections | rejected |
| Friend activity feed, suggested members | **Rejected** | Engagement | Medium | Social-graph exposure | Low | rejected |
| Public directory/profiles | **Rejected** | — | — | Violates private-by-default | — | rejected |

## 15. Dependencies and assumptions

- Owner can create and control GitHub, Cloudflare, Supabase and Google Cloud (OAuth client) accounts; LiveKit later.
- Initial members all have Google accounts **(unconfirmed — OD-03)**.
- Provider quotas are snapshots (verify at implementation). Free projects may pause and have no backups.
- Legal review is available before inviting members beyond the trusted group.
- Community size, retention numbers, group-size cap, moderation staffing remain owner decisions (`DECISIONS.md`).

## 16. Risks

| Risk | Mitigation |
|---|---|
| Scope creep before messenger is reliable | Release gates; no R3+ work before R2 acceptance |
| RLS/RPC mistake exposes data | Policies before UI; pgTAP negative tests; two-user E2E; advisor checks |
| Storage fills quickly | Client compression, caps, monitoring, Pro/R2 path |
| Free project pauses or loses data | Backups + restore drill; plan Pro before real data if downtime is unacceptable |
| Members without Google excluded | Email OTP gate (OD-03) |
| Legal obligations underestimated | 18+ default; early privacy features; counsel before wider launch |
| Calls unreliable or quota-limited | Defer; managed provider; hard-cap messaging |
| Moderator workload / abuse | Invitation controls, rate limits, block/report |
| Owner is single point of failure | Second admin appointed; documented recovery procedure |
| Misleading security claims | Rules §23 prohibits blanket claims |

## 17. Acceptance criteria — Private Messenger MVP (R2)

All of the following must be true:

1. Sign-in works without a phone number; username is unique.
2. Invitation path and no-code approval path both work; approval-for-all setting works.
3. Invitation redemption is atomic under concurrent attempts; codes are stored hashed.
4. Only the provisioned owner/admins manage membership and invitations; no client can change a role.
5. Pending, rejected and suspended users get no member data; suspension takes effect immediately.
6. Directory shows allowed fields only; no email or identifiers.
7. Connection request/accept/decline/cancel/remove/block work with server-confirmed state.
8. Direct chat requires an accepted connection and respects blocks; one conversation per pair.
9. Group chat restricted to current members; removed/left users lose access immediately.
10. Two browsers exchange persistent messages; retry does not duplicate; reconnect catches up.
11. Unread counts and read cursors are correct.
12. Image upload strips EXIF, enforces type/size, and is viewable only by authorized participants.
13. Negative tests pass for RLS, RPCs, Realtime and Storage (`Phases.md` §4).
14. No secret appears in the bundle or Git history (scan clean).
15. Report, moderation queue, audit log and account suspension work.
16. Export and delete-account work end to end.
17. Privacy notice, terms and community rules are published and accepted at onboarding; the notice says not end-to-end encrypted and 18+.
18. Backup and restore drill completed and recorded.
19. Mobile and desktop browser checks pass; accessibility basics pass.
20. Owner has reviewed quotas, retention, known limitations and open decisions.

## 18. Known limitations at MVP

- Not end-to-end encrypted; staff with database access could technically read message text.
- Google is the only sign-in method until email OTP ships (OD-03).
- No phone registration or lookup; no native app.
- No push or email notifications; closed browsers are not notified.
- Calls, games, social, video, reactions, edit/delete, announcements are not in R2.
- Free plans may pause, throttle, or run out of quota; no uptime or backup guarantee; Supabase Free has no automatic backups.
- Blocking does not hide messages in shared groups.
- Age is a declaration, not verification.
- Not legal advice; compliance is not claimed (`Architecture.md` §14).

## 19. Open decisions

Maintained in `DECISIONS.md` §3 (OD-01 … OD-12), each with a safe default and the gate by which it must be settled.
