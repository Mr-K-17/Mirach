# Phases — Mirach

> **Status:** Dependency-driven implementation roadmap v2. **No phase is complete** until its acceptance criteria are tested and recorded.
> **Last reviewed:** 4 November 2026 (Asia/Kolkata).
> **Authority:** Controls implementation order and exit gates. Requirements are in `PRD.md`; design in `Architecture.md` and `Design.md`.

## 1. Delivery strategy

Build a secure private messenger first, in vertical slices, then add features in order of dependency, risk and quota cost. No calendar dates are promised; progress is measured by tested milestones.

**What changed from the previous roadmap, and why**

| Change | Reason |
|---|---|
| Backups, privacy notice, data export/deletion and an 18+ declaration moved **into the MVP gate** (previously last) | They must exist before real people's data does; DPDP substantive obligations start on or about 13–14 May 2027 |
| New **R3 Community essentials & messenger polish** before calls | Announcements, edit/delete, reactions, mute and email OTP are cheap, valuable and remove an exclusion risk |
| **Games (R5) before Social (R6)**; calls stay before games | Games cost almost no storage; stories/feeds consume the 1 GB free storage fastest. Calls remain ahead because they are core messenger parity, but are quota-limited and device-dependent |
| Phase 4 uses Broadcast signals + `seq`, not Postgres Changes | Documented scalability/security guidance; deterministic ordering and idempotency |
| Hardening becomes a recurring gate plus a final phase | Security is not an end-of-project activity |

### Release definitions

| Release | Name | Phases |
|---|---|---|
| R0 | Foundation | 0–1 |
| R1 | Community access | 2 |
| **R2** | **Private Messenger MVP** | 3–5 |
| R3 | Community essentials and messenger polish | 6 |
| R4 | Calls | 7 |
| R5 | Games | 8 |
| R6 | Social | 9 |
| R7 | Production hardening and expansion | 10 |

**Scope split:** *MVP* = R1 + R2 (P0). *Post-MVP* = R3–R6 (P1–P2). *Future expansion* = R7 and items marked P3 in `PRD.md` §14.

## 2. Dependency roadmap

```mermaid
flowchart LR
  P0["Phase 0<br/>Approve and prepare"] --> P1["Phase 1<br/>Shell and deploy"]
  P1 --> P2["Phase 2<br/>Auth and membership"]
  P2 --> P3["Phase 3<br/>Directory and connections"]
  P3 --> P4["Phase 4<br/>Messaging"]
  P4 --> P5["Phase 5<br/>Media, safety, privacy<br/>R2 gate"]
  P5 --> P6["Phase 6<br/>Community essentials<br/>R3"]
  P6 --> P7["Phase 7<br/>Calls R4"]
  P6 --> P8["Phase 8<br/>Games R5"]
  P7 --> P9["Phase 9<br/>Social R6"]
  P8 --> P9
  P9 --> P10["Phase 10<br/>Hardening and expansion R7"]
  P5 -. "Gate C before wider rollout" .-> P10
```

Key dependencies: membership (P2) precedes everything; connections (P3) precede direct chats (P4); conversation membership (P4) precedes media authorization (P5) and call/game authorization (P7, P8); the quota and safety tooling of P5 precedes any media-heavy feature (P9). Phases 7 and 8 are independent and may be reordered by the owner after R3.

## 3. Launch gates

| Gate | When | Must be true |
|---|---|---|
| **A — first real person** | Before inviting anyone other than the owner/test accounts (during Phase 2) | Owner bootstrap done; RLS/RPC negative tests for P2 pass; encrypted backup + a first restore test; draft privacy notice and 18+ declaration shown; no secrets in repo or bundle |
| **B — R2 trusted-group release** | End of Phase 5 | `PRD.md` §17 criteria all met; quota monitoring in place; restore drill recorded; known limitations published |
| **C — wider rollout** (beyond the trusted group, or before DPDP substantive obligations apply, whichever is first) | Before inviting members outside the trusted group | Legal review completed (`DECISIONS.md` OD-07/OD-08); decision on Supabase Pro/backups (OD-09); small load test; accessibility review; incident and breach-response runbook; second admin appointed |
| **D — calls** | Start of Phase 7 | LiveKit quota understood; owner approves usage; R2 stable for ≥ 2 weeks of real use |

## 4. Testing strategy

**Layers:** unit (validation, state machines, formatters) → component (React Testing Library) → database (pgTAP via `supabase test db`: constraints, RPCs, RLS, Realtime and Storage policies) → end-to-end (Playwright, **two or more independent users**, real browsers) → manual (mobile + desktop browsers, screen reader, slow/offline network) → security review before each gate.

**Rules:** positive tests alone never pass a privacy feature; every private resource gets negative tests; bug fixes add a regression test; CI blocks merge on failing checks; synthetic data only.

**Standing negative-test matrix** (extended every phase; each row is tested through the **direct API**, not just the UI):

| Actor ↓ / Resource → | Profile directory | Connections | Conversation + messages | Realtime topic | Attachments | Admin RPCs | Audit/Reports |
|---|---|---|---|---|---|---|---|
| Signed out | deny | deny | deny | deny | deny | deny | deny |
| Pending / rejected | deny | deny | deny | deny | deny | deny | deny |
| Suspended | deny | deny | deny | deny | deny | deny | deny |
| Active member, non-participant | allowed fields only | own only | deny | deny | deny | deny | own reports only |
| Former group member | — | — | deny (history and new) | deny | deny | — | — |
| Blocked party | — | cannot request | DM read-only | — | — | — | — |
| Moderator / admin (as non-participant) | — | own only | **deny** | **deny** | **deny** | by role | evidence snapshot only |
| Forged inputs | forged `user_id`, `role`, `sender_id`, `seq`, `status` rejected everywhere | | | | | | |

**Other required suites:** invitation concurrency (many parallel redemptions of a 1-use code → exactly one succeeds); idempotent send (same `client_msg_id` twice → one row); `seq` gap-free under concurrent sends; suspension while a channel is open; MIME/size/EXIF checks; expired signed URL; rate-limit behavior; migration apply/reset from scratch; seed data is synthetic.

**Performance checks (measured, reported, not promised):** two-session message latency; history page load; search latency; a small load test (e.g. 25 simulated users) before Gate C.

## 5. Phase 0 — Approve the plan and prepare the workspace

- **Objective:** a reviewed baseline and a clean workspace.
- **Features/work:** owner reviews the six documents and `DECISIONS.md`; answers OD-01…OD-12 or accepts defaults; create private GitHub repo (README, licence decision, `.gitignore`, branch protection if available); scaffold React + TS (strict) + Vite; Tailwind and tokens; ESLint/Prettier/Vitest; add `docs/` with all documents; `.env.example`; install Supabase CLI; `supabase init`; create Supabase **staging** project (region nearest members) — production later.
- **Dependencies:** none.
- **Files/modules:** repo skeleton per `Architecture.md` §15.3; CI workflow stub; `docs/`.
- **DB changes:** none.
- **Security:** no secrets committed; secret-scan hook; two-factor on GitHub, Cloudflare, Supabase, Google accounts.
- **Tests:** `npm ci`, lint, type-check, unit, build pass locally and in CI.
- **Acceptance:** documents committed; owner can run the project; environments named; no secrets in history.
- **Risks:** owner time; unclear decisions — mitigated by defaults in `DECISIONS.md`.

## 6. Phase 1 — Frontend shell and deployment (R0)

- **Objective:** a deployed, empty but secure shell with health diagnostics.
- **Features:** app shell, router, route-guard structure, error/loading boundaries, theme tokens, offline/backend-unavailable screens; deploy to Cloudflare (Workers Static Assets via Git integration); SPA fallback; security headers file; Supabase client wiring with public config only; Google OAuth configured in dev (Google Cloud client + Supabase provider + exact redirect URLs).
- **Spike (time-boxed, record result in `DECISIONS.md`):** confirm Workers Builds free quotas, `_headers` support and SPA fallback; if unsuitable, fall back to Cloudflare Pages.
- **Dependencies:** Phase 0.
- **Files:** `src/app/*`, `src/lib/api/client.ts`, `public/_headers`, `wrangler.jsonc` (or Pages config), CI deploy.
- **DB changes:** none (extensions enabled: `pgcrypto`, `pg_cron` only if confirmed available).
- **Security:** CSP and headers verified in browser; bundle inspected for secrets; redirect allow-list exact.
- **Tests:** deployment smoke test; deep-link refresh works; backend-down shows friendly state; header check.
- **Acceptance:** push → preview deploy; production and staging use different backends; nested route refresh works.
- **Risks:** Workers vs Pages specifics; OAuth redirect mistakes.

## 7. Phase 2 — Authentication and community membership (R1)

- **Objective:** only invited or approved people become active members; admin tooling works.
- **Features:** Google sign-in (PKCE); `profiles` trigger; username claim; age/terms acceptance; invitation create/revoke/redeem; request flow; approval-for-all setting; admin console (requests, members, invitations, settings, roles); owner bootstrap; suspension with Admin-API ban and session end; audit writes; sign out / sign out everywhere; draft privacy notice.
- **Dependencies:** Phase 1.
- **Files:** `features/{auth,onboarding,membership,admin}`; `supabase/migrations/*_identity.sql`, `*_membership.sql`, `*_invitations.sql`, `*_audit.sql`; `supabase/tests/{membership,invitations,roles}.test.sql`; Edge Function `suspend-member`.
- **DB changes:** `profiles`, `reserved_usernames`, `community_settings`, `memberships`, `membership_requests`, `invitations`, `invitation_redemptions`, `invitation_attempts`, `rate_limits`, `admin_audit_log`; helper functions; RPCs listed in `Architecture.md` §8 (identity/membership/admin group); default grants revoked.
- **Security:** no direct table writes; hash-only codes; throttling; hierarchy/last-owner invariants; membership looked up per request, not from JWT claims; generic invitation errors.
- **Tests:** new/returning identity, cancellation; username collision/reserved; valid/invalid/expired/revoked/exhausted/duplicate/**concurrent** redemption; approval/rejection/re-apply cooldown; suspension immediate effect; role escalation attempts (self-promotion, admin→owner, deleting last owner) all fail; pending user cannot read members.
- **Acceptance:** `PRD.md` FR-AUTH-01…05, FR-MEM-01…09, FR-PRIV-05, FR-ADM-01 met; **Gate A** satisfied before inviting a real person.
- **Risks:** Google OAuth setup; bootstrap mistakes; RLS errors.

## 8. Phase 3 — Directory and connections

- **Objective:** members find each other and form explicit connections.
- **Features:** `search_members` (min 3 chars, ≤ 20 per page, rate-limited); member profile view; send/accept/decline/cancel/remove; block/unblock with defined effects; requests inbox; notification rows for requests.
- **Dependencies:** Phase 2.
- **Files:** `features/{people,connections}`; migration `*_connections.sql`; tests `connections.test.sql`.
- **DB changes:** `connections`, `blocks`, `notifications` (minimal); RPCs in §8 (connections group).
- **Security:** canonical pair uniqueness; block checks in both directions; no enumeration beyond allowed fields; cooldown after decline.
- **Tests:** two active users connect; pending/rejected/suspended cannot; duplicate and reverse-direction simultaneous requests resolve to one row; forged requester rejected; block removes ability to request; directory never returns email/ids beyond allowed fields.
- **Acceptance:** FR-CON-01…07, FR-SAFE-03 (search/request limits).
- **Risks:** race conditions on mutual requests.

## 9. Phase 4 — Private messaging

- **Objective:** reliable one-to-one and group text chat with deterministic ordering.
- **Features:** `get_or_create_direct`; group create/add/remove/leave/group-admin; `send_message` (idempotent, `seq`, rate limit); history pagination; Realtime Broadcast signals (ids only) on private topics; reconnect catch-up; unread counts; `mark_read`; in-app notifications; optimistic UI with retry; safe text rendering; revoked-access handling.
- **Dependencies:** Phase 3.
- **Files:** `features/chats/*`, `lib/realtime/*`; migrations `*_conversations.sql`, `*_messages.sql`, `*_realtime_policies.sql`; tests `conversations.test.sql`, `messages.test.sql`, `realtime.test.sql`; `e2e/chat.spec.ts`.
- **DB changes:** `conversations`, `conversation_members`, `messages`; trigger → `realtime.send`; `realtime.messages` policies; message `SELECT` RLS using `joined_seq`.
- **Security:** membership checks in RLS, RPCs and Realtime; read-only after block; ids-only payloads; per-user rate limits.
- **Tests:** DM requires connection; one DM per pair under concurrency; non-participant cannot select/insert/subscribe; forged `sender_id`/`seq` rejected; duplicate send idempotent; concurrent sends yield gap-free `seq`; member removed mid-session stops receiving and cannot fetch; two-browser E2E including offline→reconnect.
- **Acceptance:** FR-MSG-01…08, FR-NOT-01.
- **Risks:** Realtime authorization caching; `realtime.send` API details; conversation row lock contention (negligible at this scale).

## 10. Phase 5 — Media, safety, privacy and MVP hardening (R2 gate)

- **Objective:** make the messenger safe and legal-ready enough for a trusted group.
- **Features:** client image pipeline (resize, re-encode, EXIF removal); private buckets and Storage policies; `register_attachment`; signed-URL viewer; reports with evidence snapshots and moderation queue; admin overview and quota panel; per-user upload caps; **data export; account deletion with grace; retention/cleanup jobs; privacy notice, terms and community rules (versioned, accepted at onboarding)**; encrypted backup procedure and **restore drill**; monthly operations checklist; accessibility and cross-browser pass; second admin appointed.
- **Dependencies:** Phase 4.
- **Files:** `features/{media,reports,admin}`, `lib/media/*`; migrations `*_attachments.sql`, `*_reports.sql`, `*_deletion.sql`, storage policies; Edge Functions `delete-account`, `export-my-data`, `cleanup`; `docs/runbooks/{backup-restore,incident,breach,secret-rotation,owner-recovery}.md`.
- **DB changes:** `message_attachments`, `reports`, `account_deletion_requests`; storage policies; cron jobs.
- **Security:** MIME allow-list (no SVG); size caps; path-based policy; short-lived URLs; evidence-only moderation; deletion completeness; secret scan clean.
- **Tests:** authorized vs unauthorized download (pending, unrelated member, former member, signed out, guessed path); wrong type/oversize/interrupted upload; EXIF gone from stored file; expired URL; report snapshot contents and purge; export contains only the requester's data; deletion tombstones and removes objects; restore drill into a scratch project succeeds.
- **Acceptance:** FR-MEDIA-01…03, FR-SAFE-01/02, FR-PRIV-01…04, FR-ADM-01; every item of `PRD.md` §17; **Gate B**.
- **Risks:** storage quota; deletion edge cases; owner time for the restore drill.

## 11. Phase 6 — Community essentials and messenger polish (R3)

- **Objective:** make daily use pleasant and the community inclusive.
- **Features:** announcements; edit (15 min) and delete-for-everyone; reactions and replies; typing indicator; mute and notification preferences; "Seen" with opt-out; username change; discoverability setting; admin audit viewer; **email OTP sign-in** (domain + custom SMTP + rate limits + identity-linking tests) — pulled into Phase 2 if OD-03 shows members lack Google accounts.
- **Dependencies:** Phase 5 (Gate B); owner approval for any domain purchase.
- **Files:** `features/{community,chats,settings}`; migrations `*_announcements.sql`, `*_reactions.sql`; email templates.
- **DB changes:** `announcements`, `message_reactions`; columns for edit/delete behavior and preferences.
- **Security:** edit window enforced in RPC; tombstones; account-linking review; SMTP credentials only in Supabase settings; OTP throttling.
- **Tests:** edit/delete permissions and window; tombstone visible to others; reaction allow-list; OTP flow, wrong/expired code, throttling, same-email linking behavior; typing signals private to participants.
- **Acceptance:** FR-AUTH-06/07, FR-CON-08, FR-MSG-09…13, FR-NOT-02, FR-MEM-10, FR-COM-01.
- **Risks:** email deliverability; domain cost.

## 12. Phase 7 — Voice and video (R4)

- **Objective:** authorized one-to-one calls within free quotas.
- **Features:** LiveKit project; `call_sessions`; RPCs for invite/accept/decline/cancel/timeout/end; `create_call_token` Edge Function; voice first, then video; device and permission handling; reconnect; busy state; call history; quota guard and "calling unavailable" state.
- **Dependencies:** Gate D; Phase 6.
- **Files:** `features/calls`, `lib/calls/*`; migration `*_calls.sql`; Edge Function `create-call-token`; Permissions-Policy update.
- **DB changes:** `call_sessions`, `call_participants`.
- **Security:** secrets only in Edge Function secrets; token ≤ 10 min, room-scoped, least privilege; server-side state machine; block and connection checks; no recording; no E2EE claims.
- **Tests:** only the intended callee can obtain a token; token for another session rejected; timeouts; decline/cancel/missed transitions; cross-browser, Wi-Fi vs mobile network, permission denied, tab close; quota-exhausted behavior.
- **Acceptance:** FR-CALL-01…05.
- **Risks:** NAT/firewall variability (LiveKit provides TURN but no universal guarantee); 5,000-minute cap (≈ 2,500 one-to-one call minutes).

## 13. Phase 8 — Games (R5)

- **Objective:** server-authoritative turn-based games.
- **Features:** generic session model; invitations; tic-tac-toe, then Connect Four; resume; forfeit/timeouts; results history.
- **Dependencies:** Phase 6.
- **Files:** `features/games`; migration `*_games.sql`; tests `games.test.sql`.
- **DB changes:** `game_sessions`, `game_players`, `game_moves`; `submit_game_move` RPC; scheduled forfeit job.
- **Security:** only invited players; turn/legality/idempotency checks under row lock; no client-set winner or score.
- **Tests:** out-of-turn, duplicate, replayed and illegal moves rejected; concurrent moves deterministic; non-player cannot read or move; browser state edits have no effect.
- **Acceptance:** FR-GAME-01…05.
- **Risks:** over-building; moves being counted against Realtime quota.

## 14. Phase 9 — Social feed and stories (R6)

- **Objective:** audience-controlled posts, comments, reactions and expiring stories.
- **Features:** audience selector (`connections` or `community`); posts with compressed images; comments; reactions; stories with server expiry; reporting/blocking integration; rate limits; storage monitoring.
- **Dependencies:** Phases 7–8 optional; Phase 5 quota tooling; owner decision on Supabase Pro/R2 (OD-09).
- **Files:** `features/{community,stories}`; migration `*_social.sql`.
- **DB changes:** `posts`, `post_attachments`, `comments`, `reactions`, `stories`, `story_views`.
- **Security:** audience enforced in RLS and Storage; expired stories unreachable by API and path; moderation evidence for posts.
- **Tests:** visibility per audience; blocked users; expiry; reports; storage and egress measured.
- **Acceptance:** FR-SOC-01…03.
- **Risks:** storage and egress consumption; moderation workload.

## 15. Phase 10 — Production hardening and expansion (R7)

- **Objective:** sustainable operation and informed decisions about the P3 list.
- **Work:** provider and legal re-check; Pro/backup decision implemented; stronger monitoring and rate limiting; dependency and security review; load tests; accessibility audit fixes; incident exercise; DPDP readiness confirmed by counsel; evaluate passkeys, web push/PWA, group calls and E2EE **as separate scoped proposals** with architecture updates (no custom cryptography).
- **Dependencies:** Gate C.
- **Acceptance:** no open critical/high security findings; recovery exercised; documented, tested retention/deletion; limitations communicated.
- **Risks:** E2EE and push each carry major engineering and UX cost.

## 16. Definition of Done (every feature)

A feature is done only when all are true:
1. Requirements and acceptance criteria met.
2. Loading, empty, error, offline and access-revoked states handled.
3. Authorization enforced in the database; no security depends on hidden controls.
4. Unit, component, pgTAP and E2E tests pass, **including negative tests**.
5. Mobile and desktop behavior checked; accessibility basics met.
6. Logs contain no private content or credentials.
7. Migrations, `.env.example`, and documentation (including traceability) updated.
8. No real secrets or user data committed; secret scan clean.
9. Security impact reviewed and written in the completion report.
10. The owner has been told what was tested and what remains unverified.

## 17. Release milestones

| Milestone | Contents | Gate |
|---|---|---|
| M0 | Phases 0–1: shell deployed | — |
| M1 (R1) | Phase 2: membership live for owner + test accounts | A |
| M2 | Phases 3–4: connections and chat | — |
| **M3 (R2)** | Phase 5: Private Messenger MVP to the trusted group | **B** |
| M4 (R3) | Phase 6 | C before widening |
| M5 (R4) | Phase 7 | D |
| M6 (R5) | Phase 8 | — |
| M7 (R6) | Phase 9 | — |
| M8 (R7) | Phase 10 | — |

## 18. Main risks

| Risk | Mitigation |
|---|---|
| Free storage/egress exhausted | Client compression, caps, monitoring; Pro or R2 decision |
| Free project pauses / no backups | Encrypted backups, restore drills; Pro decision before wider rollout |
| RLS/RPC/Realtime/Storage mistakes | Negative-test matrix every phase; advisor checks; two-user E2E |
| Invitation abuse | Hash, atomic redemption, throttling, revocation |
| OAuth redirect errors | Exact allow-list; separate environments |
| Members without Google | Email OTP gate (OD-03) |
| Scope creep | Gates; no later-phase work before the gate passes |
| Legal uncertainty | 18+ default; counsel before Gate C |
| Single-owner dependency | Second admin; recovery runbook |
| Secret leak | Secret scanning; rotation runbook |

## 19. Prioritized next steps (first work session)

1. Owner reads `DECISIONS.md` §3 and confirms or changes OD-01…OD-12 (especially OD-03 Google accounts, OD-07 age, OD-09 backups/Pro).
2. Do Phase 0 only: repo, scaffold, CI, docs, `.env.example`, secret scanning, 2FA on all accounts.
3. Start Phase 1: deploy a blank shell; run the Workers/Pages spike and headers check.
4. Create the Supabase staging project and the Google OAuth client; configure local and preview redirect URLs.
5. **Stop** before messaging. Write and review Phase 2 migrations, RPCs and pgTAP tests first.

## 20. Future enhancements (not committed)

Polls and events; passkeys; web push and PWA install; shared albums; group calls and voice rooms; video messages and voice notes; richer moderation tooling; end-to-end encryption (separate project); native apps; larger-scale infrastructure. Each requires a new scoped proposal, an architecture update and owner approval.
