# Review Report — Documentation Audit, Architecture Optimization and Refinement (Mirach)

> **Date:** 4 November 2026 (Asia/Kolkata). **Scope:** `Memory.md`, `Architecture.md`, `Design.md`, `Phases.md`, `PRD.md`, `Rules.md` (originals preserved in `_originals_2026-11-03/`).
> **Result:** all six documents rewritten as a consistent v2 baseline, plus `DECISIONS.md`, `SOURCE_REGISTER.md` and this report. **No application code was written; nothing is implemented.**

## 1. Method and limitations

- Read all six originals completely; audited them from user, administrator, developer, attacker and operator viewpoints.
- Researched current provider documentation with a web search/fetch tool. Only `supabase.com/pricing` was fetched in full as an official page; other official pages were seen as search excerpts, and several facts come from secondary sources. Every claim is tiered in `SOURCE_REGISTER.md`; unverified items are labelled **UNVERIFIED** and listed there (16 items).
- The DPDP full Rules text was **not** read; only PIB releases and law-firm summaries. Nothing here is legal advice.
- I could not test any provider behavior, so statements such as `realtime.send` semantics, `_headers` on Workers assets, and identity-linking behavior are flagged for verification at implementation.
- The cost scenarios are arithmetic on stated assumptions, not measurements.

## 2. Executive summary

**The previous plan was directionally sound** (private-by-default, backend-enforced permissions, honest security claims, phased delivery). The substantive corrections were:

1. **Realtime design** used Postgres Changes, which Supabase's own docs steer away from; replaced by private Broadcast signals carrying ids only, plus per-conversation `seq` and idempotent `client_msg_id`.
2. **Hosting** reconsidered: GitHub Pages is a poor fit (details in §4.4); Cloudflare now points new projects to Workers Static Assets.
3. **Authentication** was Google-only with no plan for members without Google; email OTP added as a gated second method with its real costs (domain + SMTP) stated.
4. **Missing critical specifications** added: owner bootstrap and recovery, hash-only invitations with atomic redemption and throttling, username policy, account deletion and export, moderation evidence snapshots, rate limiting, EXIF stripping, security headers, backup/restore (Free has none), DPDP timeline, age policy.
5. **Data model** simplified and hardened (merged connection tables, removed per-message receipts, added `seq`, tombstone deletion), with an ER diagram that matches the text.
6. **Roadmap** re-sequenced: privacy/backup/deletion moved into the MVP gate, community essentials inserted, games before social, explicit launch gates.
7. **Rules** expanded into an enforceable AI-agent operating procedure with status vocabulary and completion report.

## 3. Gap analysis

Severity: **C**ritical / **H**igh / **M**edium / **L**ow. "Doc" lists documents changed.

| ID | Gap | Sev | Why it matters | Correction | Doc |
|---|---|:-:|---|---|---|
| G-01 | Realtime used Postgres Changes for durable messages | H | Single-thread processing, RLS evaluated per subscriber, full rows broadcast; poor scale and a revocation leak | Private Broadcast, DB trigger, ids-only payloads, minimal fetch under RLS | Arch §9, ADR-006 |
| G-02 | No message ordering or idempotency (`seq`, `client_msg_id`) | H | Duplicates and reordering on retry/reconnect | Per-conversation `seq` under row lock; unique client id | Arch §6.3, §9 |
| G-03 | `message_receipts` row per message per user | M | Storage and write amplification on a 500 MB DB | `last_read_seq` cursor; unread = `last_seq − last_read_seq` | Arch §6.2 |
| G-04 | Owner/admin bootstrap and recovery unspecified | C | Either no admin or an insecure admin path | One-shot `bootstrap_owner`, hierarchy and last-owner invariants, break-glass runbook | Arch §4.5, Rules §11 |
| G-05 | Invitations: hashing, atomic redemption, attempt throttling not specified | H | Brute force, over-redemption races | ≥ 80-bit codes, sha256 only, locked transaction, 5 failures/hour, generic errors | Arch §4.4, PRD FR-MEM |
| G-06 | Google-only auth excludes members without Google | H | Contradicts the "flexible" and inclusive requirement | Email OTP second method, gated on domain/SMTP and OD-03 | Arch §4.1, ADR-004 |
| G-07 | Email OTP/magic links assumed free; need SMTP and a domain | M | Hidden cost; default Supabase SMTP is team-only and ~2/hour | Cost stated; owner approval gate | Arch §2, §4.1 |
| G-08 | Authorization from JWT claims risk (stale after suspension) | H | Suspended users keep access until token expiry | Per-request DB lookup; Admin-API ban; global sign-out; channel teardown | Arch §4.2, ADR-016 |
| G-09 | Realtime channel authorization may be cached; revocation | M | Removed user could keep receiving | Ids-only payloads; teardown signal; explicit test | Arch §9 |
| G-10 | Client writes with RLS (mass-assignment surface) | H | Complex policies, forged fields | RPC-only writes, default-deny grants | Arch §6, §7, ADR-007 |
| G-11 | Security-definer functions: `search_path`, execute grants not specified | H | Classic privilege-escalation pitfall | `search_path = ''`, revoke from `anon`/`public` | Arch §3.1, §7, Rules §10 |
| G-12 | Friend requests vs connections duplicated; duplicate/reverse races | M | Duplicate pairs, race on mutual requests | Single `connections` table, canonical pair, unique constraint | Arch §6.2, ADR-009 |
| G-13 | Direct conversation uniqueness not enforced | M | Duplicate DMs | `direct_key` unique + transactional get-or-create | Arch §6.2 |
| G-14 | Group history after leaving/removal and for new members undefined | M | Privacy ambiguity | `joined_seq`; new row per stint; owner default OD-05 | Arch §6.3, PRD §5 |
| G-15 | Block semantics undefined | M | Inconsistent behavior, harassment loopholes | Defined effects; documented group limitation | Arch §6.3, PRD §5 |
| G-16 | No moderation path that respects "admins can't read chats" | H | Either blind moderation or an admin backdoor | Evidence snapshots with reporter-visible scope; purge schedule | Arch §6.4, ADR-010 |
| G-17 | Admin audit log not append-only / not specified | M | Untraceable abuse | Append-only table, written in same transaction | Arch §6.2 |
| G-18 | Username policy (normalization, reserved names, change, impersonation) | M | Impersonation, homoglyphs | ASCII `[a-z0-9_]`, reserved list, 30-day change cooldown, name hold | Arch §6.2, PRD FR-AUTH-02/07 |
| G-19 | Rate limiting not defined anywhere concrete | H | Spam, scraping, brute force | Per-action limits in RPCs; table-backed counters | Arch §8, PRD FR-SAFE-03 |
| G-20 | Directory enumeration/scraping | M | Social-graph leakage | Min 3 chars, page ≤ 20, discoverability setting, rate limits | Arch §7, PRD FR-CON |
| G-21 | Media: EXIF/GPS leakage; no image transformations on Free; quota burn | H | Privacy leak and 1 GB exhaustion | Client re-encode, caps, thumbnails, monitoring | Arch §10, ADR-011 |
| G-22 | Upload validation (SVG/HTML), bucket types, path-based authorization | H | Stored XSS, unauthorized access | MIME allow-list, no SVG, path policy, signed URLs ≤ 5 min | Arch §10, Rules §13 |
| G-23 | No frontend security headers/CSP plan | M | XSS impact, clickjacking | `_headers` CSP etc.; GitHub Pages cannot set them | Arch §13.2 |
| G-24 | OAuth: PKCE and exact redirect allow-list not explicit | M | Redirect/token interception | `flowType: 'pkce'`, exact URLs | Arch §4.2 |
| G-25 | Backups: Free plan has none; no concrete procedure | C | Total data loss risk | Encrypted dumps, restore drill, stated RPO, Pro decision gate | Arch §15.6, OD-09 |
| G-26 | Free project pauses after 1 week inactivity | M | Outage | Treated as an incident type; Pro decision; no keep-alive hacks | Arch §15.7 |
| G-27 | Only dev/prod implied; two free projects only | M | Previews hitting production | Local Docker + staging + production mapping | Arch §15.2 |
| G-28 | Account deletion and data export missing | H | Trust and DPDP readiness | Grace + tombstone workflow; export function | Arch §4.6, PRD FR-PRIV |
| G-29 | DPDP timeline and children's-data rule absent | H | Compliance planning | Dates (on or about 13–14 May 2027), 18+ default, counsel gate | Arch §14, OD-07/08 |
| G-30 | IT Rules intermediary duties never considered | M | Possible obligations | Flagged for legal review (not analyzed) | Arch §14, OD-08 |
| G-31 | Notifications undefined; push assumed implicitly | M | Unrealistic expectations (closed browser) | In-app only; push deferred (P3) | PRD FR-NOT, Arch §9 |
| G-32 | Edit/delete semantics, evidence retention interplay | M | Unclear tombstones, destroyed evidence | 15-min edit window, soft delete, snapshots | Arch §6.3 |
| G-33 | Group size and abuse limits undefined | L | Resource abuse | Default cap 50, configurable | Arch §6.2 |
| G-34 | Presence design (global online list) | M | Privacy cost, Realtime load | Rejected; presence only inside open conversations | PRD §14, Arch §9 |
| G-35 | Calls: token authorization, state machine, quota hard cap, ring timeout | M | Unauthorized joins; surprise limit | Edge Function token ≤ 10 min, server states, hard-cap UX | Arch §11 |
| G-36 | Games: server authority not specified in detail | M | Cheating | Row-locked `submit_game_move`, idempotency | Arch §12 |
| G-37 | Sequencing: hardening last; stories before games | M | Real data before safeguards; storage burn | Gates; games before social | Phases §1, §3 |
| G-38 | Free-tier numbers partly stale/unsourced | M | Overstated assumptions | Verified table with tiers and dates | Arch §18, Source Register |
| G-39 | Rules lacked status vocabulary, completion report, dependency/secret rules | M | Agents overclaiming | Rules §3–§4, §22–§23 | Rules |
| G-40 | Accessibility target and states not measurable | M | Exclusion | WCAG 2.2 AA, tests, contrast table | Design §2, §15 |
| G-41 | Supply-chain and secret scanning | M | Compromise | Lockfile, audit, pinned actions, gitleaks | Arch §15.4, Rules §6–7 |
| G-42 | Duplicate-account/ban evasion | L | A suspended member can use another Google account | Documented limitation; admin review of no-code requests | PRD §18 |
| G-43 | Timezone/locale/i18n | L | India-first but English UI | Strings centralized; times in viewer locale | PRD §9 |
| G-44 | No operations/monitoring cadence | M | Silent quota exhaustion | Monthly checklist | Arch §15.7 |
| G-45 | Pending profile squatting and stale records | L | Name squatting, bloat | 30-day purge, hidden from directory | Arch §4.3 |

## 4. Technology comparison and recommendation

### 4.1 Frontend

| Option | Pros | Cons | Verdict |
|---|---|---|---|
| **React + TS + Vite SPA** | Simple, static output, wide ecosystem, easy testing, any static host | Client-side only (fine for a login-gated app) | **Chosen** |
| Next.js | SSR, file routing | Server runtime or adapter needed; second trust boundary; no SEO need | Rejected |
| SvelteKit / others | Lean | Smaller hiring/AI-agent familiarity; no deciding benefit | Not chosen |

### 4.2 Authentication

| Provider | Free tier (checked) | Fit | Verdict |
|---|---|---|---|
| **Supabase Auth** | 50,000 MAU | Same identity as DB/RLS/Storage/Realtime | **Chosen** |
| Firebase Auth | 50,000 MAU (secondary) | Good, but data layer mismatch; Storage needs billing plan | Rejected |
| Appwrite | 75,000 MAU; project pausing | Smaller ecosystem; caps 2 GB / 5 GB | Rejected |
| Clerk | **UNVERIFIED** | Extra vendor; would integrate via third-party JWT | Not needed |

| Method | Verdict |
|---|---|
| Google OAuth | MVP default (no SMTP/domain) |
| Email OTP | Second method, gated (domain + SMTP) |
| Magic link | Rejected (scanner prefetch can consume links) |
| Email + password | Rejected (reset flow; no breached-password check on Free) |
| Passkeys | Later; Supabase beta |
| Username | Identity only, never authentication |

### 4.3 Backend and database

| Provider | Relational integrity / ACL | Realtime | Storage on free | Backups on free | Verdict |
|---|---|---|---|---|---|
| **Supabase** | PostgreSQL, RLS, transactions | Broadcast/Presence | 1 GB | None | **Chosen** |
| Firebase | Document model; rules language | Yes | Needs Blaze since Feb 2026 (secondary) | n/a | Rejected |
| Appwrite | Collection/document permissions (not evaluated in depth) | Yes (disabled when limits hit) | 2 GB | Not on Free (Start/Pro) | Rejected |

Postgres can safely enforce private conversation access and membership: via RLS + constraints + `SECURITY DEFINER` RPCs. The decisive reasons are atomic invitation redemption, unique canonical pairs and policy joins across membership/conversation tables.

### 4.4 Frontend hosting

| Option | Verdict |
|---|---|
| GitHub Pages | Static-only; public site; no custom headers; sensitive-transaction/commercial wording → **poor fit**, not prohibited |
| **Cloudflare Workers Static Assets** | **Chosen**; headers, Git deploy, free static delivery |
| Cloudflare Pages | Fallback (500 builds/month, 1 concurrent) |
| Vercel Hobby / Netlify | Unnecessary; restrictions |

Layers: code (GitHub) · frontend (Cloudflare) · APIs/DB/auth/storage/realtime (Supabase) · calls (LiveKit). A static host does not run a backend.

### 4.5 Voice/video

| Option | Verdict |
|---|---|
| Native WebRTC | Rejected: signaling, STUN/TURN relays for hostile NATs, and meshes do not scale |
| **LiveKit Cloud (Build)** | **Chosen, deferred**: TURN/SFU included; hard-capped free allowance; open-source exit path |
| Daily / 100ms / Agora | Not price-verified (**UNVERIFIED**) |

### 4.6 Media storage

Supabase Storage (private buckets, signed URLs; 1 GB, 50 MB per file) for MVP; Cloudflare R2 as the documented escape hatch (10 GB free and no egress fees per secondary sources; card requirement **UNVERIFIED**); Firebase Storage rejected; never in database rows.

### 4.7 Final stack table

See `Architecture.md` §2 (components, alternatives, recommendation, reason, free-tier limits), §17 (reconsideration triggers) and §2 notes (optional components and lock-in).

## 5. Provider verification summary

| Provider | Verified (tier) | Main limits | Card required | Pause/inactivity | Production suitability |
|---|---|---|---|---|---|
| Supabase Free | A | 500 MB DB, 1 GB storage, 5 GB egress, 200 peak Realtime, 2 M messages, 500K Edge calls, no backups | Not stated on pricing page (**U**) | Pauses after 1 week | Prototype/trusted-group grade; not an uptime or backup guarantee |
| Cloudflare Pages / Workers | B / C | 500 builds/month; static requests free (secondary) | **U** | None | Suitable for static frontend |
| LiveKit Build | B | 5,000 min, 50 GB, 100 participants; hard cap | No (secondary) | n/a | Fine for small calling |
| Firebase Spark | C | Storage needs Blaze | Blaze needs billing | n/a | Not selected |
| Appwrite Free | B | 2 GB, 5 GB, pauses idle | n/a | After 1 week | Not selected |
| Email (Resend/Brevo) | C | 3,000/month; 300/day | Varies | n/a | Needed only for email OTP |

## 6. Usage scenarios and cost

**Assumptions (not measurements):** A1 each member sends 40 text messages/day, 30 days; A2 ≈ 8 counted Realtime messages per sent message (signal fan-out plus typing; deliberately high); A3 ≈ 0.5 KB DB per message incl. indexes; A4 1 image/member/day at ≈ 0.3 MB compressed (≈ 2 MB if not compressed); A5 images viewed by ≈ 2.5 recipients; A6 peak concurrent online ≈ 30% of members; A7 each member joins 4 one-to-one calls/month of 10 minutes; video ≈ 1 Mbps per direction.

| Metric (per month) | 10 members | 50 members | 100 members | Free limit |
|---|---:|---:|---:|---|
| Messages sent | 12,000 | 60,000 | 120,000 | — |
| Realtime counted (×8) | 96,000 | 480,000 | 960,000 | 2,000,000 |
| DB growth (messages) | 6 MB | 30 MB | 60 MB | 500 MB total |
| Months until 500 MB (messages only) | ≈ 83 | ≈ 17 | ≈ 8 | — |
| Images stored (compressed) | 90 MB | 450 MB | 900 MB | 1 GB total |
| Months until 1 GB | ≈ 11 | ≈ 2 | ≈ 1 | — |
| Images stored if uncompressed (2 MB) | 600 MB | 3,000 MB | 6,000 MB | exceeds quickly |
| Cached egress (images × 2.5) | ≈ 0.23 GB | ≈ 1.1 GB | ≈ 2.3 GB | 5 GB cached |
| Peak connections (30%) | 3 | 15 | 30 | 200 |
| Auth MAU | 10 | 50 | 100 | 50,000 |
| Call participant-minutes (A7) | 400 | 2,000 | 4,000 | 5,000 |
| Video downstream if all calls were video | ≈ 3 GB | ≈ 15 GB | ≈ 30 GB | 50 GB |

Sensitivity: 20-minute calls double call minutes (100 members → 8,000, above the cap); 100 messages/day per member at 100 members gives ≈ 2.4 M counted Realtime messages (above the cap).

**Conclusions.** 10 members fit the Free plans for a long time. 50 members can run the messenger but storage (and any call growth) needs action within months. 100 members need Supabase Pro (or R2) for media and backups; calls fit only at modest use.

| Cost layer | Amount |
|---|---|
| Development | $0 cash (owner/AI time) |
| Initial launch | $0 required; a domain only if email OTP or a custom domain is approved (price **UNVERIFIED**) |
| Ongoing (within Free quotas) | $0, with no backups and a pause risk |
| Future | Supabase Pro from $25/month; LiveKit Ship from $50/month (secondary); email provider free tiers likely sufficient |

## 7. Security and privacy review summary

- **Auth:** PKCE, exact redirects, verified-email claim, global sign-out, linking tests, rate limits.
- **Database:** default-deny grants, RLS plus RPCs, `search_path` pinned, constraints, append-only audit, hash-only codes.
- **Messaging/Realtime/Storage:** membership checks in all three policy planes; ids-only signals; private buckets; signed URLs; EXIF stripped; SVG rejected.
- **Secrets/deployment:** no secrets in `VITE_*`/repo; server-side secrets; scanning; pinned actions; env separation.
- **User safety:** block, report with evidence, suspension, audit, rate limits.
- **Encryption:** TLS yes; at-rest is provider-managed and not verified; **no E2EE**; E2EE deferred as a separate audited project, stated as a limitation everywhere users read.
- **Legal (India):** DPDP Act and Rules notified; substantive obligations on or about 13–14 May 2027 (sources differ by one day); verifiable parental consent for under-18 → default 18+; notice/consent, security safeguards, breach reporting, rights handling and retention duties need counsel; IT Rules intermediary duties and any personal/domestic-use exemption unresolved. **No legal conclusion is offered.**
- **Open security checks for implementation:** `realtime.send` behavior and Realtime authorization caching; identity linking; `_headers` on Workers; Storage policy edge cases; Admin-API ban semantics.

## 8. Traceability matrix

Status for every row is **Planned** (no implementation exists).

| Requirement | PRD | Architecture | Design | Phase | Status |
|---|---|---|---|---|---|
| Google sign-in, no phone | §6.1 FR-AUTH-01 | §4.1–4.2 | S1 (§5) | 2 | Planned |
| Unique username policy | FR-AUTH-02 | §6.2 `profiles`, §8 | S2 | 2 | Planned |
| Sign out / all devices | FR-AUTH-04/05 | §4.2 | S16 (§8) | 2 | Planned |
| Email OTP second method | FR-AUTH-06 | §4.1 | S1 | 6 | Planned |
| Invitation join (atomic, hashed) | §6.2 FR-MEM-01/04 | §4.4, §6.2 | S2, S17 | 2 | Planned |
| No-code request + approval | FR-MEM-02/03/06 | §4.3 | S2, S3, S17 | 2 | Planned |
| Owner bootstrap, roles | FR-MEM-07/08 | §4.5 | S17 | 2 | Planned |
| Suspension immediate | FR-MEM-05, FR-SAFE-04 | §4.2, §8 | S3, S17 | 2 | Planned |
| Audit log | FR-MEM-09/10 | §6.2 | S17 | 2 (write), 6 (viewer) | Planned |
| Directory search | §6.3 FR-CON-01 | §7, §8 | S5 | 3 | Planned |
| Connections lifecycle | FR-CON-02…05 | §6.2–6.3 | S6 | 3 | Planned |
| Block / unblock | FR-CON-06 | §6.3 | Profile (§6) | 3 | Planned |
| Direct + group chat | §6.4 FR-MSG-01/02/05/06 | §6.2, §8 | S7, S8 | 4 | Planned |
| Realtime delivery, ordering, retry | FR-MSG-03/04/07/08 | §9 | S4, S7 | 4 | Planned |
| In-app notifications | §6.6 FR-NOT-01 | §9 | S15 | 4 | Planned |
| Image sharing, authorization | §6.5 FR-MEDIA-01…03 | §10 | S9, S7 | 5 | Planned |
| Report + moderation evidence | §6.7 FR-SAFE-01/02 | §6.4 | S18 | 5 | Planned |
| Rate limiting | FR-SAFE-03 | §8 | (error states §16) | 3–5 | Planned |
| Notice/terms, export, deletion, retention, age | §6.8 FR-PRIV-01…05 | §4.6, §14 | S2, S16 | 2 (age), 5 | Planned |
| Backup and restore | §17 #18 | §15.6 | — | 5 | Planned |
| Announcements | §6.9 FR-COM-01 | §6.2 (R3), §8 | S4, S11 | 6 | Planned |
| Edit/delete, reactions, typing, mute, seen | FR-MSG-09…13, FR-NOT-02 | §6.3, §9 | S7, S8, S16 | 6 | Planned |
| Calls | §6.10 FR-CALL-01…05 | §11 | S13 | 7 | Planned |
| Games | §6.11 FR-GAME-01…05 | §12 | S14 | 8 | Planned |
| Social feed/stories | §6.12 FR-SOC-01…03 | §12 | S11, S12 | 9 | Planned |
| Accessibility WCAG 2.2 AA | §9 | — | §15 | all | Planned |
| Cost / quota monitoring | §11 | §15.7, §16 | S17 | 5 | Planned |
| No E2EE claim | §5 rule 11, §18 | §13.3 | S1, S16 | all | Planned |

## 9. Cross-document consistency report

**Checks performed:** authentication method; registration/invitation rules; roles and permissions; membership statuses; table and RPC names; rate-limit and retention numbers; release/phase numbering; section cross-references; calling provider; hosting; free-tier numbers; MVP boundary; deferred-feature wording; status claims.

**Inconsistencies found and fixed during the audit**
1. Architecture §9 pointed to §17 for the quota budget (should be §16) — fixed.
2. Architecture §16 pointed to §19 for verified limits (should be §18) — fixed.
3. PRD NFR linked accessibility to `Design.md` §9 (calls); corrected to §15 — fixed.
4. PRD gave moderators suspend power while Architecture/Design restricted suspension to admins — aligned: moderators dismiss/warn/escalate; admins/owners suspend (PRD §4, Architecture §8, Design S18).
5. Design listed an audit-log screen at R2 while PRD scheduled the viewer for R3 — aligned (writes in R1, viewer R3).
6. Design contained a stray routing sentence — reworded.
7. Architecture §8 listed Phase 6–8 operations without a phase marker — noted.

**Verified consistent:** Google OAuth first + email OTP second everywhere; invitation defaults (1 use, 7 days, ≥ 80 bits, hash-only, 5 failed/hour); role hierarchy and "no role reads chats"; membership statuses (`pending|active|rejected|suspended|left`); connection and block semantics; group cap 50; edit window 15 min; message limit 30/minute and 4,000 chars; signed URL ≤ 5 min; call token ≤ 10 min, ring 45 s; retention (evidence 90 days, audit 1 year, notifications 30 days, pending 30 days); LiveKit is the only calling provider referenced; Workers Static Assets (Pages fallback) in all hosting statements; MVP = R1 + R2 identical in PRD, Phases and Memory; deferred features marked Planned/P2/P3 and never as implemented.

**Residual items (not contradictions):** the OD register carries defaults that need owner confirmation; the Phase 1 spike may change ADR-002; unverified provider facts are listed in `SOURCE_REGISTER.md`.

## 10. Unresolved decisions

OD-01 … OD-12 in `DECISIONS.md` §3. Highest priority: **OD-03** (members without Google), **OD-07** (age), **OD-08** (legal review), **OD-09** (backups/Pro).

## 11. Risks and limitations

Free-tier pausing and no backups; storage exhaustion; RLS/Realtime/Storage policy mistakes; calls quota and network variability; Google dependency until email OTP; legal obligations from May 2027; single-owner dependency; unverified provider details; absence of E2EE; plan not yet reviewed by anyone but the author.

## 12. Prioritized next steps

1. Owner reviews all documents and answers OD-03, OD-07, OD-09 first.
2. Phase 0: repo, scaffold, CI, secret scanning, 2FA everywhere.
3. Phase 1: deploy blank shell; run the Workers/Pages and headers spike; create staging Supabase project and Google OAuth client.
4. Write Phase 2 migrations, RPCs and pgTAP tests before any UI.
5. Do not start messaging until Gate A conditions and Phase 2 tests pass.

## 13. Diagrams and roadmap locations

Architecture diagram: `Architecture.md` §3. ER diagram: §6.1. Message sequence: §9. Onboarding flow: `Design.md` §13. Dependency roadmap: `Phases.md` §2.
