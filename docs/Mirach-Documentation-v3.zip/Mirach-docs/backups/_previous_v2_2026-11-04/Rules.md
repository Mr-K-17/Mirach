# Rules — Development, Security and AI-Agent Operating Rules for Mirach

> **Purpose:** Binding engineering guardrails for the owner, developers and AI coding agents.
> **Last reviewed:** 4 November 2026 (Asia/Kolkata).
> **Applies to:** every contributor, human or AI. "Must" and "never" are literal.

## 1. Read order and document precedence

Before planning or changing anything, read in this order:

1. `Rules.md` (this file)
2. `Memory.md` — decisions, current status, known limitations
3. `PRD.md` — what to build and what is out of scope
4. `Architecture.md` — stack, data model, trust boundaries, security design
5. `Design.md` — screens, flows, accessibility
6. `Phases.md` — order, gates, acceptance criteria
7. `DECISIONS.md` — ADRs and open decisions (read OD list before touching anything undecided)

**Precedence:** security and privacy rules in this file cannot be weakened without an explicit owner decision recorded in `DECISIONS.md` plus a security review. `PRD.md` controls scope; `Architecture.md` controls technical boundaries and security design; `Design.md` controls interaction; `Phases.md` controls sequence and gates; `Memory.md` records current status and must be updated when it changes.

If documents conflict: **stop**, state the conflict, propose the smallest fix, update the affected documents, then proceed. Never silently pick one.

## 2. Established decisions — do not change silently

Browser web app · free-first budget (no paid service, domain, overage or billing change without written owner approval) · invitation-code **and** admin-approved registration · no phone numbers anywhere · small private community · Supabase (Auth, Postgres, Realtime, Storage, Edge Functions) · React + TypeScript (strict) + Vite · Tailwind · Cloudflare static hosting · GitHub · LiveKit for calls (later) · Google OAuth first, email OTP second (gated) · database-enforced authorization · **no end-to-end encryption claim** · releases in the order of `Phases.md`.

To change any of these: write an ADR in `DECISIONS.md`, update every dependent document, then ask the owner to approve **before** implementing.

## 3. Task procedure (mandatory for every task)

1. **Inspect existing state** — read the relevant docs and the actual repository (`git status`, branch, existing files, migrations, tests). Never assume paths, versions or what is built.
2. **Plan** — list files, migrations, functions, policies and tests you will touch; confirm the task is in the current phase.
3. **Implement** — small, reviewable change; one feature or migration set per task.
4. **Test** — add and run the tests the change requires (§18), including negative tests for anything private. Report exact commands and results.
5. **Security impact review** — RLS/grants, RPC `search_path` and execute grants, Realtime and Storage policies, secrets, logging, rate limits, data collected.
6. **Update documentation** — migrations, `.env.example`, `Memory.md` status, traceability, any contradicted statement.
7. **Completion report** — format in §22.

If a step cannot be done (no repo access, no database, tests not runnable), say so and stop claiming progress; ask for the files or command output.

## 4. Status vocabulary (use exactly these words)

- **Planned** — described in documents only.
- **Partially implemented** — some code exists; list what is missing.
- **Implemented** — code exists and runs; not yet verified by tests.
- **Tested** — automated or recorded manual tests pass; name them.
- **Verified in production** — observed working in the production environment.

Never write "done", "complete", "working" or "secure" without the evidence and the scope. Documents describing plans must say "planned".

## 5. Scope control

- Work only on the current phase of `Phases.md`. Do not implement unrequested features, "nice-to-haves" or later-phase items.
- Do not add native apps, PWA behavior, push notifications, payments, advertising, public registration, a custom server, video upload, global presence, or any item in `PRD.md` §13 without an approved scope change.
- Do not introduce another cloud provider, SaaS, plugin or paid service for convenience. Before proposing one: state the capability, data shared, free limits, lock-in, fallback; add an ADR; get approval.
- Provider facts in documents are dated snapshots. Re-verify limits and prices at the moment of implementation and record the date.

## 6. Dependencies

- Do not add a package silently. For each new dependency record in the PR/report: purpose, maintenance status, licence, size impact, known vulnerabilities, and why existing tools do not suffice.
- Commit the lockfile; use reproducible installs (`npm ci`); pin GitHub Actions to commit hashes.
- Prefer a version at least two weeks old; never use floating `latest`.
- Run `npm audit` and address high/critical issues or record why not.

## 7. Secrets and configuration

- Never commit, print, log or paste: `.env*` (except `.env.example`), service-role/secret keys, database passwords, Google OAuth client secret, LiveKit API secret, SMTP credentials, backup encryption keys, raw invitation codes, tokens, signed URLs, real user data.
- `VITE_*` variables are public and may hold only the Supabase URL, publishable key and non-secret flags.
- Backend secrets live in Supabase secrets or the CI secret store. Development and production use different keys and projects.
- Document every variable (name, purpose, public/secret, where set) in `.env.example` and `Architecture.md` §15.5.
- Suspected exposure: stop using the secret, rotate/revoke it, check logs, tell the owner. Removing it from the latest commit is not remediation.
- Never place secrets in prompts, chats, issues or screenshots.

## 8. Environments and data

- Local (Docker Supabase) → staging → production, as in `Architecture.md` §15.2. Previews never touch production data.
- **Synthetic data only** in local/staging/tests. Never copy real user data to a lower environment. Never present synthetic data as real in demos or reports.
- Do not bypass authentication or authorization "just for the demo": no disabled RLS, no service key in the browser, no hard-coded admin, no `if (dev)` shortcuts that reach production code.

## 9. Authentication and identity

- No phone number is requested, stored or required.
- Browser OAuth uses PKCE; redirect URLs are exact. Never ask for a Google password.
- Identity comes only from the verified session (`auth.uid()` / validated JWT). Never trust a client-supplied `user_id`, `sender_id`, `role`, `status`, `seq`, or provider subject.
- **Authorization looks up membership and role in the database on every request.** Do not use JWT custom claims for status/role decisions (suspension must be immediate).
- Email and provider identifiers never appear in any member-readable table, view, RPC result, log or URL.
- Email OTP is enabled only after custom SMTP and a verified sending domain exist, rate limits are set, and identity-linking tests pass. Magic links are not used. Email/password is not implemented.
- Suspension must: update membership, ban the auth user via the Admin API, end sessions, and signal open channels.

## 10. Authorization and database

- RLS enabled on every table in an exposed schema; default-deny. **Review grants and policies together**; revoke default grants from `anon` and `authenticated` and grant narrowly.
- Clients do **not** write tables directly. All state changes go through RPCs (`SECURITY DEFINER`, `set search_path = ''`, `revoke … from public, anon`, `grant execute … to authenticated`) that re-check caller identity, membership, role, relationship and input. RPCs never accept an identity parameter.
- Use `(select auth.uid())` in policies; index every policy and FK column; inspect query plans before declaring performance fine.
- Enforce rules with constraints (FK, unique, check), transactions and locking in PostgreSQL, not in the frontend.
- Messages: sender is the caller; `seq` assigned in `send_message` under row lock; unique `(conversation_id, sender_id, client_msg_id)`.
- Group history follows the confirmed rule (`DECISIONS.md` OD-05). Block semantics follow `Architecture.md` §6.3.
- Do not mutate Supabase-managed schemas (`auth`, `storage`, `realtime`, …) except through documented APIs and policies.
- Ordinary users can never change membership status, role, invitation counters, audit data, report status, sequence numbers.
- Run `supabase db lint` and the dashboard Security Advisor before each gate.

## 11. Invitations, administration and recovery

- Invitation codes: random ≥ 80 bits, shown once, stored only as `sha256`, never logged. Default 1 use / 7 days. Only grant `member`.
- Redemption is a single atomic transaction with row lock; failures are generic; ≤ 5 failed attempts per user per hour.
- Roles: owner > admin > moderator > member. Enforce in the database: no self-role-change; admins cannot act on owners; only owners create admins; **the last owner cannot be removed or demoted**.
- Owner bootstrap runs once via `app.bootstrap_owner(user_id)` using a user ID supplied at run time (never committed). It refuses to run if an owner exists.
- **Break-glass owner recovery:** only the Supabase organization owner may use the SQL editor to restore ownership, following `docs/runbooks/owner-recovery.md`; the action must write an audit row and be reported to all admins.
- Every privileged action writes an append-only `admin_audit_log` row in the same transaction. No secrets, no message text.
- **No admin or moderator may read conversations.** Moderation uses report evidence snapshots only. Never add an admin message browser, impersonation, or hidden backdoor.

## 12. Messaging and Realtime

- PostgreSQL is the source of truth. Realtime Broadcast carries **signals with ids only**, never message bodies.
- All topics are private with policies on `realtime.messages`; public channels are disabled.
- Presence/typing are best-effort UI hints, not facts, and are scoped to an open conversation.
- Use `seq` cursors; never load an unbounded history. Enforce body length (4,000), page size (≤ 50), rate limits.
- Retries must be idempotent via `client_msg_id`.
- Render user text as text; never inject HTML; never log bodies.
- After removal, block or suspension: test that open channels stop receiving and that fetches fail.

## 13. Storage and media

- Private buckets only for member content. Never use a public bucket as a shortcut.
- Allowed types: JPEG, PNG, WebP. **Reject SVG, HTML, executables.** Client must resize and re-encode (removing EXIF) before upload; the server still enforces type/size at bucket and RPC level.
- Paths are server-controlled (`{conversation_id}/{uuid}.{ext}`); a client path or filename is never authorization.
- Store paths and metadata, never URLs. Signed URLs ≤ 5 minutes, created only after an authorization check.
- Use the Storage API for deletion; never edit `storage` tables with SQL. Implement orphan cleanup.
- Video and large files stay disabled until quota, egress and owner approval are documented.

## 14. Calls (LiveKit, R4 only)

- Not before Gate D. Secrets only in Edge Function secrets.
- The server decides who may join: validate session, participants, status, block and connection rules, then mint a token ≤ 10 minutes, room-scoped, least-privilege. Clients never choose rooms or mint tokens.
- State machine transitions happen server-side. No recording. No E2EE claims. Handle permission/device/network errors honestly.
- Stay within the free allowance (hard cap); show "calling unavailable" rather than enabling paid plans.

## 15. Games (R5 only)

- Turn-based only. The database is authoritative for state, turn, legality, results. Lock the session row; validate player, turn, legality, idempotency. Browsers never submit winners or scores. No gambling, stakes or paid randomness.

## 16. Frontend and code standards

- TypeScript `strict`; no `any` without a local justification comment; no `@ts-ignore`/ESLint disables without a reason.
- Feature-based modules (`src/features/<feature>`); small components; separate UI, data access (`src/lib/api`), validation (Zod), and trusted logic (database/Edge).
- Components never call the Supabase client directly outside `src/lib/api`.
- Route guards are UX only. Every data screen implements loading, empty, error, offline and access-revoked states (`Design.md` §16).
- Accessibility is a requirement, not polish (`Design.md` §15). Do not use `dangerouslySetInnerHTML`.
- Do not store tokens or personal data in `localStorage` beyond what Supabase's documented session storage does.
- Centralize UI strings; do not hard-code copy that reveals security-sensitive reasons.
- Reuse existing components/utilities before writing new ones; no duplicate implementations.

## 17. Migrations

- Every schema change is a version-controlled SQL migration; dashboard edits are never the only record.
- Review each migration for grants, RLS, constraints, indexes, `search_path`, locks and recovery. Prefer additive changes; no destructive change without a verified backup.
- Apply locally → staging → production. Never edit an applied migration; add a new one.
- Test from-scratch reset (`supabase db reset`) in CI.
- Before risky production migrations: encrypted dump and recorded restore path.

## 18. Testing standards

- Every feature has tests proportional to risk: unit, component, pgTAP (constraints, RPCs, RLS, Realtime, Storage), and Playwright with **two or more users**.
- **Privacy features require negative tests** against the direct API for each actor in the `Phases.md` §4 matrix.
- Required regressions: invitation concurrency, idempotent send, `seq` ordering, block effects, suspended access, removed group member, signed-URL expiry.
- Do not skip, delete or weaken a failing test to pass CI; fix the cause or document an owner-approved exception.
- Report exactly what ran and its result. Say "not run" when not run.

## 19. Logging, monitoring and privacy

- Log request IDs, action category, error class, timing. Never log message bodies, attachment content, tokens, invitation codes, emails, signed URLs or secrets.
- Return safe user-facing errors; keep details in protected logs.
- Follow the retention schedule in `Architecture.md` §6.2; do not keep data longer without a documented reason.
- Collect the minimum: no phone, contacts, birth date, location. Strip EXIF.
- Check quotas monthly (`Architecture.md` §15.7); stop or limit optional features before exhausting free limits; never auto-enable billing.
- Do not invite minors or claim legal compliance (DPDP or otherwise); legal conclusions require professional advice.

## 20. Git, CI and deployment

- Check `git status`, branch, remotes before large operations. Work on feature branches; PRs to `main`; CI must pass (type-check, lint, tests, build, db reset + pgTAP, secret scan, audit).
- Never force-push, rewrite history, `git clean -fdx`, mass-delete or hard-reset without explicit owner permission and a verified recovery path.
- Do not overwrite a user-authored file without reading it first. Do not commit build output, dumps, uploads, `.env*`.
- Production deploys come from `main` only, after staging verification. Record deploy notes.

## 21. Documentation maintenance

- Any change that alters behavior, data, security, scope, environments or costs updates the affected documents **in the same change**.
- Architectural changes need an ADR (`DECISIONS.md`). New open questions go to the OD register.
- Keep the six filenames; do not create `-final`, `-new` or duplicate copies. Supporting files: `REVIEW_REPORT.md`, `DECISIONS.md`, `SOURCE_REGISTER.md`, runbooks.
- Update `Memory.md` current-status section at the end of every working session, truthfully.
- When provider facts are re-verified, update `SOURCE_REGISTER.md` with URL, access date and result.
- Keep the traceability matrix (`REVIEW_REPORT.md` §8) current when requirements or phases change.

## 22. Completion report (required at the end of every task)

1. **Changed** — files, migrations, functions, policies, behavior.
2. **Why** — requirement ID and phase satisfied.
3. **Tests run** — exact commands, pass/fail, and what was **not** run.
4. **Security impact** — RLS/grants, RPCs, Realtime, Storage, secrets, roles, logging.
5. **Status** — each item labeled Planned / Partially implemented / Implemented / Tested (§4).
6. **Not done / risks / unverified** — blockers, quota or cost effects.
7. **Documentation updated** — list.
8. **Next approved step** — one logical action from `Phases.md`.

## 23. Prohibited claims

Never state, in code, UI, documents or reports, without evidence and a defined scope: "secure", "production-ready", "fully encrypted", "end-to-end encrypted", "unlimited free", "compliant with DPDP/GDPR", "no data is ever lost", "calls work on every network", "completed". Do not create placeholder security policies (for example `using (true)`) and describe the application as secure. Say what was verified and how.
