# Source Register — Mirach

> **Access date for every entry:** 4 November 2026 unless stated.
> **Method and limits:** research used a web search tool and page fetch. Tiers:
> **A** = official page fetched in full this session; **B** = official page content seen only as search-result excerpts (not fetched in full); **C** = secondary source (blog, aggregator, comparison site); **U** = **UNVERIFIED** (not checked, or only inferred).
> Never describe a free plan as unlimited or production-grade. Re-verify at implementation time and update this file (`Rules.md` §21).

## 1. Verified or partly verified provider facts

| # | Claim | Source URL | Tier | Notes |
|---|---|---|---|---|
| S1 | Supabase Free: 50,000 MAU; 500 MB database (shared CPU, 500 MB RAM); 5 GB egress + 5 GB cached egress; 1 GB storage; 50 MB max upload; 200 peak Realtime connections; 2 M Realtime messages; 256 KB max Realtime message; 500,000 Edge Function invocations; 2 active projects; custom SMTP allowed; no automatic backups; pauses after 1 week inactivity; Pro from $25/month (8 GB disk, 100 GB storage, 250 GB egress, daily backups) | https://supabase.com/pricing | **A** | Primary source for all quota numbers used in `Architecture.md` §2, §16, §18 |
| S2 | Default Supabase SMTP sends only to project-team addresses with a very low rate (about 2/hour); custom SMTP recommended; no SLA | https://supabase.com/docs/guides/auth/auth-smtp | B | Rate numbers also seen in secondary guides (C); confirm in dashboard |
| S3 | Realtime: Broadcast is recommended over Postgres Changes for scalability; Postgres Changes has throughput limits and RLS-per-subscriber cost | https://supabase.com/docs/guides/realtime/subscribing-to-database-changes and https://supabase.com/docs/guides/realtime/benchmarks | B | Exact `realtime.send` signature **U** — confirm in docs at implementation |
| S4 | Supabase passkeys: beta/experimental since 28 May 2026; requires explicit client opt-in; anonymous users cannot register passkeys | https://supabase.com/docs/guides/auth/passkeys and https://supabase.com/changelog/46458-passkeys-for-supabase-auth-beta | B | |
| S5 | Cloudflare Pages Free: 500 builds/month; 1 concurrent build; 20-minute build timeout; 20,000 files; 25 MiB per file | https://developers.cloudflare.com/pages/platform/limits | B | |
| S6 | Cloudflare directs new static/full-stack sites to Workers Static Assets; Pages remains supported, described as maintenance mode by commentators | https://developers.cloudflare.com/workers/configuration/sites/ ; https://flaviocopes.com/cloudflare-pages-vs-workers/ ; https://mecanik.dev/en/posts/cloudflare-pages-vs-workers-which-to-use-in-2026/ | B / C | The primary best-practices page was **not** retrieved; the Workers Builds free quota and `_headers` support on Workers assets are **U** |
| S7 | GitHub Pages: static only; publicly reachable; size/bandwidth soft limits; not intended for sensitive transactions (e.g. passwords) or commercial SaaS | https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits and https://docs.github.com/pages (terms excerpt) | B | Private-repo Pages requiring a paid plan and lack of custom headers are from general knowledge — treat as **U** until confirmed |
| S8 | LiveKit Build: $0; 5,000 WebRTC minutes; 50 GB downstream; 100 concurrent participants; for Build the free allowance is a hard cap (requests fail until reset); allowance is shared across projects | https://docs.livekit.io/home/cloud/quotas-and-limits/ ; https://livekit.com/blog/towards-a-future-aligned-pricing-model ; https://livekit.com/pricing.md | B | No-credit-card requirement and Ship plan price ($50/month) from secondary sources (C) |
| S9 | Firebase: Cloud Storage requires the Blaze (billing) plan since 3 Feb 2026; Spark free quotas (Firestore, Auth 50K MAU); budgets alert but do not cap spend | https://dev.to/androve2k/spark-vs-blaze-the-firebase-pricing-guide-i-wish-id-read-sooner-onb ; https://magora-systems.com/firebase-pricing/ | **C** | Confirm on firebase.google.com/pricing before relying on it |
| S10 | Appwrite Free: 75,000 MAU; 2 GB storage; 5 GB bandwidth; 750K executions; 2 projects; 1 DB/1 bucket/2 functions per project; projects pause after 1 week inactivity (enforced from Feb 2026); Pro $25/month | https://appwrite.io/pricing ; https://appwrite.io/changelog/entry/2026-02-20-1 ; https://appwrite.io/docs/advanced/platform/free | B | |
| S11 | DPDP Rules 2025 notified 13–14 Nov 2025; 18-month phased commencement; verifiable parental consent for under-18 | https://www.pib.gov.in/PressReleasePage.aspx?PRID=2190655&reg=48&lang=2 ; https://www.pib.gov.in/PressReleasePage.aspx?PRID=2190014&reg=3&lang=2 ; Rules PDF linked there: https://www.meity.gov.in/static/uploads/2025/11/53450e6e5dc0bfa85ebd78686cadad39.pdf | B (PIB) | Full Rules text **not read**. Commencement dates (14 Nov 2025 / 13–14 Nov 2026 / 13–14 May 2027) taken from law-firm summaries (C): https://www.amsshardul.com/insight/enforcement-of-the-dpdp-act-and-notification-of-the-dpdp-rules/ — sources differ by one day; confirm in the Gazette |
| S12 | Transactional email free tiers: Resend 3,000/month (100/day); Brevo 300/day; SendGrid no permanent free tier; Postmark 100/month | https://cli.nylas.com/guides/email-api-free-tiers-compared ; https://dreamlit.ai/blog/best-sendgrid-alternatives | **C** | Verify on provider pricing pages before choosing; a sending domain is required for good deliverability (**U**) |
| S13 | Vercel Hobby is for non-commercial use; Netlify free plan is credit-based | https://macmyths.com/best-free-website-hosting-compared-2026/ | **C** | Not used by the design; only informs rejection |

## 2. Items that remain UNVERIFIED

1. Cloudflare Workers Builds free build quota; `_headers` and SPA-fallback support for Workers Static Assets (Phase 1 spike).
2. Whether GitHub Pages for private repositories requires a paid plan, and that it cannot set custom response headers (general knowledge).
3. Supabase region availability (e.g. Mumbai) and data-residency terms.
4. How Supabase counts Realtime "messages" (per send vs per delivery) — the cost model assumes ≈ 8 counted messages per sent chat message; measure.
5. Supabase automatic identity linking across providers with the same verified email.
6. Cloudflare R2 free allowance and whether a payment method is required.
7. Pricing and limits of other managed WebRTC services (Daily, 100ms, Agora).
8. Clerk pricing/limits (not evaluated; not needed).
9. iOS/Safari web-push requirements and behavior.
10. DPDP details not read in primary text: breach-notification timing, log-retention duration, exemptions for small or personal/domestic processing, and who is a "Data Fiduciary" here.
11. IT Act / IT Rules 2021 intermediary obligations (grievance officer, takedown timelines) applicability to a small private community.
12. Provider-side encryption at rest and exact backup behavior on paid tiers.
13. Domain registration price (varies by TLD).
14. GitHub Actions and GitHub free-plan quotas for private repositories at implementation time.
15. Apple sign-in requiring a paid developer membership (general knowledge).
16. Current Supabase API-key naming/verification behavior for Edge Functions (docs change often).

## 3. Verification procedure at implementation time

For each provider before relying on it: open the official pricing/limits page; copy the relevant numbers; record date and URL here; compare with `Architecture.md` §18; if different, update the architecture, PRD cost section and scenarios, and notify the owner.
